export type MainFeatureId = 
  | 'welcome'       // Halaman Pembuka / Welcome
  | 'objectives'    // Fitur 1: Tujuan Pembelajaran
  | 'materials'     // Fitur 2: Bahan Ajar
  | 'simulation'    // Fitur 3: Simulasi
  | 'games';        // Fitur 4: Games

export type SectionId = MainFeatureId;

export interface SectionMeta {
  id: MainFeatureId;
  title: string;
  badge: string;
  iconName: string;
}

export type GameDifficulty = 'low' | 'medium' | 'high'; // Rendah, Sedang, Tinggi

export interface GameItem {
  id: string;
  label: string;
  value: string | number;
  color?: string;
}

export interface WarungData {
  id: string;
  name: string;
  syrupMl: number;
  glasses: number;
  unitRatio: number; // syrupMl / glasses
  unitRatioFormatted: string;
  color: string;
  badgeColor: string;
}

