import React, { useState } from 'react';
import { Target, CheckCircle2, Compass, BookOpen, FlaskConical, Gamepad2, ArrowRight, Award, Sparkles } from 'lucide-react';

interface SectionObjectivesProps {
  onStartLearning: () => void;
}

export const SectionObjectives: React.FC<SectionObjectivesProps> = ({ onStartLearning }) => {
  // Interactive student self-check state
  const [checkedIndicators, setCheckedIndicators] = useState<number[]>([]);

  const toggleIndicator = (index: number) => {
    setCheckedIndicators((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const learningObjectives = [
    {
      id: 1,
      text: 'Melalui kegiatan eksplorasi, peserta didik dapat menjelaskan konsep rasio dan rasio satuan serta membedakan penggunaannya untuk membandingkan dua besaran dengan tepat.',
      focus: 'Memahami Konsep Rasio',
      icon: '💡',
    },
    {
      id: 2,
      text: 'Melalui kegiatan simulasi dan latihan, peserta didik dapat menganalisis informasi, menentukan, dan membandingkan rasio satuan dari dua besaran sejenis maupun berbeda satuan serta menjelaskan alasan berdasarkan hasil perhitungan secara logis.',
      focus: 'Menentukan dan Membandingkan Rasio Satuan',
      icon: '🧪',
    },
    {
      id: 3,
      text: 'Melalui games berbasis permasalahan kontekstual dan diskusi kelompok, peserta didik dapat menganalisis permasalahan, berkolaborasi menentukan strategi penyelesaian menggunakan rasio satuan, serta mengomunikasikan hasil dan alasan penyelesaiannya secara logis, efektif, dan santun.',
      focus: 'Memecahkan Masalah Kontekstual secara Kolaboratif',
      icon: '🎮',
    },
  ];

  const learningSteps = [
    {
      step: 1,
      title: 'Tujuan Pembelajaran',
      desc: 'Mengetahui arah dan target capaian materi rasio satuan.',
      icon: <Target className="w-5 h-5 text-amber-600" />,
      color: 'bg-amber-100 border-amber-400 text-amber-900',
      status: 'Sedang Dibaca',
    },
    {
      step: 2,
      title: 'Bahan Ajar Interaktif',
      desc: 'Pelajari konsep rasio dasar & rasio satuan dengan animasi pensil.',
      icon: <BookOpen className="w-5 h-5 text-sky-600" />,
      color: 'bg-sky-100 border-sky-400 text-sky-900',
      status: 'Langkah 2',
    },
    {
      step: 3,
      title: 'Simulasi Racikan',
      desc: 'Uji coba racik es sirup bebas & selidiki 3 studi kasus warung.',
      icon: <FlaskConical className="w-5 h-5 text-purple-600" />,
      color: 'bg-purple-100 border-purple-400 text-purple-900',
      status: 'Langkah 3',
    },
    {
      step: 4,
      title: 'Games Tantangan',
      desc: 'Mainkan game drag & drop tingkat Rendah, Sedang, & Tinggi!',
      icon: <Gamepad2 className="w-5 h-5 text-rose-600" />,
      color: 'bg-rose-100 border-rose-400 text-rose-900',
      status: 'Langkah 4',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Banner Header */}
      <div className="bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-200 border-4 border-slate-900 rounded-2xl p-5 sm:p-7 shadow-[6px_6px_0px_#1e293b] relative overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-slate-900 font-extrabold text-xs flex items-center gap-1 bg-white/90 px-2.5 py-0.5 rounded-full border border-slate-800">
            <Compass className="w-3.5 h-3.5 text-amber-700" /> Panduan & Target Belajar
          </span>
        </div>

        <h2 className="font-heading font-black text-2xl sm:text-3xl lg:text-4xl text-slate-900 leading-tight">
          Selamat Datang! 👋
        </h2>

        <p className="text-slate-800 text-sm sm:text-base font-bold mt-2 max-w-3xl leading-relaxed">
          Selamat datang! Melalui media pembelajaran interaktif ini, kamu akan mempelajari bagaimana cara membandingkan dua hal secara adil dan tepat menggunakan konsep <strong className="text-rose-700 underline decoration-rose-400">Rasio Satuan</strong>.
        </p>
      </div>

      {/* Capaian Pembelajaran (CP) Box */}
      <div className="comic-card bg-white p-5 sm:p-6 border-slate-900 space-y-3">
        <div className="flex items-center gap-3 border-b-2 border-slate-200 pb-3">
          <div className="p-2.5 bg-amber-400 border-2 border-slate-900 rounded-xl text-xl">
            📜
          </div>
          <div>
            <span className="text-xs font-black uppercase text-amber-800 tracking-wider">
              Standar Kompetensi
            </span>
            <h3 className="font-heading font-black text-xl text-slate-900">
              Capaian Pembelajaran (Fase C - Matematika SD)
            </h3>
          </div>
        </div>

        <p className="text-sm sm:text-base font-bold text-slate-700 leading-relaxed bg-amber-50/80 p-4 rounded-xl border border-amber-300">
          Peserta didik dapat memahami dan menerapkan konsep <strong>rasio</strong> serta <strong>rasio satuan</strong> untuk membandingkan dua besaran sejenis maupun berbeda satuan, serta mampu menggunakannya dalam menyelesaikan permasalahan kontekstual sehari-hari dengan kritis dan bernalar logis.
        </p>
      </div>

      {/* Rincian Tujuan Pembelajaran */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-black text-xl text-slate-900 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" /> Tujuan Pembelajaran:
          </h3>
          <span className="text-xs font-extrabold text-slate-500 hidden sm:inline">
            Klik kartu untuk menandai pemahamanmu!
          </span>
        </div>

        <div className="space-y-3.5">
          {learningObjectives.map((obj) => {
            const isChecked = checkedIndicators.includes(obj.id);
            return (
              <div
                key={obj.id}
                onClick={() => toggleIndicator(obj.id)}
                className={`comic-card p-4 sm:p-5 cursor-pointer transition-all duration-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                  isChecked
                    ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500 shadow-md'
                    : 'bg-white hover:bg-amber-50/50 border-slate-800'
                }`}
              >
                <div className="flex items-start gap-3.5 flex-1">
                  <div className="w-9 h-9 rounded-xl bg-amber-400 border-2 border-slate-900 flex items-center justify-center text-slate-900 font-heading font-black text-lg shrink-0 shadow-sm">
                    {obj.id}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-base">{obj.icon}</span>
                      <span className="bg-slate-900 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                        {obj.focus}
                      </span>
                    </div>

                    <p className="text-sm sm:text-base font-bold text-slate-800 leading-relaxed">
                      {obj.text}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <span className={`text-xs font-bold ${isChecked ? 'text-emerald-700 font-black' : 'text-slate-400'}`}>
                    {isChecked ? 'Tercapai ✅' : 'Tandai'}
                  </span>
                  <div
                    className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center transition-all ${
                      isChecked
                        ? 'bg-emerald-500 border-slate-900 text-white'
                        : 'border-slate-400 bg-slate-100 text-transparent'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Alur Pembelajaran 4 Langkah */}
      <div className="comic-card bg-slate-50 p-5 sm:p-6 border-slate-900 space-y-4">
        <div className="flex items-center gap-2 border-b-2 border-slate-200 pb-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          <h3 className="font-heading font-black text-lg sm:text-xl text-slate-900">
            Alur Pembelajaran
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {learningSteps.map((s) => (
            <div
              key={s.step}
              className={`p-4 rounded-xl border-2 border-slate-800 space-y-2 relative ${s.color} shadow-sm`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black bg-white/90 text-slate-900 px-2 py-0.5 rounded-full border border-slate-800">
                  {s.title}
                </span>
                {s.icon}
              </div>

              <h4 className="font-heading font-black text-base text-slate-900">
                {s.title}
              </h4>

              <p className="text-xs font-semibold text-slate-700 leading-snug">
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Action CTA Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-amber-100 p-5 rounded-2xl border-2 border-slate-900">
        <div className="text-center sm:text-left">
          <div className="font-heading font-bold text-lg text-slate-900">
            Sudah siap untuk memulai petualangan belajar?
          </div>
          <p className="text-xs sm:text-sm font-semibold text-slate-600">
            Mari buka Bahan Ajar untuk memahami konsep Rasio & Rasio Satuan!
          </p>
        </div>

        <button
          onClick={onStartLearning}
          className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-6 py-3.5 text-base font-black flex items-center gap-2 shrink-0 shadow-[4px_4px_0px_#1e293b]"
        >
          <span>Buka Bahan Ajar</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
