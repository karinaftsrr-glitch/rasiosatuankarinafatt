import React, { useState, useEffect } from 'react';
import { SectionId } from '../types';
import { Target, BookOpen, FlaskConical, Gamepad2, RotateCcw, Volume2, VolumeX, Scale, Home, Music } from 'lucide-react';
import { sounds } from '../utils/audio';
import { BgmModal } from './BgmModal';

interface NavbarProps {
  currentSection: SectionId;
  onSelectSection: (section: SectionId) => void;
  onResetSection: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentSection,
  onSelectSection,
  onResetSection,
  soundEnabled,
  onToggleSound,
}) => {
  const [isBgmModalOpen, setIsBgmModalOpen] = useState(false);
  const [bgmState, setBgmState] = useState(() => sounds.getBgmState());

  useEffect(() => {
    return sounds.subscribeBgm((st) => setBgmState(st));
  }, []);

  const features: { id: SectionId; label: string; short: string; badge: string; icon: React.ReactNode }[] = [
    {
      id: 'welcome',
      label: 'Halaman Pembuka',
      short: 'Pembuka',
      badge: 'Awal',
      icon: <Home className="w-4 h-4" />,
    },
    {
      id: 'objectives',
      label: 'Tujuan Pembelajaran',
      short: 'Tujuan',
      badge: 'Capaian',
      icon: <Target className="w-4 h-4" />,
    },
    {
      id: 'materials',
      label: 'Bahan Ajar',
      short: 'Bahan Ajar',
      badge: 'Materi',
      icon: <BookOpen className="w-4 h-4" />,
    },
    {
      id: 'simulation',
      label: 'Simulasi',
      short: 'Simulasi',
      badge: 'Praktik',
      icon: <FlaskConical className="w-4 h-4" />,
    },
    {
      id: 'games',
      label: 'Games',
      short: 'Games',
      badge: 'Tantangan',
      icon: <Gamepad2 className="w-4 h-4" />,
    },
  ];

  return (
    <header className="sticky top-0 z-50 bg-amber-400 border-b-4 border-slate-800 shadow-md">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-2">
        {/* Brand / Logo */}
        <div
          className="flex items-center gap-2.5 cursor-pointer group"
          onClick={() => onSelectSection('welcome')}
          title="Kembali ke Halaman Pembuka RasioKu"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-500 border-2 border-slate-900 flex items-center justify-center text-white font-extrabold shadow-[2px_2px_0px_#1e293b] group-hover:scale-105 transition-transform">
            <Scale className="w-5 h-5 text-amber-200" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-heading font-black text-lg sm:text-xl text-slate-900 leading-none tracking-tight">
                Rasio<span className="text-rose-600">Ku</span>
              </h1>
              <span className="hidden sm:inline-block bg-rose-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full border border-slate-900">
                KELAS 6
              </span>
            </div>
            <p className="text-xs font-bold text-slate-800 hidden sm:block">
              Matematika SD: Konsep Rasio Satuan
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Reset Current Animation / Page */}
          <button
            onClick={onResetSection}
            className="comic-button bg-emerald-300 hover:bg-emerald-400 text-slate-900 px-2.5 py-1.5 text-xs sm:text-sm font-bold flex items-center gap-1"
            title="Muat Ulang Halaman Ini"
          >
            <RotateCcw className="w-4 h-4 text-emerald-900" />
            <span className="hidden sm:inline">Reset</span>
          </button>

          {/* Sound FX Toggle */}
          <button
            onClick={onToggleSound}
            className={`comic-button p-2 text-xs font-bold ${
              soundEnabled ? 'bg-amber-100 text-amber-900' : 'bg-slate-200 text-slate-600'
            }`}
            title={soundEnabled ? 'Suara Efek Aktif' : 'Suara Efek Mute'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Backsound Music Toggle / Settings */}
          <button
            onClick={() => setIsBgmModalOpen(true)}
            className={`comic-button px-2.5 py-1.5 text-xs font-black flex items-center gap-1.5 transition-all ${
              bgmState.isPlaying
                ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-[2px_2px_0px_#1e293b]'
                : 'bg-amber-100 hover:bg-white text-slate-800'
            }`}
            title="Pengaturan Musik Backsound"
          >
            <Music className={`w-4 h-4 ${bgmState.isPlaying ? 'animate-bounce text-amber-200' : 'text-slate-800'}`} />
            <span className="hidden sm:inline font-bold">
              {bgmState.isPlaying ? 'Musik ON' : 'Musik'}
            </span>
          </button>
        </div>
      </div>

      {/* Bgm Modal */}
      <BgmModal isOpen={isBgmModalOpen} onClose={() => setIsBgmModalOpen(false)} />

      {/* Navigation Tabs Bar */}
      <div className="bg-amber-300/90 border-t-2 border-slate-800/40 px-2 py-1.5 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto flex items-center justify-start md:justify-center gap-2 min-w-max">
          {features.map((feat) => {
            const isActive = feat.id === currentSection;
            return (
              <button
                key={feat.id}
                onClick={() => onSelectSection(feat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all ${
                  isActive
                    ? 'bg-rose-500 text-white border-2 border-slate-900 shadow-[2px_2px_0px_#1e293b] scale-105'
                    : 'bg-amber-100 hover:bg-white text-slate-800 border-2 border-slate-800/60'
                }`}
              >
                {feat.icon}
                <span className="whitespace-nowrap hidden sm:inline">{feat.label}</span>
                <span className="whitespace-nowrap sm:hidden">{feat.short}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
