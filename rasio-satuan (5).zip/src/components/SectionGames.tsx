import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { GameDifficulty } from '../types';
import { GameVisualIllustration } from './GameVisualIllustration';
import { sounds } from '../utils/audio';
import {
  Gamepad2,
  Trophy,
  Sparkles,
  HelpCircle,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Lightbulb,
  ArrowRight,
  Star,
  ChevronRight,
  Smile,
  Flame,
  BookOpen,
  Calculator,
  Scale,
  AlertCircle,
} from 'lucide-react';

interface SectionGamesProps {
  soundEnabled: boolean;
}

interface ReviewStep {
  label: string;
  formula: string;
  result: string;
  explanation: string;
}

interface ReviewDiscussion {
  title: string;
  summary: string;
  steps: ReviewStep[];
  comparison: string;
  conclusion: string;
}

interface Question {
  id: string;
  difficulty: GameDifficulty;
  title: string;
  scenario: string;
  slots: {
    key: string;
    label: string;
    correctValue: string;
    currentValue?: string;
  }[];
  cards: {
    id: string;
    text: string;
    value: string;
    color?: string;
  }[];
  guidanceSteps: {
    step: number;
    title: string;
    hint: string;
  }[];
  appreciationText: string;
  reviewDiscussion: ReviewDiscussion;
}

export const SectionGames: React.FC<SectionGamesProps> = ({ soundEnabled }) => {
  const [difficulty, setDifficulty] = useState<GameDifficulty>('low');
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);

  // Drag and drop state
  const [droppedValues, setDroppedValues] = useState<{ [slotKey: string]: string }>({});
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);

  // Feedback states
  const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);
  const [showGuidance, setShowGuidance] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [incompleteWarning, setIncompleteWarning] = useState<boolean>(false);

  // Question bank across 3 difficulty levels: Mudah, Sedang, Susah (2 soal masing-masing)
  const questionsByDifficulty: Record<GameDifficulty, Question[]> = {
    low: [
      {
        id: 'low-1',
        difficulty: 'low',
        title: 'Minyak Goreng Kemasan Paling Hemat 🍳',
        scenario:
          'Ibu berbelanja di swalayan dan melihat dua kemasan minyak goreng: Merek A (2 Liter seharga Rp 28.000,00) dan Merek B (3 Liter seharga Rp 45.000,00). Hitung harga satuan minyak per 1 liter dan tentukan merek mana yang lebih murah (hemat)!',
        slots: [
          {
            key: 'slot-1',
            label: 'Harga Merek A per 1 Liter',
            correctValue: 'Rp 14.000 / Liter',
          },
          {
            key: 'slot-2',
            label: 'Harga Merek B per 1 Liter',
            correctValue: 'Rp 15.000 / Liter',
          },
          {
            key: 'slot-3',
            label: 'Merek yang Lebih Murah & Hemat',
            correctValue: 'Merek A (Hemat Rp 1.000/L)',
          },
        ],
        cards: [
          { id: 'c-1', text: 'Rp 14.000 / Liter', value: 'Rp 14.000 / Liter' },
          { id: 'c-2', text: 'Rp 15.000 / Liter', value: 'Rp 15.000 / Liter' },
          { id: 'c-3', text: 'Rp 16.000 / Liter', value: 'Rp 16.000 / Liter' },
          { id: 'c-4', text: 'Merek A (Hemat Rp 1.000/L)', value: 'Merek A (Hemat Rp 1.000/L)' },
          { id: 'c-5', text: 'Merek B (Lebih Hemat)', value: 'Merek B (Lebih Hemat)' },
        ],
        guidanceSteps: [
          {
            step: 1,
            title: 'Hitung Harga per 1 Liter Merek A',
            hint: 'Bagi total harga dengan volume: Rp 28.000 ÷ 2 Liter = Rp 14.000,00 per Liter.',
          },
          {
            step: 2,
            title: 'Hitung Harga per 1 Liter Merek B',
            hint: 'Bagi total harga dengan volume: Rp 45.000 ÷ 3 Liter = Rp 15.000,00 per Liter.',
          },
          {
            step: 3,
            title: 'Bandingkan & Tentukan yang Termurah',
            hint: 'Rp 14.000 < Rp 15.000. Merek A lebih murah dan menghemat Rp 1.000 setiap liternya!',
          },
        ],
        appreciationText:
          'Luar biasa cerdas! 🌟 Kamu berhasil membandingkan harga minyak goreng secara adil dengan rasio satuan. Merek A lebih hemat Rp 1.000 per liter!',
        reviewDiscussion: {
          title: 'Pembahasan: Memilih Minyak Goreng Paling Hemat',
          summary:
            'Kedua merek memiliki volume yang berbeda (2 Liter vs 3 Liter). Agar adil, kita tidak bisa langsung membandingkan total harga, melainkan harus menghitung harga satuan per 1 liter.',
          steps: [
            {
              label: 'Merek A (Kemasan 2 Liter)',
              formula: 'Rp 28.000,00 ÷ 2 Liter',
              result: 'Rp 14.000,00 / Liter',
              explanation: 'Setiap 1 liter minyak Merek A berharga Rp 14.000,00.',
            },
            {
              label: 'Merek B (Kemasan 3 Liter)',
              formula: 'Rp 45.000,00 ÷ 3 Liter',
              result: 'Rp 15.000,00 / Liter',
              explanation: 'Setiap 1 liter minyak Merek B berharga Rp 15.000,00.',
            },
          ],
          comparison: 'Rp 14.000,00 / Liter (Merek A) < Rp 15.000,00 / Liter (Merek B)',
          conclusion:
            'Merek A lebih murah dan menghemat Rp 1.000,00 untuk setiap liternya (Rp 15.000 - Rp 14.000 = Rp 1.000). Jadi, Ibu sebaiknya memilih Merek A!',
        },
      },
      {
        id: 'low-2',
        difficulty: 'low',
        title: 'Sabun Cuci Piring Murah & Banyak Isinya 🍋',
        scenario:
          'Ayah memilih sabun cuci piring jeruk nipis: Kemasan Pouch Isi Ulang (400 ml seharga Rp 8.000,00) dan Kemasan Botol Pompa (500 ml seharga Rp 12.500,00). Hitung harga per 1 ml pada masing-masing kemasan dan pilih yang paling hemat!',
        slots: [
          {
            key: 'slot-1',
            label: 'Harga Pouch per 1 ml',
            correctValue: 'Rp 20 / ml',
          },
          {
            key: 'slot-2',
            label: 'Harga Botol per 1 ml',
            correctValue: 'Rp 25 / ml',
          },
          {
            key: 'slot-3',
            label: 'Pilihan Paling Hemat per ml',
            correctValue: 'Pouch Isi Ulang (Lebih Murah)',
          },
        ],
        cards: [
          { id: 'c-1', text: 'Rp 20 / ml', value: 'Rp 20 / ml' },
          { id: 'c-2', text: 'Rp 25 / ml', value: 'Rp 25 / ml' },
          { id: 'c-3', text: 'Rp 30 / ml', value: 'Rp 30 / ml' },
          { id: 'c-4', text: 'Pouch Isi Ulang (Lebih Murah)', value: 'Pouch Isi Ulang (Lebih Murah)' },
          { id: 'c-5', text: 'Botol Pompa (Lebih Murah)', value: 'Botol Pompa (Lebih Murah)' },
        ],
        guidanceSteps: [
          {
            step: 1,
            title: 'Hitung Harga per ml Kemasan Pouch',
            hint: 'Rp 8.000 ÷ 400 ml = Rp 20 per ml.',
          },
          {
            step: 2,
            title: 'Hitung Harga per ml Kemasan Botol',
            hint: 'Rp 12.500 ÷ 500 ml = Rp 25 per ml.',
          },
          {
            step: 3,
            title: 'Bandingkan Kedua Harga Satuan',
            hint: 'Rp 20/ml < Rp 25/ml. Pouch isi ulang menghemat Rp 5 untuk setiap mililiter sabun!',
          },
        ],
        appreciationText:
          'Hebat sekali! 🌟 Kamu menghemat pengeluaran belanja keluarga dengan memilih pouch isi ulang yang berharga Rp 20 per ml dibanding botol pompa Rp 25 per ml!',
        reviewDiscussion: {
          title: 'Pembahasan: Sabun Pouch vs Botol Pompa',
          summary:
            'Kemasan pouch dan botol memiliki isi mililiter yang tidak sama. Kita cari harga untuk tiap 1 mililiter (ml) cairan sabun.',
          steps: [
            {
              label: 'Kemasan Pouch Isi Ulang (400 ml)',
              formula: 'Rp 8.000,00 ÷ 400 ml',
              result: 'Rp 20,00 / ml',
              explanation: 'Setiap 1 mililiter sabun dalam pouch berharga Rp 20,00.',
            },
            {
              label: 'Kemasan Botol Pompa (500 ml)',
              formula: 'Rp 12.500,00 ÷ 500 ml',
              result: 'Rp 25,00 / ml',
              explanation: 'Setiap 1 mililiter sabun dalam botol pompa berharga Rp 25,00.',
            },
          ],
          comparison: 'Rp 20,00 / ml (Pouch) < Rp 25,00 / ml (Botol)',
          conclusion:
            'Pouch isi ulang lebih murah dan hemat Rp 5,00 per ml. Botol pompa lebih mahal karena ada biaya wadah plastik dan kepala pompa dispenser!',
        },
      },
    ],
    medium: [
      {
        id: 'med-1',
        difficulty: 'medium',
        title: 'Menentukan Es Sirup yang Lebih Manis 🍹',
        scenario:
          'Kakak membuat 2 teko es sirup: Teko Melati (30 ml sirup murni dilarutkan ke dalam 5 gelas air) dan Teko Mawar (32 ml sirup murni dilarutkan ke dalam 4 gelas air). Hitung takaran sirup per 1 gelas dan tentukan teko mana yang rasanya lebih manis!',
        slots: [
          {
            key: 'slot-1',
            label: 'Teko Melati (Sirup per 1 Gelas)',
            correctValue: '6 ml / gelas',
          },
          {
            key: 'slot-2',
            label: 'Teko Mawar (Sirup per 1 Gelas)',
            correctValue: '8 ml / gelas',
          },
          {
            key: 'slot-3',
            label: 'Teko dengan Rasa Lebih Manis',
            correctValue: 'Teko Mawar (Lebih Manis)',
          },
        ],
        cards: [
          { id: 'c-1', text: '6 ml / gelas', value: '6 ml / gelas' },
          { id: 'c-2', text: '8 ml / gelas', value: '8 ml / gelas' },
          { id: 'c-3', text: '5 ml / gelas', value: '5 ml / gelas' },
          { id: 'c-4', text: 'Teko Mawar (Lebih Manis)', value: 'Teko Mawar (Lebih Manis)' },
          { id: 'c-5', text: 'Teko Melati (Lebih Manis)', value: 'Teko Melati (Lebih Manis)' },
        ],
        guidanceSteps: [
          {
            step: 1,
            title: 'Hitung Sirup per Gelas Teko Melati',
            hint: '30 ml ÷ 5 gelas = 6 ml sirup untuk setiap 1 gelas air.',
          },
          {
            step: 2,
            title: 'Hitung Sirup per Gelas Teko Mawar',
            hint: '32 ml ÷ 4 gelas = 8 ml sirup untuk setiap 1 gelas air.',
          },
          {
            step: 3,
            title: 'Tentukan Tingkat Rasa Manis',
            hint: 'Semakin banyak sirup dalam 1 gelas, rasanya semakin manis! 8 ml > 6 ml, sehingga racikan Teko Mawar lebih manis.',
          },
        ],
        appreciationText:
          'Tepat sekali! 🌟 Kamu berhasil menemukan bahwa Teko Mawar memiliki 8 ml sirup per gelas, sehingga rasa manisnya lebih pekat dan segar!',
        reviewDiscussion: {
          title: 'Pembahasan: Menakar Tingkat Kemanisan Es Sirup',
          summary:
            'Kemanisan sirup bergantung pada kepekatan (konsentrasi) sirup murni dalam tiap gelas air saji.',
          steps: [
            {
              label: 'Teko Melati (30 ml untuk 5 gelas)',
              formula: '30 ml ÷ 5 gelas',
              result: '6 ml / gelas',
              explanation: 'Tiap 1 gelas air di Teko Melati mendapat 6 ml sirup murni.',
            },
            {
              label: 'Teko Mawar (32 ml untuk 4 gelas)',
              formula: '32 ml ÷ 4 gelas',
              result: '8 ml / gelas',
              explanation: 'Tiap 1 gelas air di Teko Mawar mendapat 8 ml sirup murni.',
            },
          ],
          comparison: '8 ml / gelas (Teko Mawar) > 6 ml / gelas (Teko Melati)',
          conclusion:
            'Karena Teko Mawar mengandung 8 ml sirup per gelas (lebih banyak dari 6 ml), maka rasa racikan Teko Mawar terbukti jauh lebih manis!',
        },
      },
      {
        id: 'med-2',
        difficulty: 'medium',
        title: 'Membeli Beras Berkualitas Paling Hemat 🌾',
        scenario:
          'Paman membandingkan dua karung beras pulen di toko kelontong: Karung Sedang (5 kg seharga Rp 65.000,00) dan Karung Besar (10 kg seharga Rp 140.000,00). Hitung harga beras per 1 kg untuk masing-masing karung dan pilih yang paling hemat!',
        slots: [
          {
            key: 'slot-1',
            label: 'Harga Karung 5 kg per 1 kg',
            correctValue: 'Rp 13.000 / kg',
          },
          {
            key: 'slot-2',
            label: 'Harga Karung 10 kg per 1 kg',
            correctValue: 'Rp 14.000 / kg',
          },
          {
            key: 'slot-3',
            label: 'Karung Paling Hemat per 1 kg',
            correctValue: 'Karung 5 kg (Hemat Rp 1.000/kg)',
          },
        ],
        cards: [
          { id: 'c-1', text: 'Rp 13.000 / kg', value: 'Rp 13.000 / kg' },
          { id: 'c-2', text: 'Rp 14.000 / kg', value: 'Rp 14.000 / kg' },
          { id: 'c-3', text: 'Rp 15.000 / kg', value: 'Rp 15.000 / kg' },
          { id: 'c-4', text: 'Karung 5 kg (Hemat Rp 1.000/kg)', value: 'Karung 5 kg (Hemat Rp 1.000/kg)' },
          { id: 'c-5', text: 'Karung 10 kg (Lebih Hemat)', value: 'Karung 10 kg (Lebih Hemat)' },
        ],
        guidanceSteps: [
          {
            step: 1,
            title: 'Hitung Harga per kg Karung 5 kg',
            hint: 'Rp 65.000 ÷ 5 kg = Rp 13.000 per kg.',
          },
          {
            step: 2,
            title: 'Hitung Harga per kg Karung 10 kg',
            hint: 'Rp 140.000 ÷ 10 kg = Rp 14.000 per kg.',
          },
          {
            step: 3,
            title: 'Bandingkan Keduanya',
            hint: 'Rp 13.000 < Rp 14.000. Karung 5 kg ternyata lebih hemat Rp 1.000 per kg dibandingkan karung 10 kg!',
          },
        ],
        appreciationText:
          'Pintar sekali! 🎉 Kamu tidak terkecoh ukuran besar. Dengan menghitung rasio satuan, kamu menghemat Rp 1.000 per kg dengan membeli karung 5 kg!',
        reviewDiscussion: {
          title: 'Pembahasan: Membandingkan Harga Beras Antar-Karung',
          summary:
            'Sering kali orang mengira kemasan yang lebih besar otomatis lebih murah. Mari kita buktikan dengan rasio satuan per 1 kilogram.',
          steps: [
            {
              label: 'Karung 5 kg (Rp 65.000,00)',
              formula: 'Rp 65.000,00 ÷ 5 kg',
              result: 'Rp 13.000,00 / kg',
              explanation: 'Harga beras kemasan 5 kg adalah Rp 13.000,00 untuk tiap kilogram.',
            },
            {
              label: 'Karung 10 kg (Rp 140.000,00)',
              formula: 'Rp 140.000,00 ÷ 10 kg',
              result: 'Rp 14.000,00 / kg',
              explanation: 'Harga beras kemasan 10 kg adalah Rp 14.000,00 untuk tiap kilogram.',
            },
          ],
          comparison: 'Rp 13.000,00 / kg (Karung 5 kg) < Rp 14.000,00 / kg (Karung 10 kg)',
          conclusion:
            'Karung 5 kg ternyata lebih murah Rp 1.000,00 per kilogram! Jika membeli dua karung 5 kg (total 10 kg), harganya hanya Rp 130.000,00, lebih hemat Rp 10.000,00 daripada karung 10 kg langsung.',
        },
      },
    ],
    high: [
      {
        id: 'high-1',
        difficulty: 'high',
        title: 'Deterjen Mesin Cuci: Biaya Satuan per 1 Kali Cuci 🧺',
        scenario:
          'Bibi membandingkan dua deterjen cair mesin cuci: Mawar Wangi (Rp 30.000,00 cukup untuk 15 kali mencuci) dan Melati Segar (Rp 36.000,00 cukup untuk 20 kali mencuci). Hitung biaya per 1 kali cuci untuk masing-masing deterjen dan pilih yang paling irit!',
        slots: [
          {
            key: 'slot-1',
            label: 'Biaya Mawar Wangi per 1 Kali Cuci',
            correctValue: 'Rp 2.000 / cuci',
          },
          {
            key: 'slot-2',
            label: 'Biaya Melati Segar per 1 Kali Cuci',
            correctValue: 'Rp 1.800 / cuci',
          },
          {
            key: 'slot-3',
            label: 'Deterjen Paling Irit Biaya Cuci',
            correctValue: 'Melati Segar (Hemat Rp 200/cuci)',
          },
        ],
        cards: [
          { id: 'c-1', text: 'Rp 2.000 / cuci', value: 'Rp 2.000 / cuci' },
          { id: 'c-2', text: 'Rp 1.800 / cuci', value: 'Rp 1.800 / cuci' },
          { id: 'c-3', text: 'Rp 2.400 / cuci', value: 'Rp 2.400 / cuci' },
          { id: 'c-4', text: 'Melati Segar (Hemat Rp 200/cuci)', value: 'Melati Segar (Hemat Rp 200/cuci)' },
          { id: 'c-5', text: 'Mawar Wangi (Paling Irit)', value: 'Mawar Wangi (Paling Irit)' },
        ],
        guidanceSteps: [
          {
            step: 1,
            title: 'Hitung Biaya per Cuci Mawar Wangi',
            hint: 'Rp 30.000 ÷ 15 kali cuci = Rp 2.000 per 1 kali cuci.',
          },
          {
            step: 2,
            title: 'Hitung Biaya per Cuci Melati Segar',
            hint: 'Rp 36.000 ÷ 20 kali cuci = Rp 1.800 per 1 kali cuci.',
          },
          {
            step: 3,
            title: 'Tentukan Deterjen Paling Irit',
            hint: 'Rp 1.800 < Rp 2.000. Melati Segar lebih hemat Rp 200 untuk setiap kali mencuci pakaian!',
          },
        ],
        appreciationText:
          'Luar Biasa Jenius! 👑 Kamu adalah manajer belanja rumah tangga yang cerdas! Memilih deterjen Melati Segar terbukti paling irit pengeluarannya!',
        reviewDiscussion: {
          title: 'Pembahasan: Menghitung Biaya per 1 Kali Mencuci Pakaian',
          summary:
            'Kedua kemasan memiliki kapasitas pemakaian berbeda (15 kali vs 20 kali cuci). Kita hitung berapa rupiah yang dikeluarkan untuk 1 kali mencuci pakaian.',
          steps: [
            {
              label: 'Mawar Wangi (Rp 30.000 untuk 15 cuci)',
              formula: 'Rp 30.000,00 ÷ 15 kali',
              result: 'Rp 2.000,00 / cuci',
              explanation: 'Setiap 1 kali mencuci menghabiskan biaya deterjen Rp 2.000,00.',
            },
            {
              label: 'Melati Segar (Rp 36.000 untuk 20 cuci)',
              formula: 'Rp 36.000,00 ÷ 20 kali',
              result: 'Rp 1.800,00 / cuci',
              explanation: 'Setiap 1 kali mencuci menghabiskan biaya deterjen Rp 1.800,00.',
            },
          ],
          comparison: 'Rp 1.800,00 / cuci (Melati Segar) < Rp 2.000,00 / cuci (Mawar Wangi)',
          conclusion:
            'Melati Segar lebih irit dan menghemat Rp 200,00 untuk tiap kali mencuci pakaian (Rp 2.000 - Rp 1.800 = Rp 200).',
        },
      },
      {
        id: 'high-2',
        difficulty: 'high',
        title: 'Tiga Resep Sirup Buah: Urutan Tingkat Kemanisan 🍹🥭🍊',
        scenario:
          'Kedai minuman membuat 3 resep sirup buah: Sirup Jeruk (25 ml sirup dalam 4 gelas air), Sirup Cocopandan (36 ml sirup dalam 4 gelas air), dan Sirup Mangga (35 ml sirup dalam 5 gelas air). Hitung takaran sirup per 1 gelas (ml/gelas) dan urutkan dari yang PALING MANIS hingga yang KURANG MANIS!',
        slots: [
          {
            key: 'slot-1',
            label: 'Sirup Jeruk (ml per Gelas)',
            correctValue: '6,25 ml / gelas',
          },
          {
            key: 'slot-2',
            label: 'Sirup Cocopandan (ml per Gelas)',
            correctValue: '9 ml / gelas',
          },
          {
            key: 'slot-3',
            label: 'Sirup Mangga (ml per Gelas)',
            correctValue: '7 ml / gelas',
          },
          {
            key: 'slot-4',
            label: 'Urutan Rasa dari Paling Manis',
            correctValue: 'Cocopandan > Mangga > Jeruk',
          },
        ],
        cards: [
          { id: 'c-1', text: '6,25 ml / gelas', value: '6,25 ml / gelas' },
          { id: 'c-2', text: '9 ml / gelas', value: '9 ml / gelas' },
          { id: 'c-3', text: '7 ml / gelas', value: '7 ml / gelas' },
          { id: 'c-4', text: 'Cocopandan > Mangga > Jeruk', value: 'Cocopandan > Mangga > Jeruk' },
          { id: 'c-5', text: 'Jeruk > Mangga > Cocopandan', value: 'Jeruk > Mangga > Cocopandan' },
          { id: 'c-6', text: 'Mangga > Cocopandan > Jeruk', value: 'Mangga > Cocopandan > Jeruk' },
        ],
        guidanceSteps: [
          {
            step: 1,
            title: 'Kalkulasi Takaran Desimal Sirup Jeruk',
            hint: '25 ml ÷ 4 gelas = 6 sisa 1/4 = 6,25 ml per gelas.',
          },
          {
            step: 2,
            title: 'Kalkulasi Sirup Cocopandan & Mangga',
            hint: 'Cocopandan: 36 ÷ 4 = 9 ml/gelas. Mangga: 35 ÷ 5 = 7 ml/gelas.',
          },
          {
            step: 3,
            title: 'Urutkan dari Nilai Terbesar (Paling Manis)',
            hint: '9 ml (Cocopandan) > 7 ml (Mangga) > 6,25 ml (Jeruk).',
          },
        ],
        appreciationText:
          'Selamat, Kamu Menguasai Seluruh Tantangan Games! 🌟🌟🌟 Urutanmu 100% tepat: Cocopandan (9 ml) > Mangga (7 ml) > Jeruk (6,25 ml). Kemampuan rasio satuanmu luar biasa hebat!',
        reviewDiscussion: {
          title: 'Pembahasan: Urutan Kemanisan 3 Resep Sirup Buah',
          summary:
            'Kita hitung takaran sirup murni dalam 1 gelas saji untuk tiap resep hingga bentuk desimal, lalu mengurutkannya dari yang terbesar (paling pekat dan manis).',
          steps: [
            {
              label: 'Sirup Jeruk (25 ml dalam 4 gelas)',
              formula: '25 ml ÷ 4 gelas',
              result: '6,25 ml / gelas',
              explanation: '25 dibagi 4 menghasilkan 6,25 ml sirup murni untuk setiap gelas air.',
            },
            {
              label: 'Sirup Mangga (35 ml dalam 5 gelas)',
              formula: '35 ml ÷ 5 gelas',
              result: '7 ml / gelas',
              explanation: '35 dibagi 5 menghasilkan tepat 7 ml sirup murni untuk setiap gelas air.',
            },
            {
              label: 'Sirup Cocopandan (36 ml dalam 4 gelas)',
              formula: '36 ml ÷ 4 gelas',
              result: '9 ml / gelas',
              explanation: '36 dibagi 4 menghasilkan tepat 9 ml sirup murni untuk setiap gelas air.',
            },
          ],
          comparison: '9 ml (Cocopandan) > 7 ml (Mangga) > 6,25 ml (Jeruk)',
          conclusion:
            'Urutan dari yang paling manis adalah Cocopandan (9 ml) > Mangga (7 ml) > Jeruk (6,25 ml). Resep Cocopandan adalah pemenangnya!',
        },
      },
    ],
  };

  const currentQuestions = questionsByDifficulty[difficulty];
  const activeQuestion = currentQuestions[currentQIndex] || currentQuestions[0];

  // Drag and drop handlers
  const handleDragStart = (e: React.DragEvent, cardId: string) => {
    e.dataTransfer.setData('text/plain', cardId);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, slotKey: string) => {
    e.preventDefault();
    const cardId = e.dataTransfer.getData('text/plain');
    const card = activeQuestion.cards.find((c) => c.id === cardId);
    if (card) {
      setDroppedValues((prev) => ({
        ...prev,
        [slotKey]: card.value,
      }));
      setSelectedCardId(null);
      setIncompleteWarning(false);
      sounds.playCardSnap(soundEnabled);
    }
  };

  // Click-to-place helper
  const handleCardClick = (cardId: string) => {
    setSelectedCardId((prev) => (prev === cardId ? null : cardId));
  };

  const handleSlotClick = (slotKey: string) => {
    if (selectedCardId) {
      const card = activeQuestion.cards.find((c) => c.id === selectedCardId);
      if (card) {
        setDroppedValues((prev) => ({
          ...prev,
          [slotKey]: card.value,
        }));
        setSelectedCardId(null);
        setIncompleteWarning(false);
        sounds.playCardSnap(soundEnabled);
      }
    }
  };

  const handleRemoveFromSlot = (slotKey: string) => {
    setDroppedValues((prev) => {
      const next = { ...prev };
      delete next[slotKey];
      return next;
    });
  };

  // Submit and verify answer
  const handleCheckAnswer = () => {
    const allFilled = activeQuestion.slots.every((s) => droppedValues[s.key]);
    if (!allFilled) {
      setIncompleteWarning(true);
      sounds.playWarning(soundEnabled);
      return;
    }
    setIncompleteWarning(false);

    const allCorrect = activeQuestion.slots.every(
      (s) => droppedValues[s.key] === s.correctValue
    );

    setHasSubmitted(true);
    setIsCorrect(allCorrect);

    if (allCorrect) {
      sounds.playCorrect(soundEnabled);
      setShowGuidance(false);
      setScore((prev) => prev + (difficulty === 'low' ? 10 : difficulty === 'medium' ? 20 : 30));
      confetti({
        particleCount: 80,
        spread: 80,
        origin: { y: 0.6 },
      });
    } else {
      sounds.playWrong(soundEnabled);
    }
  };

  const handleResetCurrentQuestion = () => {
    setDroppedValues({});
    setSelectedCardId(null);
    setHasSubmitted(false);
    setIsCorrect(false);
    setShowGuidance(false);
    setIncompleteWarning(false);
  };

  const handleNextQuestion = () => {
    if (currentQIndex < currentQuestions.length - 1) {
      setCurrentQIndex((prev) => prev + 1);
    } else {
      // Cycle or advance difficulty
      if (difficulty === 'low') setDifficulty('medium');
      else if (difficulty === 'medium') setDifficulty('high');
      else setDifficulty('low');
      setCurrentQIndex(0);
    }
    setDroppedValues({});
    setSelectedCardId(null);
    setHasSubmitted(false);
    setIsCorrect(false);
    setShowGuidance(false);
    setIncompleteWarning(false);
  };

  const handleSelectDifficulty = (newDiff: GameDifficulty) => {
    setDifficulty(newDiff);
    setCurrentQIndex(0);
    setDroppedValues({});
    setSelectedCardId(null);
    setHasSubmitted(false);
    setIsCorrect(false);
    setShowGuidance(false);
    setIncompleteWarning(false);
  };

  return (
    <div className="space-y-6">
      {/* HEADER SECTION */}
      <div className="comic-card bg-amber-300 p-6 flex flex-col md:flex-row items-center justify-between gap-4 border-amber-400">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-white border-2 border-slate-900 rounded-2xl shadow-[3px_3px_0px_#1e293b]">
            <Gamepad2 className="w-8 h-8 text-amber-600 animate-bounce" />
          </div>
          <div>
            <h2 className="font-heading font-black text-2xl sm:text-3xl text-slate-900">
              Arena Tantangan RasioKu 🎮
            </h2>
            <p className="text-xs sm:text-sm font-extrabold text-slate-800">
              Selesaikan studi kasus belanja & takaran sehari-hari dengan rasio satuan!
            </p>
          </div>
        </div>

        {/* SCORE BADGE */}
        <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-2xl border-2 border-slate-900 shadow-[3px_3px_0px_#1e293b]">
          <Trophy className="w-6 h-6 text-yellow-500 fill-yellow-400" />
          <div>
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-500">
              Skor Prestasi
            </div>
            <div className="font-heading font-black text-xl text-slate-900 leading-tight">
              {score} Poin
            </div>
          </div>
        </div>
      </div>

      {/* DIFFICULTY SELECTOR */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          {
            key: 'low' as GameDifficulty,
            label: '🟢 Mudah',
            desc: 'Minyak Goreng & Sabun Cuci',
            bg: 'bg-emerald-400',
            border: 'border-emerald-500',
          },
          {
            key: 'medium' as GameDifficulty,
            label: '🟡 Sedang',
            desc: 'Es Sirup & Beras Karung',
            bg: 'bg-amber-400',
            border: 'border-amber-500',
          },
          {
            key: 'high' as GameDifficulty,
            label: '🔴 Susah',
            desc: 'Deterjen & Urutan 3 Sirup',
            bg: 'bg-rose-400',
            border: 'border-rose-500',
          },
        ].map((item) => {
          const isActive = difficulty === item.key;
          return (
            <button
              key={item.key}
              onClick={() => handleSelectDifficulty(item.key)}
              className={`comic-card p-3.5 sm:p-4 text-left transition-all ${
                isActive
                  ? `${item.bg} text-slate-900 scale-[1.02] shadow-[5px_5px_0px_#1e293b] ring-2 ring-slate-900`
                  : 'bg-white text-slate-700 hover:bg-slate-50 opacity-90'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-heading font-black text-base">{item.label}</span>
                {isActive && <Sparkles className="w-4 h-4 text-slate-900 animate-spin" />}
              </div>
              <p className="text-xs font-bold text-slate-800">{item.desc}</p>
            </button>
          );
        })}
      </div>

      {/* MAIN GAME CARD */}
      <div className="comic-card bg-white p-5 sm:p-7 space-y-6">
        {/* Top Info Bar */}
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="bg-slate-900 text-amber-300 font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
                Tantangan #{currentQIndex + 1} dari {currentQuestions.length}
              </span>
              <span className="text-xs font-black bg-amber-100 text-amber-900 px-2.5 py-1 rounded-full border border-amber-300">
                Level: {difficulty === 'low' ? 'Mudah' : difficulty === 'medium' ? 'Sedang' : 'Susah'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetCurrentQuestion}
                className="comic-button bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs px-3 py-1.5 font-extrabold flex items-center gap-1.5"
                title="Reset kotak jawaban"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Kosongkan</span>
              </button>

              <button
                onClick={() => setShowGuidance(!showGuidance)}
                className="comic-button bg-amber-200 hover:bg-amber-300 text-amber-900 text-xs px-3 py-1.5 font-extrabold flex items-center gap-1.5"
              >
                <Lightbulb className="w-4 h-4 text-amber-700" />
                <span>{showGuidance ? 'Tutup Bantuan' : 'Butuh Petunjuk?'}</span>
              </button>
            </div>
          </div>

          <h3 className="font-heading font-black text-xl text-slate-900">
            {activeQuestion.title}
          </h3>

          <p className="text-sm sm:text-base font-bold text-slate-800 leading-relaxed bg-amber-50 p-4 rounded-xl border border-amber-300">
            {activeQuestion.scenario}
          </p>
        </div>

        {/* Visual Illustration of the Game Scenario (Calculations hidden until user submits!) */}
        <GameVisualIllustration questionId={activeQuestion.id} showCalculations={hasSubmitted} />

        {/* DRAG AND DROP ZONE */}
        <div className="space-y-4">
          <div className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center justify-between">
            <span>🎯 Kotak Jawaban Sasaran (Drop Zone):</span>
            <span className="text-slate-500 normal-case font-bold hidden sm:inline">
              Tarik kartu atau ketuk kartu lalu ketuk kotak di bawah ini
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {activeQuestion.slots.map((slot) => {
              const currentValue = droppedValues[slot.key];
              const isSlotCorrect = hasSubmitted && currentValue === slot.correctValue;
              const isSlotWrong = hasSubmitted && currentValue && currentValue !== slot.correctValue;

              return (
                <div
                  key={slot.key}
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, slot.key)}
                  onClick={() => handleSlotClick(slot.key)}
                  className={`comic-card p-4 rounded-xl border-2 transition-all cursor-pointer min-h-[110px] flex flex-col justify-between ${
                    isSlotCorrect
                      ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500'
                      : isSlotWrong
                      ? 'bg-rose-50 border-rose-500 ring-2 ring-rose-500'
                      : currentValue
                      ? 'bg-white border-sky-400'
                      : 'bg-slate-100/90 border-dashed border-slate-400 hover:border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <span className="text-xs font-black text-slate-700">{slot.label}</span>
                    {isSlotCorrect && (
                      <span className="text-[10px] font-black bg-emerald-500 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Benar
                      </span>
                    )}
                    {isSlotWrong && (
                      <span className="text-[10px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                        <XCircle className="w-3 h-3" /> Kurang Tepat
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    {currentValue ? (
                      <div className="flex items-center justify-between w-full bg-slate-900 text-amber-300 px-3.5 py-2 rounded-xl border border-slate-800 font-extrabold text-sm sm:text-base">
                        <span>{currentValue}</span>
                        {!hasSubmitted && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveFromSlot(slot.key);
                            }}
                            className="text-slate-400 hover:text-white text-xs px-1"
                            title="Hapus pilihan ini"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="text-xs font-bold text-slate-400 italic py-2 text-center w-full">
                        {selectedCardId ? 'Ketuk di sini untuk memasukkan kartu' : 'Letakkan jawaban di sini'}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* AVAILABLE ANSWER CARDS */}
        <div className="space-y-3 bg-amber-50/70 p-4 sm:p-5 rounded-2xl border-2 border-amber-300">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-black uppercase text-amber-900 tracking-wider flex items-center gap-1.5">
              <Star className="w-4 h-4 fill-amber-400 text-amber-700" />
              <span>Pilihan Kartu Jawaban:</span>
            </span>
            <span className="text-[11px] font-bold text-amber-800">
              Geser kartu atau ketuk kartu untuk memilih
            </span>
          </div>

          <div className="flex flex-wrap gap-2.5">
            {activeQuestion.cards.map((card) => {
              const isSelected = selectedCardId === card.id;
              // Check if already used in any slot
              const isAlreadyPlaced = Object.values(droppedValues).includes(card.value);

              return (
                <div
                  key={card.id}
                  draggable={!hasSubmitted}
                  onDragStart={(e) => handleDragStart(e, card.id)}
                  onClick={() => !hasSubmitted && handleCardClick(card.id)}
                  className={`comic-card px-4 py-2.5 rounded-xl border-2 font-black text-xs sm:text-sm cursor-grab active:cursor-grabbing transition-all select-none ${
                    isAlreadyPlaced
                      ? 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed opacity-60'
                      : isSelected
                      ? 'bg-yellow-400 text-slate-900 border-slate-900 ring-2 ring-slate-900 scale-105 shadow-[4px_4px_0px_#1e293b]'
                      : 'bg-white text-slate-900 border-slate-900 hover:bg-amber-100 shadow-[3px_3px_0px_#1e293b]'
                  }`}
                >
                  <span>{card.text}</span>
                  {isSelected && <span className="ml-1.5 text-xs">👈</span>}
                </div>
              );
            })}
          </div>
        </div>

        {/* INCOMPLETE WARNING NOTICE */}
        {incompleteWarning && (
          <div className="comic-card bg-rose-50 border-rose-400 p-3.5 flex items-center gap-2.5 text-rose-900 text-xs sm:text-sm font-extrabold animate-shake">
            <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            <span>Tolong lengkapi semua kotak jawaban sasaran di atas terlebih dahulu ya sebelum memeriksa!</span>
          </div>
        )}

        {/* SUBMIT BUTTON BAR */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="text-xs font-bold text-slate-500">
            {hasSubmitted
              ? '✅ Jawaban telah dikirim. Simak review pembahasan lengkap di bawah ini!'
              : 'Pastikan seluruh kotak sudah terisi, lalu periksa hasil perhitunganmu.'}
          </div>

          <div className="flex items-center gap-2">
            {hasSubmitted && !isCorrect && (
              <button
                onClick={handleResetCurrentQuestion}
                className="comic-button bg-amber-400 hover:bg-amber-500 text-slate-900 px-4 py-3 text-sm font-black flex items-center gap-1.5 shadow-[3px_3px_0px_#1e293b]"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Coba Lagi</span>
              </button>
            )}

            <button
              onClick={handleCheckAnswer}
              disabled={hasSubmitted && isCorrect}
              className={`comic-button px-6 py-3 text-sm sm:text-base font-black flex items-center gap-2 shadow-[4px_4px_0px_#1e293b] ${
                hasSubmitted && isCorrect
                  ? 'bg-slate-300 text-slate-600 cursor-not-allowed border-slate-400 shadow-none'
                  : 'bg-rose-500 hover:bg-rose-600 text-white'
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>{hasSubmitted ? 'Periksa Ulang' : 'Periksa Jawaban!'}</span>
            </button>
          </div>
        </div>

        {/* APPRECIATION FEEDBACK BOX (WHEN 100% CORRECT) */}
        {hasSubmitted && isCorrect && (
          <div className="comic-card bg-emerald-100 p-5 sm:p-6 border-emerald-500 space-y-4 animate-bounce-subtle">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-400 border-2 border-slate-900 rounded-2xl text-3xl">
                🌟
              </div>
              <div>
                <span className="bg-emerald-600 text-white font-extrabold text-xs px-3 py-0.5 rounded-full uppercase">
                  Umpan Balik Positif & Apresiasi
                </span>
                <h4 className="font-heading font-black text-xl sm:text-2xl text-emerald-900 mt-1">
                  Luar Biasa, Jawabanmu 100% Benar! 🎉
                </h4>
              </div>
            </div>

            <p className="text-sm sm:text-base font-bold text-slate-800 leading-relaxed bg-white p-4 rounded-xl border-2 border-slate-900">
              {activeQuestion.appreciationText}
            </p>
          </div>
        )}

        {/* ENCOURAGEMENT BOX (WHEN NOT 100% CORRECT) */}
        {hasSubmitted && !isCorrect && (
          <div className="comic-card bg-rose-50 p-5 sm:p-6 border-rose-400 space-y-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-rose-400 border-2 border-slate-900 rounded-2xl text-2xl">
                💪
              </div>
              <div>
                <span className="bg-rose-600 text-white font-extrabold text-[11px] px-2.5 py-0.5 rounded-full uppercase">
                  Tetap Semangat!
                </span>
                <h4 className="font-heading font-black text-lg sm:text-xl text-rose-950 mt-0.5">
                  Ada Pilihan yang Masih Kurang Tepat
                </h4>
              </div>
            </div>
            <p className="text-xs sm:text-sm font-bold text-slate-700 bg-white p-3.5 rounded-xl border border-rose-200">
              Jangan berkecil hati! Mari pelajari <strong>Review & Pembahasan Lengkap</strong> di bawah ini, lalu kamu bisa menekan tombol <strong>"Coba Lagi"</strong> untuk memperbaiki jawabanmu!
            </p>
          </div>
        )}

        {/* REVIEW & PEMBAHASAN LENGKAP (APPEARS AFTER SUBMIT!) */}
        {hasSubmitted && (
          <div className="comic-card bg-gradient-to-b from-sky-50 to-indigo-50/60 p-5 sm:p-6 border-sky-400 space-y-5 animate-fadeIn">
            {/* Review Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b-2 border-sky-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-sky-400 border-2 border-slate-900 rounded-xl text-xl">
                  <BookOpen className="w-5 h-5 text-slate-900" />
                </div>
                <div>
                  <span className="bg-sky-600 text-white font-black text-[10px] px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    Review & Pembahasan Lengkap
                  </span>
                  <h4 className="font-heading font-black text-lg sm:text-xl text-slate-900 mt-0.5">
                    {activeQuestion.reviewDiscussion.title}
                  </h4>
                </div>
              </div>
              <span className="text-xs font-black bg-indigo-100 text-indigo-900 px-3 py-1 rounded-full border border-indigo-300 flex items-center gap-1">
                <Calculator className="w-3.5 h-3.5 text-indigo-700" />
                <span>Kupas Tuntas Rasio Satuan</span>
              </span>
            </div>

            {/* Problem Summary Context */}
            <div className="bg-white p-4 rounded-xl border-2 border-slate-800 text-xs sm:text-sm font-bold text-slate-800 leading-relaxed">
              💡 <span className="font-black text-slate-900">Cara Berpikir: </span>
              {activeQuestion.reviewDiscussion.summary}
            </div>

            {/* Calculation Steps Grid */}
            <div className="space-y-3">
              <div className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-sky-600" />
                <span>Langkah Perhitungan Rasio Satuan:</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {activeQuestion.reviewDiscussion.steps.map((step, idx) => (
                  <div
                    key={idx}
                    className="bg-white p-4 rounded-xl border-2 border-slate-800 shadow-sm flex flex-col justify-between space-y-2"
                  >
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="font-heading font-black text-xs sm:text-sm text-slate-900">
                        {step.label}
                      </span>
                      <span className="bg-amber-300 text-slate-900 text-[10px] font-black px-2 py-0.5 rounded-full border border-slate-900">
                        Langkah {idx + 1}
                      </span>
                    </div>

                    <div className="bg-slate-900 text-amber-300 p-2.5 rounded-lg text-center font-mono font-black text-xs sm:text-sm">
                      {step.formula} = <span className="text-emerald-400">{step.result}</span>
                    </div>

                    <p className="text-xs font-bold text-slate-600">
                      {step.explanation}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Comparison Box */}
            <div className="bg-amber-100 border-2 border-slate-900 rounded-xl p-3.5 sm:p-4 text-center space-y-1">
              <div className="text-[11px] font-black uppercase tracking-wider text-amber-900">
                Perbandingan Nilai Satuan
              </div>
              <div className="font-heading font-black text-base sm:text-lg text-slate-900">
                {activeQuestion.reviewDiscussion.comparison}
              </div>
            </div>

            {/* Final Conclusion Box */}
            <div className="bg-emerald-100 border-2 border-emerald-500 rounded-xl p-4 flex items-start gap-3">
              <div className="text-2xl mt-0.5">🎯</div>
              <div>
                <h5 className="font-heading font-black text-sm text-emerald-950">
                  Kesimpulan & Keputusan Cerdas:
                </h5>
                <p className="text-xs sm:text-sm font-bold text-emerald-900 mt-0.5 leading-relaxed">
                  {activeQuestion.reviewDiscussion.conclusion}
                </p>
              </div>
            </div>

            {/* Navigation to Next Challenge */}
            <div className="flex justify-end pt-2">
              <button
                onClick={handleNextQuestion}
                className="comic-button bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3 text-sm sm:text-base font-black flex items-center gap-2 shadow-[3px_3px_0px_#1e293b]"
              >
                <span>Tantangan Selanjutnya</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* STEP-BY-STEP GUIDANCE (HINTS ON DEMAND) */}
        {showGuidance && (
          <div className="comic-card bg-sky-50 p-5 sm:p-6 border-sky-400 space-y-4 animate-fadeIn">
            <div className="flex items-center gap-2.5 border-b-2 border-sky-200 pb-3">
              <div className="p-2 bg-sky-400 border-2 border-slate-900 rounded-xl text-xl">
                💡
              </div>
              <div>
                <span className="bg-sky-600 text-white font-extrabold text-[10px] px-2.5 py-0.5 rounded-full uppercase">
                  Bimbingan Langkah Belajar
                </span>
                <h4 className="font-heading font-black text-lg sm:text-xl text-slate-900">
                  Yuk Ikuti Langkah Bantuan Ini:
                </h4>
              </div>
            </div>

            <div className="space-y-3">
              {activeQuestion.guidanceSteps.map((step) => (
                <div
                  key={step.step}
                  className="bg-white p-4 rounded-xl border-2 border-slate-800 space-y-1"
                >
                  <div className="flex items-center gap-2">
                    <span className="bg-amber-400 text-slate-900 text-xs font-black px-2.5 py-0.5 rounded-full border border-slate-900">
                      Langkah {step.step}
                    </span>
                    <h5 className="font-heading font-black text-sm text-slate-900">
                      {step.title}
                    </h5>
                  </div>
                  <p className="text-xs sm:text-sm font-bold text-slate-700 pl-1 leading-relaxed">
                    {step.hint}
                  </p>
                </div>
              ))}
            </div>

            <div className="bg-sky-100 p-3.5 rounded-xl border border-sky-300 text-center text-xs font-extrabold text-slate-800">
              Sudah paham langkahnya? Silakan susun kembali kartu jawabanmu di atas, lalu tekan tombol <strong>"Periksa Jawaban!"</strong>.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
