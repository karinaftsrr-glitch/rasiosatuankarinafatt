import React from 'react';
import { SectionId } from '../types';
import {
  Sparkles,
  ArrowRight,
  Target,
  BookOpen,
  FlaskConical,
  Gamepad2,
  CheckCircle2,
  Scale,
  Smile,
  GraduationCap,
  Heart,
  HelpCircle,
} from 'lucide-react';

interface SectionWelcomeProps {
  onStartLearning: () => void;
  onSelectDirectSection?: (section: SectionId) => void;
}

export const SectionWelcome: React.FC<SectionWelcomeProps> = ({
  onStartLearning,
  onSelectDirectSection,
}) => {
  return (
    <div className="space-y-8 animate-fadeIn max-w-4xl mx-auto py-2">
      {/* HERO BANNER CARD WITH LOGO */}
      <div className="comic-card bg-gradient-to-br from-amber-300 via-amber-200 to-yellow-300 p-6 sm:p-10 border-4 border-slate-900 shadow-[8px_8px_0px_#1e293b] text-center relative overflow-hidden">
        {/* Background decorative doodles */}
        <div className="absolute top-4 left-6 text-3xl opacity-30 select-none pointer-events-none animate-pulse">
          📐
        </div>
        <div className="absolute top-8 right-8 text-3xl opacity-30 select-none pointer-events-none animate-bounce">
          🧮
        </div>
        <div className="absolute bottom-6 left-10 text-3xl opacity-30 select-none pointer-events-none">
          ⚖️
        </div>
        <div className="absolute bottom-6 right-12 text-3xl opacity-30 select-none pointer-events-none">
          🍹
        </div>

        {/* LOGO RASIOKU */}
        <div className="flex flex-col items-center justify-center space-y-4 relative z-10">
          {/* Logo Badge Icon */}
          <div className="relative group">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-rose-500 border-4 border-slate-900 flex items-center justify-center shadow-[6px_6px_0px_#1e293b] transform -rotate-3 hover:rotate-0 transition-transform duration-300">
              <div className="flex flex-col items-center justify-center">
                <span className="text-4xl sm:text-5xl">⚖️</span>
                <span className="text-[10px] font-black tracking-widest text-amber-200 uppercase mt-0.5">
                  1 : N
                </span>
              </div>
            </div>
            <div className="absolute -top-2 -right-3 bg-amber-400 border-2 border-slate-900 text-slate-900 text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-[2px_2px_0px_#1e293b] animate-bounce">
              SD KELAS 6
            </div>
          </div>

          {/* Logo Brand Title */}
          <div>
            <div className="inline-block bg-slate-900 text-amber-300 text-xs sm:text-sm font-black px-4 py-1 rounded-full border-2 border-slate-900 uppercase tracking-wider mb-2 shadow-[2px_2px_0px_#1e293b]">
              Media Pembelajaran Interaktif Matematika
            </div>
            <h1 className="font-heading font-black text-5xl sm:text-6xl md:text-7xl text-slate-900 tracking-tight drop-shadow-sm">
              Rasio<span className="text-rose-600">Ku</span>
            </h1>
            <p className="font-heading font-black text-lg sm:text-2xl text-slate-800 mt-2">
              Kuasai Rasio Satuan dalam Kehidupan Sehari-hari! 🌟
            </p>
          </div>

          {/* Short Intro Description */}
          <p className="text-sm sm:text-base font-bold text-slate-700 max-w-xl mx-auto leading-relaxed bg-white/80 p-3.5 sm:p-4 rounded-2xl border-2 border-slate-900 shadow-[3px_3px_0px_#1e293b]">
            Selamat datang di <strong>RasioKu</strong>! Yuk, pelajari konsep rasio satuan dengan mudah dan seru lewat simulasi interaktif!
          </p>

          {/* MAIN CALL TO ACTION BUTTON */}
          <div className="pt-3 w-full sm:w-auto">
            <button
              onClick={onStartLearning}
              className="comic-button bg-rose-500 hover:bg-rose-600 text-white font-heading font-black text-xl sm:text-2xl px-8 sm:px-14 py-4 sm:py-5 rounded-2xl shadow-[6px_6px_0px_#1e293b] flex items-center justify-center gap-3 transition-all transform hover:-translate-y-1 hover:scale-105 active:translate-y-1 active:scale-95 w-full sm:w-auto cursor-pointer"
            >
              <span>Mulai Belajar Sekarang</span>
              <ArrowRight className="w-7 h-7 animate-pulse" />
            </button>
          </div>

          {/* Author Badge */}
          <div className="flex items-center justify-center gap-2 pt-2 text-xs sm:text-sm font-extrabold text-slate-700">
            <GraduationCap className="w-4 h-4 text-rose-600" />
            <span>Disusun oleh: <strong className="text-slate-900">Karina Fatmasari</strong></span>
          </div>
        </div>
      </div>

      {/* 4 LEARNING ZONES PREVIEW */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500 fill-amber-400" />
            <h2 className="font-heading font-black text-xl text-slate-900">
              4 Petualangan Belajar di RasioKu
            </h2>
          </div>
          <span className="text-xs font-bold text-slate-500">
            Pilih atau klik "Mulai Belajar" di atas
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Card 1: Tujuan */}
          <div
            onClick={() => onSelectDirectSection && onSelectDirectSection('objectives')}
            className="comic-card bg-white hover:bg-amber-50 p-5 rounded-2xl border-3 border-slate-900 shadow-[4px_4px_0px_#1e293b] flex items-start gap-3.5 cursor-pointer transition-transform hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-400 border-2 border-slate-900 flex items-center justify-center flex-shrink-0 shadow-[2px_2px_0px_#1e293b]">
              <Target className="w-6 h-6 text-slate-900" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-heading font-black text-base text-slate-900">
                  1. Tujuan Pembelajaran
                </h3>
                <span className="text-[10px] font-black bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full border border-slate-900">
                  Capaian
                </span>
              </div>
              <p className="text-xs font-bold text-slate-600 mt-1">
                Pahami capaian pembelajaran Kurikulum Merdeka & indikator keberhasilan rasio satuan.
              </p>
            </div>
          </div>

          {/* Card 2: Bahan Ajar */}
          <div
            onClick={() => onSelectDirectSection && onSelectDirectSection('materials')}
            className="comic-card bg-white hover:bg-sky-50 p-5 rounded-2xl border-3 border-slate-900 shadow-[4px_4px_0px_#1e293b] flex items-start gap-3.5 cursor-pointer transition-transform hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-xl bg-sky-400 border-2 border-slate-900 flex items-center justify-center flex-shrink-0 shadow-[2px_2px_0px_#1e293b]">
              <BookOpen className="w-6 h-6 text-slate-900" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-heading font-black text-base text-slate-900">
                  2. Bahan Ajar Interaktif
                </h3>
                <span className="text-[10px] font-black bg-sky-200 text-sky-900 px-2 py-0.5 rounded-full border border-slate-900">
                  Materi
                </span>
              </div>
              <p className="text-xs font-bold text-slate-600 mt-1">
                Kuasai konsep rasio satuan lewat cerita belanja cerdas di Toko Buah & Swalayan.
              </p>
            </div>
          </div>

          {/* Card 3: Simulasi */}
          <div
            onClick={() => onSelectDirectSection && onSelectDirectSection('simulation')}
            className="comic-card bg-white hover:bg-purple-50 p-5 rounded-2xl border-3 border-slate-900 shadow-[4px_4px_0px_#1e293b] flex items-start gap-3.5 cursor-pointer transition-transform hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-xl bg-purple-400 border-2 border-slate-900 flex items-center justify-center flex-shrink-0 shadow-[2px_2px_0px_#1e293b]">
              <FlaskConical className="w-6 h-6 text-slate-900" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-heading font-black text-base text-slate-900">
                  3. Lab Simulasi Sirup
                </h3>
                <span className="text-[10px] font-black bg-purple-200 text-purple-900 px-2 py-0.5 rounded-full border border-slate-900">
                  Praktik
                </span>
              </div>
              <p className="text-xs font-bold text-slate-600 mt-1">
                Uji kepekatan rasa es sirup secara visual dengan slider takaran sirup & air saji.
              </p>
            </div>
          </div>

          {/* Card 4: Games */}
          <div
            onClick={() => onSelectDirectSection && onSelectDirectSection('games')}
            className="comic-card bg-white hover:bg-rose-50 p-5 rounded-2xl border-3 border-slate-900 shadow-[4px_4px_0px_#1e293b] flex items-start gap-3.5 cursor-pointer transition-transform hover:-translate-y-1"
          >
            <div className="w-12 h-12 rounded-xl bg-rose-400 border-2 border-slate-900 flex items-center justify-center flex-shrink-0 shadow-[2px_2px_0px_#1e293b]">
              <Gamepad2 className="w-6 h-6 text-slate-900" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-heading font-black text-base text-slate-900">
                  4. Arena Games Tantangan
                </h3>
                <span className="text-[10px] font-black bg-rose-200 text-rose-900 px-2 py-0.5 rounded-full border border-slate-900">
                  Tantangan
                </span>
              </div>
              <p className="text-xs font-bold text-slate-600 mt-1">
                Pecahkan 6 kasus belanja hemat dengan drag-and-drop dan simak review pembahasan lengkapnya!
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* WHY RASIOKU HIGHLIGHTS */}
      <div className="comic-card bg-white p-6 rounded-2xl border-3 border-slate-900 shadow-[4px_4px_0px_#1e293b] space-y-3">
        <h3 className="font-heading font-black text-base sm:text-lg text-slate-900 flex items-center gap-2">
          <Smile className="w-5 h-5 text-amber-500" />
          <span>Kenapa Belajar di RasioKu Itu Asyik?</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs sm:text-sm font-bold text-slate-700">
          <div className="flex items-start gap-2 bg-amber-50 p-3 rounded-xl border border-amber-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
            <span><strong>Kontekstual:</strong> Contoh kasus belanja barang asli di toko dan swalayan.</span>
          </div>
          <div className="flex items-start gap-2 bg-sky-50 p-3 rounded-xl border border-sky-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
            <span><strong>Interaktif:</strong> Dilengkapi simulasi lab visual dan permainan drag & drop.</span>
          </div>
          <div className="flex items-start gap-2 bg-emerald-50 p-3 rounded-xl border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
            <span><strong>Review Lengkap:</strong> Pembahasan langkah demi langkah setelah menjawab.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
