import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { SyrupGlassVisual } from './SyrupGlassVisual';
import { DivisionVisualizer } from './DivisionVisualizer';
import { Search, Calculator, ArrowRight, CheckCircle2, HelpCircle, AlertCircle } from 'lucide-react';
import { sounds } from '../utils/audio';

interface SectionCase2Props {
  onNextSection: () => void;
  soundEnabled: boolean;
}

export const SectionCase2: React.FC<SectionCase2Props> = ({ onNextSection, soundEnabled }) => {
  const [showDiscussion, setShowDiscussion] = useState<boolean>(false);
  const [step, setStep] = useState<number>(0);

  // Warung C: 24 ml / 3 glasses = 8 ml/glass
  // Warung A: 40 ml / 6 glasses = 6.67 ml/glass
  const warungC = { name: 'Warung C', syrup: 24, glasses: 3, unit: 8, unitStr: '8 ml/gelas' };
  const warungA = { name: 'Warung A', syrup: 40, glasses: 6, unit: 40 / 6, unitStr: '6,67 ml/gelas' };

  const handleRevealDiscussion = () => {
    setShowDiscussion(true);
    sounds.playPourWater(soundEnabled, true, true);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  return (
    <div className="space-y-6">
      {/* Case Header Banner */}
      <div className="bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 border-4 border-slate-900 rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_#1e293b] text-white relative overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-slate-900 text-emerald-300 font-extrabold text-xs px-3 py-1 rounded-full border border-emerald-300 uppercase tracking-wider">
            STUDI KASUS 2
          </span>
          <span className="text-slate-900 font-extrabold text-xs flex items-center gap-1 bg-white/80 px-2 py-0.5 rounded-full">
            <Search className="w-3.5 h-3.5" /> Warung C vs Warung A
          </span>
        </div>

        <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-slate-900 leading-tight">
          Warung C datang menantang Warung A! 🍹
        </h2>
        <p className="text-slate-900 text-sm sm:text-base font-bold mt-1 max-w-2xl">
          Warung C menyajikan 24 ml sirup untuk 3 gelas air. Siapa yang lebih manis?
        </p>
      </div>

      {/* Visual Comparison Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Warung C */}
        <div className="comic-card bg-emerald-50 p-5 border-emerald-400 relative">
          <div className="absolute top-3 right-3 bg-emerald-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
            Resep Baru
          </div>

          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-emerald-400 rounded-2xl border-2 border-slate-900 flex items-center justify-center text-2xl">
              🥤
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                WARUNG C
              </h3>
              <p className="text-xs font-bold text-emerald-800">
                24 ml sirup untuk 3 gelas air
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border-2 border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-700">
              <span>Bahan: 24 ml Sirup</span>
              <span>Wadah: 3 Gelas Air</span>
            </div>

            <div
              className="grid grid-cols-3 gap-2 py-2 bg-emerald-100/50 rounded-lg p-2 border border-dashed border-emerald-300 cursor-pointer hover:bg-emerald-100 transition-colors"
              onClick={() => sounds.playPourWater(soundEnabled, true, true)}
              title="Klik untuk mendengar suara tuang sirup Warung C"
            >
              {[1, 2, 3].map((g) => (
                <SyrupGlassVisual key={g} syrupMl={8} glassNumber={g} size="sm" showMlBadge={false} />
              ))}
            </div>

            <div className="bg-emerald-100 p-2.5 rounded-lg border border-emerald-300 text-center font-bold text-xs text-emerald-900">
              Rasio Mula-Mula: <span className="text-emerald-700 font-black text-sm">24 ml : 3 gelas</span>
            </div>
          </div>
        </div>

        {/* Warung A (Reference) */}
        <div className="comic-card bg-amber-50 p-5 border-amber-400 relative">
          <div className="absolute top-3 right-3 bg-amber-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
            Pembanding
          </div>

          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-amber-400 rounded-2xl border-2 border-slate-900 flex items-center justify-center text-2xl">
              🏪
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                WARUNG A
              </h3>
              <p className="text-xs font-bold text-amber-800">
                40 ml sirup untuk 6 gelas air
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border-2 border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-700">
              <span>Bahan: 40 ml Sirup</span>
              <span>Wadah: 6 Gelas Air</span>
            </div>

            <div
              className="grid grid-cols-6 gap-1 py-2 bg-amber-100/50 rounded-lg p-2 border border-dashed border-amber-300 cursor-pointer hover:bg-amber-100 transition-colors"
              onClick={() => sounds.playPourWater(soundEnabled, true, true)}
              title="Klik untuk mendengar suara tuang sirup Warung A"
            >
              {[1, 2, 3, 4, 5, 6].map((g) => (
                <SyrupGlassVisual key={g} syrupMl={40 / 6} glassNumber={g} size="sm" showMlBadge={false} />
              ))}
            </div>

            <div className="bg-amber-100 p-2.5 rounded-lg border border-amber-300 text-center font-bold text-xs text-amber-900">
              Rasio Mula-Mula: <span className="text-rose-600 font-black text-sm">40 ml : 6 gelas</span>
            </div>
          </div>
        </div>
      </div>

      {/* Oral Question Box for Class Discussion */}
      <div className="comic-card bg-emerald-300 p-6 border-slate-900 text-center space-y-4">
        <div className="inline-flex items-center gap-2 bg-white px-4 py-1.5 rounded-full border-2 border-slate-900 text-xs font-extrabold text-slate-900 shadow-sm">
          <HelpCircle className="w-4 h-4 text-emerald-700" /> Pertanyaan Diskusi Lisan Guru
        </div>

        <h3 className="font-heading font-black text-2xl sm:text-3xl text-slate-900">
          "Dibanding Warung A, mana yang lebih manis?"
        </h3>

        <p className="text-slate-800 text-sm sm:text-base font-extrabold max-w-xl mx-auto">
          🗣️ Sampaikan pendapat kalian secara lisan! Hitung berapa ml sirup per 1 gelas untuk Warung C terlebih dahulu!
        </p>

        {!showDiscussion && (
          <div className="pt-2">
            <button
              onClick={handleRevealDiscussion}
              className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-8 py-3.5 text-lg font-black flex items-center gap-2 mx-auto shadow-[4px_4px_0px_#1e293b] animate-bounce"
            >
              <Calculator className="w-5 h-5" />
              Lihat Pembahasan
            </button>
          </div>
        )}
      </div>

      {/* Discussion Reveal Section */}
      {showDiscussion && (
        <div className="space-y-6 animate-fadeIn">
          {/* Interactive Division Visualizer */}
          <DivisionVisualizer
            shopAName="Warung C"
            shopASyrup={24}
            shopAGlasses={3}
            unitAStr="8 ml"
            unitAVal={8}
            colorA="emerald"
            shopBName="Warung A"
            shopBSyrup={40}
            shopBGlasses={6}
            unitBStr="6,67 ml"
            unitBVal={40 / 6}
            colorB="amber"
            winningShopName="Warung C"
            conclusionText="memiliki sirup per 1 gelas yang LEBIH BANYAK (8 ml > 6,67 ml), sehingga rasanya LEBIH MANIS!"
            soundEnabled={soundEnabled}
          />

          <div className="comic-card bg-cyan-100 p-6 border-cyan-500 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-cyan-400 border-2 border-slate-900 rounded-2xl text-2xl text-slate-900">
                🎉
              </div>
              <div>
                <span className="bg-cyan-600 text-white font-extrabold text-xs px-3 py-0.5 rounded-full uppercase">
                  Hasil Perhitungan & Kesimpulan
                </span>
                <h3 className="font-heading font-black text-2xl text-slate-900 mt-1">
                  Warung C Lebih Manis Dibanding Warung A!
                </h3>
              </div>
            </div>

            {/* Comparison Numbers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white p-4 rounded-xl border-2 border-slate-800 text-center">
              <div className="p-3 bg-emerald-100 rounded-lg border-2 border-emerald-500 relative">
                <span className="absolute -top-2.5 right-2 bg-emerald-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                  LEBIH MANIS!
                </span>
                <div className="text-xs font-bold text-emerald-800">Warung C</div>
                <div className="text-sm font-bold text-slate-600">24 ml ÷ 3 gelas</div>
                <div className="text-2xl font-black text-emerald-700 mt-1">8 ml / gelas</div>
              </div>

              <div className="p-3 bg-amber-50 rounded-lg border border-amber-300">
                <div className="text-xs font-bold text-amber-800">Warung A</div>
                <div className="text-sm font-bold text-slate-600">40 ml ÷ 6 gelas</div>
                <div className="text-2xl font-black text-amber-600 mt-1">6,67 ml / gelas</div>
              </div>
            </div>

            <p className="text-sm font-extrabold text-slate-800 bg-white p-3 rounded-lg border-2 border-slate-900 text-center">
              Kesimpulan: <span className="text-emerald-700 font-black">8 ml/gelas &gt; 6,67 ml/gelas</span> (Warung C lebih manis).
            </p>
          </div>

          {/* Next Button */}
          <div className="flex justify-end pt-2">
            <button
              onClick={onNextSection}
              className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-6 py-3 text-base sm:text-lg font-bold flex items-center gap-2 shadow-[4px_4px_0px_#1e293b]"
            >
              Lanjut ke Studi Kasus 3 (Warung D vs C)
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
