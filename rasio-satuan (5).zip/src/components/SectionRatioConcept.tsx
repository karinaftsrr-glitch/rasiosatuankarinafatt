import React, { useState } from 'react';
import { Sparkles, ArrowRight, BookOpen, Layers, CheckCircle } from 'lucide-react';

interface SectionRatioConceptProps {
  onNextSection: () => void;
}

export const SectionRatioConcept: React.FC<SectionRatioConceptProps> = ({ onNextSection }) => {
  const [activeTab, setActiveTab] = useState<'fruit' | 'supplies'>('fruit');

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-400 via-amber-300 to-amber-200 border-4 border-slate-900 rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_#1e293b] relative overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-rose-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900 uppercase tracking-wider">
            BAGIAN 1
          </span>
          <span className="text-slate-800 font-extrabold text-xs flex items-center gap-1">
            <BookOpen className="w-4 h-4 text-amber-700" /> Konsep Dasar
          </span>
        </div>
        <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-slate-900 leading-tight">
          Apa itu Rasio? 🔍
        </h2>
      </div>

      {/* Definition Box */}
      <div className="comic-card bg-amber-50 p-6 border-amber-400 relative overflow-hidden space-y-4">
        <div className="flex items-start gap-3">
          <div className="p-3 bg-amber-400 border-2 border-slate-900 rounded-2xl text-slate-900 text-2xl shrink-0">
            💡
          </div>
          <div>
            <h3 className="font-heading font-bold text-xl text-slate-900 mb-1">
              Apa itu Rasio?
            </h3>
            <p className="text-base sm:text-lg font-bold text-slate-800 leading-relaxed bg-white p-4 rounded-xl border-2 border-slate-800 shadow-sm">
              <span className="text-rose-600 font-extrabold">Rasio</span> adalah cara sederhana untuk <strong className="text-amber-800 underline decoration-amber-400 decoration-2">membandingkan dua jumlah benda</strong>.
            </p>
          </div>
        </div>

        {/* Highlighted Comparison Signs Box */}
        <div className="bg-white p-4 rounded-xl border-2 border-slate-900 space-y-3">
          <div className="font-heading font-black text-base sm:text-lg text-rose-600 flex items-center gap-2">
            <span className="bg-rose-500 text-white text-xs px-2.5 py-0.5 rounded-md border border-slate-900 uppercase">
              Penting!
            </span>
            Tanda Pembanding Rasio yang Harus Diketahui:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-rose-50 rounded-lg border-2 border-rose-300 text-center">
              <div className="text-2xl font-black text-rose-600 mb-0.5">:</div>
              <div className="text-xs font-bold text-slate-800">Tanda Titik Dua</div>
              <div className="text-[11px] font-semibold text-slate-600 mt-0.5">Contoh: <strong className="text-slate-900">3 : 2</strong></div>
            </div>

            <div className="p-3 bg-amber-50 rounded-lg border-2 border-amber-300 text-center">
              <div className="text-sm font-extrabold text-amber-800 mb-1">"berbanding"</div>
              <div className="text-xs font-bold text-slate-800">Kata Pembanding</div>
              <div className="text-[11px] font-semibold text-slate-600 mt-0.5">Dibaca: <strong className="text-slate-900">3 berbanding 2</strong></div>
            </div>

            <div className="p-3 bg-sky-50 rounded-lg border-2 border-sky-300 text-center">
              <div className="text-lg font-black text-sky-700 mb-0.5">a / b</div>
              <div className="text-xs font-bold text-slate-800">Bentuk Pecahan</div>
              <div className="text-[11px] font-semibold text-slate-600 mt-0.5">Ditulis: <strong className="text-slate-900">3/2</strong></div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Example Selector */}
      <div className="comic-card bg-white p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b-2 border-slate-200 pb-3">
          <div>
            <h3 className="font-heading font-bold text-lg text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" /> Contoh Visualisasi Rasio
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              Pilih contoh visualisasi untuk diperagakan kepada siswa:
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('fruit')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border-2 border-slate-800 transition ${
                activeTab === 'fruit'
                  ? 'bg-rose-500 text-white shadow-[2px_2px_0px_#1e293b]'
                  : 'bg-slate-100 hover:bg-amber-100 text-slate-800'
              }`}
            >
              🍎 Apel & Jeruk 🍊
            </button>
            <button
              onClick={() => setActiveTab('supplies')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border-2 border-slate-800 transition ${
                activeTab === 'supplies'
                  ? 'bg-sky-500 text-white shadow-[2px_2px_0px_#1e293b]'
                  : 'bg-slate-100 hover:bg-sky-100 text-slate-800'
              }`}
            >
              ✏️ Pensil & Buku 📚
            </button>
          </div>
        </div>

        {/* Content Display based on selected tab */}
        {activeTab === 'fruit' ? (
          <div className="bg-rose-50/80 rounded-2xl p-5 border-2 border-rose-300 space-y-4">
            <div className="text-center sm:text-left">
              <span className="bg-rose-200 text-rose-900 font-extrabold text-xs px-3 py-1 rounded-full border border-rose-400">
                Contoh 1: Buah Segar
              </span>
              <h4 className="font-heading font-bold text-xl text-slate-900 mt-2">
                Membandingkan Apel dan Jeruk
              </h4>
            </div>

            {/* Visual Container */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Group A: Apel */}
              <div className="comic-card-sm bg-white p-4 text-center">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-xs text-rose-700 bg-rose-100 px-2.5 py-0.5 rounded-full border border-rose-300">
                    Kelompok Apel
                  </span>
                  <span className="font-extrabold text-lg text-rose-600">3 Apel</span>
                </div>
                <div className="flex justify-center items-center gap-3 py-4 bg-rose-50 rounded-xl border border-dashed border-rose-300">
                  <div className="text-4xl sm:text-5xl animate-bounce hover:scale-125 transition">🍎</div>
                  <div className="text-4xl sm:text-5xl animate-bounce hover:scale-125 transition" style={{ animationDelay: '0.15s' }}>🍎</div>
                  <div className="text-4xl sm:text-5xl animate-bounce hover:scale-125 transition" style={{ animationDelay: '0.3s' }}>🍎</div>
                </div>
              </div>

              {/* Group B: Jeruk */}
              <div className="comic-card-sm bg-white p-4 text-center">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-xs text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">
                    Kelompok Jeruk
                  </span>
                  <span className="font-extrabold text-lg text-amber-600">2 Jeruk</span>
                </div>
                <div className="flex justify-center items-center gap-4 py-4 bg-amber-50 rounded-xl border border-dashed border-amber-300">
                  <div className="text-4xl sm:text-5xl animate-bounce hover:scale-125 transition" style={{ animationDelay: '0.2s' }}>🍊</div>
                  <div className="text-4xl sm:text-5xl animate-bounce hover:scale-125 transition" style={{ animationDelay: '0.4s' }}>🍊</div>
                </div>
              </div>
            </div>

            {/* Ratio Summary Card */}
            <div className="comic-card bg-amber-300 p-4 border-slate-900 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <p className="text-xs font-extrabold text-slate-800 uppercase tracking-wide">
                  Penulisan Rasio
                </p>
                <p className="font-heading font-extrabold text-xl text-slate-900">
                  Rasio Apel terhadap Jeruk adalah <span className="bg-white px-2.5 py-0.5 rounded-lg border-2 border-slate-900 text-rose-600">3 : 2</span>
                </p>
                <p className="text-xs font-semibold text-slate-800 mt-1">
                  Artinya: Untuk setiap <strong className="text-rose-700">3 buah Apel</strong>, terdapat <strong className="text-amber-800">2 buah Jeruk</strong>.
                </p>
              </div>

              <div className="bg-white p-3 rounded-xl border-2 border-slate-900 text-center shrink-0">
                <div className="text-2xl font-black text-rose-600">3 : 2</div>
                <div className="text-[10px] font-bold text-slate-600 uppercase">Apel : Jeruk</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-sky-50/80 rounded-2xl p-5 border-2 border-sky-300 space-y-4">
            <div className="text-center sm:text-left">
              <span className="bg-sky-200 text-sky-900 font-extrabold text-xs px-3 py-1 rounded-full border border-sky-400">
                Contoh 2: Alat Tulis
              </span>
              <h4 className="font-heading font-bold text-xl text-slate-900 mt-2">
                Membandingkan Pensil dan Buku
              </h4>
            </div>

            {/* Visual Container */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Group A: Pensil */}
              <div className="comic-card-sm bg-white p-4 text-center">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-xs text-sky-700 bg-sky-100 px-2.5 py-0.5 rounded-full border border-sky-300">
                    Kelompok Pensil
                  </span>
                  <span className="font-extrabold text-lg text-sky-600">4 Pensil</span>
                </div>
                <div className="flex justify-center items-center gap-2 py-4 bg-sky-50 rounded-xl border border-dashed border-sky-300">
                  <div className="text-3xl sm:text-4xl hover:scale-125 transition">✏️</div>
                  <div className="text-3xl sm:text-4xl hover:scale-125 transition">✏️</div>
                  <div className="text-3xl sm:text-4xl hover:scale-125 transition">✏️</div>
                  <div className="text-3xl sm:text-4xl hover:scale-125 transition">✏️</div>
                </div>
              </div>

              {/* Group B: Buku */}
              <div className="comic-card-sm bg-white p-4 text-center">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-xs text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">
                    Kelompok Buku
                  </span>
                  <span className="font-extrabold text-lg text-emerald-600">2 Buku</span>
                </div>
                <div className="flex justify-center items-center gap-4 py-4 bg-emerald-50 rounded-xl border border-dashed border-emerald-300">
                  <div className="text-3xl sm:text-4xl hover:scale-125 transition">📚</div>
                  <div className="text-3xl sm:text-4xl hover:scale-125 transition">📚</div>
                </div>
              </div>
            </div>

            {/* Ratio Summary Card */}
            <div className="comic-card bg-cyan-300 p-4 border-slate-900 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <p className="text-xs font-extrabold text-slate-800 uppercase tracking-wide">
                  Penulisan Rasio
                </p>
                <p className="font-heading font-extrabold text-xl text-slate-900">
                  Rasio Pensil terhadap Buku adalah <span className="bg-white px-2.5 py-0.5 rounded-lg border-2 border-slate-900 text-sky-600">4 : 2</span>
                </p>
                <p className="text-xs font-semibold text-slate-800 mt-1">
                  Dapat disederhanakan menjadi <strong className="text-sky-800">2 : 1</strong> (2 Pensil untuk setiap 1 Buku).
                </p>
              </div>

              <div className="bg-white p-3 rounded-xl border-2 border-slate-900 text-center shrink-0">
                <div className="text-2xl font-black text-sky-600">4 : 2</div>
                <div className="text-[10px] font-bold text-slate-600 uppercase">Pensil : Buku</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Next Step Navigation Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNextSection}
          className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-6 py-3 text-base sm:text-lg font-bold flex items-center gap-2 shadow-[4px_4px_0px_#1e293b]"
        >
          Lanjut ke Rasio Satuan
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
