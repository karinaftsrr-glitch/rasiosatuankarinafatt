import React, { useState } from 'react';
import { SectionRatioConcept } from './SectionRatioConcept';
import { SectionUnitRatioConcept } from './SectionUnitRatioConcept';
import {
  BookOpen,
  Calculator,
  Sparkles,
  Layers,
  ArrowRight,
  ArrowLeft,
  Bookmark,
  ChevronRight,
  ChevronLeft,
  GraduationCap,
  Pin,
  CheckCircle2,
} from 'lucide-react';

interface SectionBahanAjarProps {
  onNextToSimulation: () => void;
  soundEnabled?: boolean;
}

export const SectionBahanAjar: React.FC<SectionBahanAjarProps> = ({ onNextToSimulation, soundEnabled = true }) => {
  const [activeChapter, setActiveChapter] = useState<'ratio' | 'unit_ratio'>('ratio');

  const handleTurnToRatio = () => {
    setActiveChapter('ratio');
    window.scrollTo({ top: 180, behavior: 'smooth' });
  };

  const handleTurnToUnitRatio = () => {
    setActiveChapter('unit_ratio');
    window.scrollTo({ top: 180, behavior: 'smooth' });
  };

  return (
    <div className="space-y-4">
      {/* DESK ENVIRONMENT & REALISTIC BOOK WRAPPER */}
      <div className="relative pt-6 pb-2">
        {/* BOOKMARK TABS (TAB INDEKS BUKU) - Sticking out from the top edge */}
        <div className="flex items-end justify-between px-4 sm:px-8 relative z-20 -mb-1">
          {/* Chapter Tabs */}
          <div className="flex items-end gap-2 sm:gap-3">
            {/* Tab Bab 1 */}
            <button
              onClick={handleTurnToRatio}
              className={`group relative px-4 sm:px-6 py-2.5 sm:py-3 rounded-t-2xl font-heading font-black text-xs sm:text-sm border-t-3 border-x-3 border-slate-900 transition-all flex items-center gap-2 cursor-pointer ${
                activeChapter === 'ratio'
                  ? 'bg-[#fffdf8] text-slate-900 shadow-[0_-4px_10px_rgba(0,0,0,0.06)] translate-y-1 z-30 pb-4'
                  : 'bg-amber-200/90 hover:bg-amber-300 text-slate-700 hover:text-slate-900 translate-y-2'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 border border-slate-900" />
              <Bookmark className={`w-4 h-4 ${activeChapter === 'ratio' ? 'text-amber-600 fill-amber-500' : 'text-slate-500'}`} />
              <span>Bab 1: Konsep Rasio</span>
              <span className="text-[10px] font-black bg-slate-900 text-amber-300 px-1.5 py-0.2 rounded-full hidden sm:inline">
                Hal. 1
              </span>
            </button>

            {/* Tab Bab 2 */}
            <button
              onClick={handleTurnToUnitRatio}
              className={`group relative px-4 sm:px-6 py-2.5 sm:py-3 rounded-t-2xl font-heading font-black text-xs sm:text-sm border-t-3 border-x-3 border-slate-900 transition-all flex items-center gap-2 cursor-pointer ${
                activeChapter === 'unit_ratio'
                  ? 'bg-[#fffdf8] text-slate-900 shadow-[0_-4px_10px_rgba(0,0,0,0.06)] translate-y-1 z-30 pb-4'
                  : 'bg-sky-200/90 hover:bg-sky-300 text-slate-700 hover:text-slate-900 translate-y-2'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-sky-500 border border-slate-900" />
              <Calculator className={`w-4 h-4 ${activeChapter === 'unit_ratio' ? 'text-sky-600' : 'text-slate-500'}`} />
              <span>Bab 2: Rasio Satuan</span>
              <span className="text-[10px] font-black bg-slate-900 text-cyan-300 px-1.5 py-0.2 rounded-full hidden sm:inline">
                Hal. 2
              </span>
            </button>
          </div>

          {/* Right badge: Edition Info */}
          <div className="hidden md:flex items-center gap-1.5 text-[11px] font-extrabold text-slate-600 bg-amber-100/90 px-3 py-1 rounded-full border border-slate-400 mb-2">
            <GraduationCap className="w-3.5 h-3.5 text-slate-800" />
            <span>Buku Belajar Siswa • Matematika SD</span>
          </div>
        </div>

        {/* 3D BOOK HARDCOVER & PAGE STACK CONTAINER */}
        <div className="relative rounded-3xl bg-amber-950 p-3 sm:p-4 border-4 border-slate-900 shadow-[10px_10px_0px_#1e293b] ring-2 ring-amber-900/40">
          
          {/* HARDCOVER STITCHING LINE EFFECT */}
          <div className="absolute inset-2 border-2 border-dashed border-amber-600/40 rounded-2xl pointer-events-none" />

          {/* REALISTIC RED SILK BOOKMARK RIBBON (Pita Pembatas Buku) */}
          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 z-40 pointer-events-none flex flex-col items-center">
            <div className="w-6 sm:w-8 h-12 sm:h-14 bg-gradient-to-b from-rose-700 via-rose-600 to-rose-700 shadow-md border-x-2 border-t-2 border-slate-900 flex items-center justify-center relative">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              {/* Ribbon V-Notch Tail */}
              <div
                className="absolute -bottom-3 left-0 w-full h-3 bg-rose-700 border-b-2 border-slate-900"
                style={{
                  clipPath: 'polygon(0% 0%, 100% 0%, 50% 100%)',
                }}
              />
            </div>
          </div>

          {/* MULTI-PAGE STACK EFFECT (3D Paper Depth) */}
          <div className="relative rounded-2xl bg-[#f8f5ee] shadow-[0_4px_0_#eae5d8,0_8px_0_#dcd5c4,0_12px_0_#cecaa4] border-3 border-slate-900">
            
            {/* SPIRAL RING BINDER AT THE TOP */}
            <div className="w-full bg-gradient-to-r from-amber-100 via-slate-200 to-amber-100 border-b-3 border-slate-900 py-2 sm:py-2.5 px-6 sm:px-12 flex items-center justify-between rounded-t-2xl shadow-inner relative overflow-hidden">
              <div className="flex items-center gap-4 sm:gap-6 w-full justify-around">
                {Array.from({ length: 14 }).map((_, i) => (
                  <div key={i} className="flex flex-col items-center">
                    {/* Ring Hole */}
                    <div className="w-3 h-3 rounded-full bg-slate-800 border-2 border-slate-900 shadow-inner" />
                    {/* Metallic Ring Coil */}
                    <div className="w-2 sm:w-2.5 h-5 -mt-1 rounded-sm bg-gradient-to-r from-slate-300 via-white to-slate-400 border border-slate-800 shadow-sm" />
                  </div>
                ))}
              </div>
            </div>

            {/* MAIN BOOK PAGE (IVORY / CREAM PARCHMENT PAPER) */}
            <div className="bg-[#fffdf9] p-5 sm:p-8 rounded-b-2xl relative min-h-[500px]">
              
              {/* NOTEBOOK RED MARGIN GUIDE LINE (Garis Tepi Buku Catatan) */}
              <div className="hidden sm:block absolute top-0 bottom-0 left-12 w-0.5 bg-rose-400/30 pointer-events-none" />

              {/* BOOK PAGE HEADER (Kepala Halaman Buku) */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-slate-200 pb-3 mb-6 sm:pl-8">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-amber-100 border border-slate-800 rounded-lg">
                    <BookOpen className="w-4 h-4 text-amber-800" />
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                      BUKU PINTAR MATEMATIKA • RASIOKU
                    </span>
                    <h2 className="font-heading font-black text-sm sm:text-base text-slate-800">
                      {activeChapter === 'ratio'
                        ? 'BAB 1 : MEMAHAMI KONSEP RASIO'
                        : 'BAB 2 : MENENTUKAN RASIO SATUAN'}
                    </h2>
                  </div>
                </div>

                {/* Page Number Stamp */}
                <div className="flex items-center gap-2">
                  <div className="bg-amber-50 border-2 border-slate-800 px-3 py-1 rounded-xl text-xs font-black text-slate-800 shadow-[2px_2px_0px_#1e293b]">
                    📖 Halaman {activeChapter === 'ratio' ? '1 dari 2' : '2 dari 2'}
                  </div>
                </div>
              </div>

              {/* STICKY POST-IT NOTE (CATATAN TEMPEL DI DALAM BUKU) */}
              <div className="comic-card bg-yellow-100/90 border-2 border-amber-400 p-3.5 rounded-xl shadow-[3px_3px_0px_#1e293b] mb-6 sm:ml-8 flex items-start gap-3 transform -rotate-0.5">
                <div className="p-1.5 bg-amber-400 rounded-lg border border-slate-900 text-slate-900 shrink-0 mt-0.5">
                  <Pin className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1 text-xs sm:text-sm font-bold text-slate-800 leading-relaxed">
                  <span className="font-black text-slate-900">Catatan Belajar Siswa: </span>
                  {activeChapter === 'ratio'
                    ? 'Baca penjelasan di bawah ini perlahan-lahan. Kamu bisa mencoba kedua contoh interaktif (Apel & Pensil) untuk memahaminya secara visual!'
                    : 'Setelah memahami rasio satuan di halaman ini, kamu bisa langsung mencoba tombol "Tutup Buku & Lanjut ke Lab Simulasi" di bagian bawah!'}
                </div>
              </div>

              {/* BOOK PAGE CHAPTER CONTENT */}
              <div className="sm:pl-8 space-y-6">
                {activeChapter === 'ratio' ? (
                  <SectionRatioConcept onNextSection={handleTurnToUnitRatio} />
                ) : (
                  <SectionUnitRatioConcept
                    onNextSection={onNextToSimulation}
                    soundEnabled={soundEnabled}
                  />
                )}
              </div>

              {/* BOOK FOOTER: REALISTIC PAGE-TURN CONTROLS */}
              <div className="mt-10 pt-5 border-t-2 border-dashed border-slate-300 flex flex-col sm:flex-row items-center justify-between gap-4 sm:pl-8">
                {/* Left Page Turn Button */}
                {activeChapter === 'unit_ratio' ? (
                  <button
                    onClick={handleTurnToRatio}
                    className="comic-button bg-white hover:bg-amber-50 text-slate-900 px-4 py-2.5 text-xs sm:text-sm font-black flex items-center gap-2 shadow-[3px_3px_0px_#1e293b] w-full sm:w-auto justify-center"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>◀ Balik ke Bab 1: Konsep Rasio</span>
                  </button>
                ) : (
                  <div className="text-xs font-extrabold text-slate-500 italic hidden sm:block">
                    Halaman pertama dari Bahan Ajar
                  </div>
                )}

                {/* Right Page Turn Button */}
                {activeChapter === 'ratio' ? (
                  <button
                    onClick={handleTurnToUnitRatio}
                    className="comic-button bg-amber-400 hover:bg-amber-500 text-slate-900 px-5 py-2.5 text-xs sm:text-sm font-black flex items-center gap-2 shadow-[3px_3px_0px_#1e293b] w-full sm:w-auto justify-center"
                  >
                    <span>Buka Bab 2: Rasio Satuan</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={onNextToSimulation}
                    className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-5 py-2.5 text-xs sm:text-sm font-black flex items-center gap-2 shadow-[3px_3px_0px_#1e293b] w-full sm:w-auto justify-center"
                  >
                    <span>Tutup Buku & Lanjut ke Lab Simulasi 🧪</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
