import React from 'react';

interface GameVisualIllustrationProps {
  questionId: string;
  showCalculations?: boolean;
}

export const GameVisualIllustration: React.FC<GameVisualIllustrationProps> = ({
  questionId,
  showCalculations = false,
}) => {
  switch (questionId) {
    // ----------------------------------------------------
    // LOW-1: Minyak Goreng Merek A (2L / Rp 28rb) vs Merek B (3L / Rp 45rb)
    // ----------------------------------------------------
    case 'low-1':
      return (
        <div className="bg-gradient-to-b from-amber-50 to-yellow-100 border-3 border-slate-900 rounded-2xl p-4 sm:p-5 shadow-[4px_4px_0px_#1e293b]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-amber-300 pb-2 mb-3">
            <span className="text-xs font-black bg-slate-900 text-amber-300 px-3 py-1 rounded-full border border-amber-300 flex items-center gap-1.5">
              <span>🍳 Komparasi Minyak Goreng Swalayan</span>
            </span>
            <span className="text-xs font-black bg-emerald-600 text-white px-3 py-1 rounded-full border border-slate-900 flex items-center gap-1.5">
              <span>🎯 Cari yang Paling Murah per Liter</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Merek A */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between border-b-2 border-amber-100 pb-2 mb-2">
                <span className="text-xs font-black bg-amber-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Merek A (2 Liter)
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 28.000,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Bottle graphic */}
                <div className="flex flex-col items-center">
                  <div className="w-14 h-22 bg-gradient-to-t from-amber-400 to-yellow-300 border-2 border-slate-900 rounded-b-2xl rounded-t-lg relative flex flex-col items-center justify-center shadow-md">
                    <div className="w-5 h-3 bg-red-500 border border-slate-900 rounded-t-sm -mt-1" />
                    <span className="text-xl my-0.5">🌻</span>
                    <span className="bg-slate-900/80 text-white text-[9px] font-black px-1 rounded">2 Liter</span>
                    <span className="text-[10px] text-amber-900 font-extrabold mt-0.5">Minyak Kelapa Sawit</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-xs font-black text-slate-700 mb-1">Kemasan 2 Liter</span>
                  <div className="flex gap-1.5">
                    <div className="w-7 h-11 bg-amber-200 border border-slate-900 rounded flex items-center justify-center text-[9px] font-black">1 L</div>
                    <div className="w-7 h-11 bg-amber-200 border border-slate-900 rounded flex items-center justify-center text-[9px] font-black">1 L</div>
                  </div>
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-emerald-50 border border-emerald-300 rounded-lg p-2 text-center text-xs font-extrabold text-emerald-900 animate-fadeIn">
                  Rumus: Rp 28.000 ÷ 2 Liter = <span className="font-black text-emerald-700">Rp 14.000 / Liter</span>
                </div>
              ) : (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-2 text-center text-xs font-bold text-amber-900 flex items-center justify-center gap-1.5">
                  <span>💭 Berapa harga satuan per 1 Liter?</span>
                </div>
              )}
            </div>

            {/* Merek B */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between border-b-2 border-amber-100 pb-2 mb-2">
                <span className="text-xs font-black bg-yellow-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Merek B (3 Liter)
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 45.000,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Jerigen graphic */}
                <div className="flex flex-col items-center">
                  <div className="w-18 h-22 bg-gradient-to-t from-amber-500 to-yellow-400 border-2 border-slate-900 rounded-b-xl rounded-t-lg relative flex flex-col items-center justify-center shadow-md">
                    <div className="w-6 h-3 bg-blue-600 border border-slate-900 rounded-t-sm -mt-1" />
                    <span className="text-xl my-0.5">🌽</span>
                    <span className="bg-slate-900/80 text-white text-[9px] font-black px-1 rounded">3 Liter</span>
                    <span className="text-[10px] text-amber-900 font-extrabold mt-0.5">Kemasan Jerigen</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-xs font-black text-slate-700 mb-1">Kemasan 3 Liter</span>
                  <div className="flex gap-1">
                    <div className="w-6 h-11 bg-amber-200 border border-slate-900 rounded flex items-center justify-center text-[9px] font-black">1 L</div>
                    <div className="w-6 h-11 bg-amber-200 border border-slate-900 rounded flex items-center justify-center text-[9px] font-black">1 L</div>
                    <div className="w-6 h-11 bg-amber-200 border border-slate-900 rounded flex items-center justify-center text-[9px] font-black">1 L</div>
                  </div>
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-amber-50 border border-amber-300 rounded-lg p-2 text-center text-xs font-extrabold text-amber-900 animate-fadeIn">
                  Rumus: Rp 45.000 ÷ 3 Liter = <span className="font-black text-slate-800">Rp 15.000 / Liter</span>
                </div>
              ) : (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-2 text-center text-xs font-bold text-amber-900 flex items-center justify-center gap-1.5">
                  <span>💭 Berapa harga satuan per 1 Liter?</span>
                </div>
              )}
            </div>
          </div>
        </div>
      );

    // ----------------------------------------------------
    // LOW-2: Sabun Cuci Piring (Pouch 400ml Rp 8rb vs Botol 500ml Rp 12.5rb)
    // ----------------------------------------------------
    case 'low-2':
      return (
        <div className="bg-gradient-to-b from-lime-50 to-emerald-100 border-3 border-slate-900 rounded-2xl p-4 sm:p-5 shadow-[4px_4px_0px_#1e293b]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-lime-300 pb-2 mb-3">
            <span className="text-xs font-black bg-slate-900 text-lime-300 px-3 py-1 rounded-full border border-lime-300 flex items-center gap-1.5">
              <span>🍋 Sabun Cuci Piring Ekstrak Jeruk Nipis</span>
            </span>
            <span className="text-xs font-black bg-emerald-600 text-white px-3 py-1 rounded-full border border-slate-900 flex items-center gap-1.5">
              <span>🍽️ Bandingkan Harga per 1 ml</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Pouch Isi Ulang */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between border-b-2 border-lime-100 pb-2 mb-2">
                <span className="text-xs font-black bg-lime-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Pouch Isi Ulang 🌿
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 8.000,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Pouch Graphic */}
                <div className="flex flex-col items-center">
                  <div className="w-16 h-22 bg-gradient-to-t from-emerald-500 via-lime-400 to-lime-200 border-2 border-slate-900 rounded-b-xl rounded-t-3xl relative flex flex-col items-center justify-center shadow-md">
                    <div className="w-4 h-2 bg-emerald-800 border border-slate-900 rounded-t-sm -mt-1" />
                    <span className="text-lg">🍋</span>
                    <span className="bg-slate-900/80 text-white text-[9px] font-black px-1.5 py-0.5 rounded">400 ml</span>
                    <span className="text-[9px] text-emerald-900 font-extrabold mt-0.5">Busa Melimpah</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-2xl mb-1">✨🍽️</span>
                  <span className="text-[11px] font-extrabold text-slate-700">Volume: 400 ml</span>
                  <span className="text-[10px] font-bold text-slate-500">Hemat Plastik</span>
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-lime-50 border border-lime-300 rounded-lg p-2 text-center text-xs font-extrabold text-lime-900 animate-fadeIn">
                  Rumus: Rp 8.000 ÷ 400 ml = <span className="font-black text-emerald-700">Rp 20 / ml</span>
                </div>
              ) : (
                <div className="bg-lime-50 border border-lime-200 rounded-lg p-2 text-center text-xs font-bold text-lime-900 flex items-center justify-center gap-1.5">
                  <span>💭 Berapa harga satuan per 1 ml?</span>
                </div>
              )}
            </div>

            {/* Botol Pompa */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between border-b-2 border-lime-100 pb-2 mb-2">
                <span className="text-xs font-black bg-yellow-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Botol Pompa 🧴
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 12.500,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Pump Bottle Graphic */}
                <div className="flex flex-col items-center">
                  <div className="w-14 h-22 bg-gradient-to-t from-lime-400 via-yellow-300 to-yellow-100 border-2 border-slate-900 rounded-b-2xl rounded-t-lg relative flex flex-col items-center justify-center shadow-md">
                    {/* Pump Head */}
                    <div className="w-3 h-3 bg-white border border-slate-900 -mt-2" />
                    <div className="w-6 h-1.5 bg-slate-800 rounded -mt-0.5" />
                    <span className="text-lg">🫧</span>
                    <span className="bg-slate-900/80 text-white text-[9px] font-black px-1.5 py-0.5 rounded">500 ml</span>
                    <span className="text-[9px] text-yellow-900 font-extrabold mt-0.5">Dengan Dispenser</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-2xl mb-1">🧴🧼</span>
                  <span className="text-[11px] font-extrabold text-slate-700">Volume: 500 ml</span>
                  <span className="text-[10px] font-bold text-slate-500">Kemasan Dispenser</span>
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-yellow-50 border border-yellow-300 rounded-lg p-2 text-center text-xs font-extrabold text-yellow-900 animate-fadeIn">
                  Rumus: Rp 12.500 ÷ 500 ml = <span className="font-black text-slate-800">Rp 25 / ml</span>
                </div>
              ) : (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-2 text-center text-xs font-bold text-yellow-900 flex items-center justify-center gap-1.5">
                  <span>💭 Berapa harga satuan per 1 ml?</span>
                </div>
              )}
            </div>
          </div>
        </div>
      );

    // ----------------------------------------------------
    // MED-1: Es Sirup Manis (Teko Melati 30ml/5 vs Teko Mawar 32ml/4)
    // ----------------------------------------------------
    case 'med-1':
      return (
        <div className="bg-gradient-to-b from-rose-50 to-pink-100 border-3 border-slate-900 rounded-2xl p-4 sm:p-5 shadow-[4px_4px_0px_#1e293b]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-rose-300 pb-2 mb-3">
            <span className="text-xs font-black bg-slate-900 text-rose-300 px-3 py-1 rounded-full border border-rose-300 flex items-center gap-1.5">
              <span>🍹 Duel Kepekatan Rasa Es Sirup</span>
            </span>
            <span className="text-xs font-black bg-rose-600 text-white px-3 py-1 rounded-full border border-slate-900 flex items-center gap-1.5">
              <span>👅 Makin Banyak Sirup per Gelas = Makin Manis!</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Teko Melati */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative">
              <div className="flex items-center justify-between border-b-2 border-slate-100 pb-2 mb-2">
                <span className="text-xs font-black bg-pink-300 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Teko Melati 🌸
                </span>
                <span className="text-xs font-black text-pink-700 bg-pink-50 px-2 py-0.5 rounded border border-pink-200">
                  30 ml dalam 5 Gelas
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Pitcher */}
                <div className="flex flex-col items-center">
                  <div className="w-13 h-16 bg-gradient-to-t from-rose-400 to-pink-200 border-2 border-slate-900 rounded-b-2xl rounded-t-md relative flex items-center justify-center shadow-sm">
                    <span className="text-xs font-black text-white bg-slate-900/70 px-1 rounded">30 ml</span>
                  </div>
                  <span className="text-[10px] font-extrabold text-slate-600 mt-1">Teko Kaca 5 Gelas</span>
                </div>

                <span className="text-lg font-black text-slate-400">➡️</span>

                {/* 5 Glasses */}
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((g) => (
                    <div
                      key={g}
                      className="w-5 h-9 bg-gradient-to-t from-rose-300 to-rose-100 border border-slate-900 rounded-b-md flex items-end justify-center pb-0.5 shadow-xs"
                      title="Gelas Melati"
                    >
                      <span className="text-[8px]">🧊</span>
                    </div>
                  ))}
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-pink-50 border border-pink-200 rounded-lg p-2 text-center text-xs font-extrabold text-pink-900 animate-fadeIn">
                  Rasio: 30 ml ÷ 5 gelas = <span className="font-black text-slate-900">6 ml / gelas</span>
                </div>
              ) : (
                <div className="bg-pink-50 border border-pink-200 rounded-lg p-2 text-center text-xs font-bold text-pink-900 flex items-center justify-center gap-1.5">
                  <span>🍹 Berapa ml sirup untuk tiap 1 gelas?</span>
                </div>
              )}
            </div>

            {/* Teko Mawar */}
            <div className={`bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative ${showCalculations ? 'ring-2 ring-rose-400' : ''}`}>
              <div className="flex items-center justify-between border-b-2 border-slate-100 pb-2 mb-2">
                <span className="text-xs font-black bg-rose-500 text-white px-2.5 py-0.5 rounded-full border border-slate-900">
                  Teko Mawar 🌹 {showCalculations && '(Lebih Manis)'}
                </span>
                <span className="text-xs font-black text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  32 ml dalam 4 Gelas
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Pitcher */}
                <div className="flex flex-col items-center">
                  <div className="w-13 h-16 bg-gradient-to-t from-red-600 to-rose-400 border-2 border-slate-900 rounded-b-2xl rounded-t-md relative flex items-center justify-center shadow-sm">
                    <span className="text-xs font-black text-white bg-slate-900/70 px-1 rounded">32 ml</span>
                  </div>
                  <span className="text-[10px] font-extrabold text-slate-600 mt-1">Teko Kaca 4 Gelas</span>
                </div>

                <span className="text-lg font-black text-slate-400">➡️</span>

                {/* 4 Glasses with deeper red */}
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 4].map((g) => (
                    <div
                      key={g}
                      className="w-5 h-9 bg-gradient-to-t from-red-500 to-rose-300 border border-slate-900 rounded-b-md flex items-end justify-center pb-0.5 shadow-xs"
                      title="Gelas Mawar"
                    >
                      <span className="text-[8px]">🧊</span>
                    </div>
                  ))}
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-rose-50 border border-rose-300 rounded-lg p-2 text-center text-xs font-extrabold text-rose-900 animate-fadeIn">
                  Rasio: 32 ml ÷ 4 gelas = <span className="font-black text-rose-700">8 ml / gelas (Paling Manis!)</span>
                </div>
              ) : (
                <div className="bg-rose-50 border border-rose-200 rounded-lg p-2 text-center text-xs font-bold text-rose-900 flex items-center justify-center gap-1.5">
                  <span>🍹 Berapa ml sirup untuk tiap 1 gelas?</span>
                </div>
              )}
            </div>
          </div>
        </div>
      );

    // ----------------------------------------------------
    // MED-2: Beras Berkualitas (Karung 5 kg Rp 65rb vs Karung 10 kg Rp 140rb)
    // ----------------------------------------------------
    case 'med-2':
      return (
        <div className="bg-gradient-to-b from-amber-50 to-orange-100 border-3 border-slate-900 rounded-2xl p-4 sm:p-5 shadow-[4px_4px_0px_#1e293b]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-amber-300 pb-2 mb-3">
            <span className="text-xs font-black bg-slate-900 text-amber-300 px-3 py-1 rounded-full border border-amber-300 flex items-center gap-1.5">
              <span>🌾 Toko Beras Pulen Super</span>
            </span>
            <span className="text-xs font-black bg-emerald-600 text-white px-3 py-1 rounded-full border border-slate-900 flex items-center gap-1.5">
              <span>⚖️ Cek Harga Satuan per 1 kg</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Karung 5 kg */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between border-b-2 border-amber-100 pb-2 mb-2">
                <span className="text-xs font-black bg-amber-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Karung Sedang (5 kg)
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 65.000,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Rice Sack 5 kg Graphic */}
                <div className="flex flex-col items-center">
                  <div className="w-16 h-20 bg-gradient-to-t from-amber-300 to-amber-100 border-2 border-slate-900 rounded-b-xl rounded-t-lg relative flex flex-col items-center justify-center shadow-md">
                    <span className="text-lg">🌾</span>
                    <span className="bg-slate-900 text-amber-300 text-[10px] font-black px-1.5 py-0.5 rounded">5 KG</span>
                    <span className="text-[9px] text-amber-900 font-extrabold mt-0.5">Pandan Wangi</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-2xl mb-1">🍚✨</span>
                  <span className="text-xs font-black text-slate-700">Kemasan 5 kg</span>
                  {showCalculations && (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 mt-1 animate-fadeIn">
                      Lebih Murah per kg!
                    </span>
                  )}
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-amber-50 border border-amber-300 rounded-lg p-2 text-center text-xs font-extrabold text-amber-900 animate-fadeIn">
                  Rasio Satuan: Rp 65.000 ÷ 5 kg = <span className="font-black text-emerald-700">Rp 13.000 / kg</span>
                </div>
              ) : (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-2 text-center text-xs font-bold text-amber-900 flex items-center justify-center gap-1.5">
                  <span>🌾 Hitung: Berapa harga per 1 kg?</span>
                </div>
              )}
            </div>

            {/* Karung 10 kg */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between border-b-2 border-amber-100 pb-2 mb-2">
                <span className="text-xs font-black bg-orange-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Karung Besar (10 kg)
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 140.000,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Rice Sack 10 kg Graphic */}
                <div className="flex flex-col items-center">
                  <div className="w-20 h-22 bg-gradient-to-t from-orange-300 to-amber-100 border-2 border-slate-900 rounded-b-xl rounded-t-lg relative flex flex-col items-center justify-center shadow-md">
                    <span className="text-xl">🌾</span>
                    <span className="bg-slate-900 text-amber-300 text-[10px] font-black px-1.5 py-0.5 rounded">10 KG</span>
                    <span className="text-[9px] text-amber-900 font-extrabold mt-0.5">Rojolele Super</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-2xl mb-1">🍚📦</span>
                  <span className="text-xs font-black text-slate-700">Kemasan 10 kg</span>
                  <span className="text-[10px] font-bold text-slate-500 mt-1">Kemasan Ekstra Besar</span>
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-orange-50 border border-orange-300 rounded-lg p-2 text-center text-xs font-extrabold text-orange-900 animate-fadeIn">
                  Rasio Satuan: Rp 140.000 ÷ 10 kg = <span className="font-black text-slate-800">Rp 14.000 / kg</span>
                </div>
              ) : (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-2 text-center text-xs font-bold text-orange-900 flex items-center justify-center gap-1.5">
                  <span>🌾 Hitung: Berapa harga per 1 kg?</span>
                </div>
              )}
            </div>
          </div>
        </div>
      );

    // ----------------------------------------------------
    // HIGH-1: Deterjen Mesin Cuci (Mawar 15x / Rp 30rb vs Melati 20x / Rp 36rb)
    // ----------------------------------------------------
    case 'high-1':
      return (
        <div className="bg-gradient-to-b from-sky-50 to-blue-100 border-3 border-slate-900 rounded-2xl p-4 sm:p-5 shadow-[4px_4px_0px_#1e293b]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-sky-300 pb-2 mb-3">
            <span className="text-xs font-black bg-slate-900 text-sky-300 px-3 py-1 rounded-full border border-sky-300 flex items-center gap-1.5">
              <span>🧺 Deterjen Cair Mesin Cuci</span>
            </span>
            <span className="text-xs font-black bg-emerald-600 text-white px-3 py-1 rounded-full border border-slate-900 flex items-center gap-1.5">
              <span>🧼 Hitung Biaya Satuan per 1 Kali Mencuci</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Mawar Wangi */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between border-b-2 border-sky-100 pb-2 mb-2">
                <span className="text-xs font-black bg-rose-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Mawar Wangi 🌹
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 30.000,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Bottle */}
                <div className="flex flex-col items-center">
                  <div className="w-14 h-20 bg-gradient-to-t from-rose-500 to-pink-300 border-2 border-slate-900 rounded-b-2xl rounded-t-md relative flex flex-col items-center justify-center shadow-md">
                    <div className="w-5 h-2.5 bg-white border border-slate-900 rounded-t-sm -mt-1" />
                    <span className="text-base">🫧</span>
                    <span className="bg-slate-900/80 text-white text-[9px] font-black px-1 rounded">15x Cuci</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-2xl mb-1">👕👗</span>
                  <span className="text-xs font-black text-slate-700">Untuk 15x Cuci</span>
                  <span className="text-[10px] font-bold text-slate-500 mt-1">Kemasan Botol</span>
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-rose-50 border border-rose-300 rounded-lg p-2 text-center text-xs font-extrabold text-rose-900 animate-fadeIn">
                  Biaya: Rp 30.000 ÷ 15 = <span className="font-black text-slate-800">Rp 2.000 / cuci</span>
                </div>
              ) : (
                <div className="bg-rose-50 border border-rose-200 rounded-lg p-2 text-center text-xs font-bold text-rose-900 flex items-center justify-center gap-1.5">
                  <span>🧺 Hitung: Berapa biaya 1x cuci?</span>
                </div>
              )}
            </div>

            {/* Melati Segar */}
            <div className={`bg-white border-2 border-slate-900 rounded-xl p-3.5 flex flex-col justify-between shadow-sm relative overflow-hidden ${showCalculations ? 'ring-2 ring-sky-400' : ''}`}>
              <div className="flex items-center justify-between border-b-2 border-sky-100 pb-2 mb-2">
                <span className="text-xs font-black bg-sky-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900">
                  Melati Segar 🌸 {showCalculations && '(Paling Irit)'}
                </span>
                <span className="text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  Rp 36.000,00
                </span>
              </div>

              <div className="flex items-center justify-around gap-2 my-2">
                {/* Pouch */}
                <div className="flex flex-col items-center">
                  <div className="w-16 h-20 bg-gradient-to-t from-blue-500 to-sky-300 border-2 border-slate-900 rounded-b-xl rounded-t-2xl relative flex flex-col items-center justify-center shadow-md">
                    <div className="w-4 h-2 bg-blue-900 border border-slate-900 rounded-t-sm -mt-1" />
                    <span className="text-base">✨</span>
                    <span className="bg-slate-900/80 text-white text-[9px] font-black px-1 rounded">20x Cuci</span>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <span className="text-2xl mb-1">🧼🧺</span>
                  <span className="text-xs font-black text-slate-700">Untuk 20x Cuci</span>
                  {showCalculations && (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 mt-1 animate-fadeIn">
                      Hemat Rp 200/cuci!
                    </span>
                  )}
                </div>
              </div>

              {showCalculations ? (
                <div className="bg-sky-50 border border-sky-300 rounded-lg p-2 text-center text-xs font-extrabold text-sky-900 animate-fadeIn">
                  Biaya: Rp 36.000 ÷ 20 = <span className="font-black text-emerald-700">Rp 1.800 / cuci (Paling Irit!)</span>
                </div>
              ) : (
                <div className="bg-sky-50 border border-sky-200 rounded-lg p-2 text-center text-xs font-bold text-sky-900 flex items-center justify-center gap-1.5">
                  <span>🧺 Hitung: Berapa biaya 1x cuci?</span>
                </div>
              )}
            </div>
          </div>
        </div>
      );

    // ----------------------------------------------------
    // HIGH-2: Tiga Resep Sirup Buah (Jeruk, Cocopandan, Mangga)
    // ----------------------------------------------------
    case 'high-2':
      return (
        <div className="bg-gradient-to-b from-orange-50 via-rose-50 to-amber-50 border-3 border-slate-900 rounded-2xl p-4 sm:p-5 shadow-[4px_4px_0px_#1e293b]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-amber-300 pb-2 mb-3">
            <span className="text-xs font-black bg-slate-900 text-amber-300 px-3 py-1 rounded-full border border-amber-300 flex items-center gap-1.5">
              <span>🍹 Uji 3 Resep Sirup Buah Spesial</span>
            </span>
            <span className="text-xs font-black bg-rose-600 text-white px-3 py-1 rounded-full border border-slate-900 flex items-center gap-1.5">
              <span>👑 Urutkan dari yang Paling Manis (ml Terbanyak)</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Jeruk */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3 flex flex-col items-center text-center shadow-sm">
              <span className="text-xs font-black bg-orange-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900 mb-2">
                1. Sirup Jeruk 🍊
              </span>

              {/* Glass */}
              <div className="w-13 h-20 bg-gradient-to-t from-orange-400 to-amber-100 border-2 border-slate-900 rounded-b-xl relative flex flex-col items-center justify-center my-1 shadow-sm">
                <span className="text-base">🧊🍊</span>
                <span className="text-[9px] font-black text-slate-900 bg-white/80 px-1 rounded mt-1">25 ml / 4</span>
              </div>

              <span className="text-xs font-extrabold text-slate-700 mt-1">25 ml dalam 4 Gelas</span>
              {showCalculations ? (
                <div className="mt-1 flex flex-col items-center animate-fadeIn">
                  <span className="text-xs font-black text-orange-700 bg-orange-50 px-2 py-0.5 rounded border border-orange-200">
                    = 6,25 ml / gelas
                  </span>
                  <span className="text-[10px] font-bold text-slate-500 mt-0.5">(Paling Kurang Manis)</span>
                </div>
              ) : (
                <span className="text-[11px] font-bold text-slate-600 bg-orange-50 px-2 py-1 rounded border border-orange-200 mt-2">
                  ❓ ... ml / gelas
                </span>
              )}
            </div>

            {/* Cocopandan */}
            <div className={`bg-white border-2 border-slate-900 rounded-xl p-3 flex flex-col items-center text-center shadow-sm ${showCalculations ? 'ring-2 ring-rose-500' : ''}`}>
              <span className="text-xs font-black bg-rose-500 text-white px-2.5 py-0.5 rounded-full border border-slate-900 mb-2">
                2. Cocopandan 🥥 {showCalculations && '(Juara 1)'}
              </span>

              {/* Glass with deep red */}
              <div className="w-13 h-20 bg-gradient-to-t from-red-600 via-rose-500 to-rose-200 border-2 border-slate-900 rounded-b-xl relative flex flex-col items-center justify-center my-1 shadow-sm">
                <span className="text-base">🧊🥥</span>
                <span className="text-[9px] font-black text-white bg-slate-900/80 px-1 rounded mt-1">36 ml / 4</span>
              </div>

              <span className="text-xs font-extrabold text-slate-700 mt-1">36 ml dalam 4 Gelas</span>
              {showCalculations ? (
                <div className="mt-1 flex flex-col items-center animate-fadeIn">
                  <span className="text-xs font-black text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                    = 9 ml / gelas ⭐
                  </span>
                  <span className="text-[10px] font-black text-rose-600 mt-0.5">Paling Manis!</span>
                </div>
              ) : (
                <span className="text-[11px] font-bold text-slate-600 bg-rose-50 px-2 py-1 rounded border border-rose-200 mt-2">
                  ❓ ... ml / gelas
                </span>
              )}
            </div>

            {/* Mangga */}
            <div className="bg-white border-2 border-slate-900 rounded-xl p-3 flex flex-col items-center text-center shadow-sm">
              <span className="text-xs font-black bg-yellow-400 text-slate-900 px-2.5 py-0.5 rounded-full border border-slate-900 mb-2">
                3. Sirup Mangga 🥭
              </span>

              {/* Glass with yellow mango */}
              <div className="w-13 h-20 bg-gradient-to-t from-amber-500 to-yellow-200 border-2 border-slate-900 rounded-b-xl relative flex flex-col items-center justify-center my-1 shadow-sm">
                <span className="text-base">🧊🥭</span>
                <span className="text-[9px] font-black text-slate-900 bg-white/80 px-1 rounded mt-1">35 ml / 5</span>
              </div>

              <span className="text-xs font-extrabold text-slate-700 mt-1">35 ml dalam 5 Gelas</span>
              {showCalculations ? (
                <div className="mt-1 flex flex-col items-center animate-fadeIn">
                  <span className="text-xs font-black text-amber-800 bg-yellow-50 px-2 py-0.5 rounded border border-yellow-200">
                    = 7 ml / gelas
                  </span>
                  <span className="text-[10px] font-bold text-slate-600 mt-0.5">(Manis Sedang)</span>
                </div>
              ) : (
                <span className="text-[11px] font-bold text-slate-600 bg-yellow-50 px-2 py-1 rounded border border-yellow-200 mt-2">
                  ❓ ... ml / gelas
                </span>
              )}
            </div>
          </div>
        </div>
      );

    default:
      return null;
  }
};
