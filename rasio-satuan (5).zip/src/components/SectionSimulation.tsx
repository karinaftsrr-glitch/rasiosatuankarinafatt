import React, { useState } from 'react';
import { SectionCase1 } from './SectionCase1';
import { SectionCase2 } from './SectionCase2';
import { SectionCase3 } from './SectionCase3';
import { SyrupGlassVisual } from './SyrupGlassVisual';
import { FlaskConical, Sparkles, Sliders, ArrowRight, RotateCcw, Award, Volume2 } from 'lucide-react';
import { sounds } from '../utils/audio';

interface SectionSimulationProps {
  onNextToGames: () => void;
  soundEnabled: boolean;
}

export const SectionSimulation: React.FC<SectionSimulationProps> = ({
  onNextToGames,
  soundEnabled,
}) => {
  const [activeTab, setActiveTab] = useState<'custom' | 'case1' | 'case2' | 'case3'>('custom');

  // Interactive Custom Lab State
  const [recipe1Syrup, setRecipe1Syrup] = useState<number>(30);
  const [recipe1Glasses, setRecipe1Glasses] = useState<number>(5);

  const [recipe2Syrup, setRecipe2Syrup] = useState<number>(36);
  const [recipe2Glasses, setRecipe2Glasses] = useState<number>(6);

  const ratio1 = recipe1Syrup / recipe1Glasses;
  const ratio2 = recipe2Syrup / recipe2Glasses;

  const handleTabChange = (tab: 'custom' | 'case1' | 'case2' | 'case3') => {
    setActiveTab(tab);
    sounds.playMixChime(soundEnabled);
  };

  const handleSyrup1Change = (val: number) => {
    setRecipe1Syrup(val);
    sounds.playPourWater(soundEnabled, true, false);
  };

  const handleGlasses1Change = (val: number) => {
    setRecipe1Glasses(val);
    sounds.playPourWater(soundEnabled, false, false);
  };

  const handleSyrup2Change = (val: number) => {
    setRecipe2Syrup(val);
    sounds.playPourWater(soundEnabled, true, false);
  };

  const handleGlasses2Change = (val: number) => {
    setRecipe2Glasses(val);
    sounds.playPourWater(soundEnabled, false, false);
  };

  const handleResetValues = () => {
    setRecipe1Syrup(30);
    setRecipe1Glasses(5);
    setRecipe2Syrup(36);
    setRecipe2Glasses(6);
    sounds.playMixChime(soundEnabled);
  };

  const getTasteBadge = (mlPerGlass: number) => {
    if (mlPerGlass < 6) return { label: 'Kurang Manis / Hambar', color: 'bg-slate-200 text-slate-800' };
    if (mlPerGlass <= 7) return { label: 'Manis Sedang / Pas', color: 'bg-emerald-100 text-emerald-800 border border-emerald-400' };
    if (mlPerGlass <= 8.5) return { label: 'Manis Terasa', color: 'bg-amber-100 text-amber-800 border border-amber-400' };
    return { label: 'Sangat Manis!', color: 'bg-rose-100 text-rose-800 border border-rose-400' };
  };

  return (
    <div className="space-y-6">
      {/* Simulation Header Banner */}
      <div className="bg-gradient-to-r from-purple-500 via-indigo-400 to-sky-300 border-4 border-slate-900 rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_#1e293b] text-white relative overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-slate-900 font-extrabold text-xs flex items-center gap-1 bg-white/90 px-2.5 py-0.5 rounded-full border border-slate-800">
            <FlaskConical className="w-3.5 h-3.5 text-purple-700" /> Laboratorium & Studi Kasus
          </span>
        </div>

        <h2 className="font-heading font-black text-2xl sm:text-3xl lg:text-4xl text-slate-900 leading-tight">
          Simulasi Rasio Satuan Minuman 🧪
        </h2>

        <p className="text-slate-900 text-sm sm:text-base font-bold mt-2 max-w-3xl leading-relaxed">
          Uji coba racikan es sirup sesukamu di <strong>Laboratorium Eksperimen</strong> atau teliti perbandingan nyata di <strong>3 Studi Kasus Warung</strong>!
        </p>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-start gap-2 bg-purple-100 p-3 rounded-2xl border-2 border-slate-900">
        <button
          onClick={() => handleTabChange('custom')}
          className={`comic-button px-3.5 py-2 text-xs sm:text-sm font-black flex items-center gap-1.5 transition-all ${
            activeTab === 'custom'
              ? 'bg-purple-600 text-white ring-2 ring-slate-900 shadow-[2px_2px_0px_#1e293b]'
              : 'bg-white text-slate-800 hover:bg-purple-50'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Eksperimen Racik Bebas</span>
        </button>

        <button
          onClick={() => handleTabChange('case1')}
          className={`comic-button px-3.5 py-2 text-xs sm:text-sm font-black flex items-center gap-1.5 transition-all ${
            activeTab === 'case1'
              ? 'bg-amber-400 text-slate-900 ring-2 ring-slate-900 shadow-[2px_2px_0px_#1e293b]'
              : 'bg-white text-slate-800 hover:bg-amber-50'
          }`}
        >
          <span>Studi Kasus 1 (A vs B)</span>
        </button>

        <button
          onClick={() => handleTabChange('case2')}
          className={`comic-button px-3.5 py-2 text-xs sm:text-sm font-black flex items-center gap-1.5 transition-all ${
            activeTab === 'case2'
              ? 'bg-emerald-400 text-slate-900 ring-2 ring-slate-900 shadow-[2px_2px_0px_#1e293b]'
              : 'bg-white text-slate-800 hover:bg-emerald-50'
          }`}
        >
          <span>Studi Kasus 2 (C vs A)</span>
        </button>

        <button
          onClick={() => handleTabChange('case3')}
          className={`comic-button px-3.5 py-2 text-xs sm:text-sm font-black flex items-center gap-1.5 transition-all ${
            activeTab === 'case3'
              ? 'bg-purple-400 text-slate-900 ring-2 ring-slate-900 shadow-[2px_2px_0px_#1e293b]'
              : 'bg-white text-slate-800 hover:bg-purple-50'
          }`}
        >
          <span>Studi Kasus 3 (D vs C)</span>
        </button>
      </div>

      {/* Active Tab Content */}
      <div className="animate-fadeIn">
        {activeTab === 'custom' && (
          <div className="space-y-6">
            {/* Custom Lab Description */}
            <div className="comic-card bg-white p-5 border-slate-900 space-y-4">
              <div className="flex items-center justify-between border-b-2 border-slate-200 pb-3">
                <div>
                  <span className="bg-purple-100 text-purple-800 font-extrabold text-xs px-2.5 py-0.5 rounded-full border border-purple-300">
                    Laboratorium Interaktif
                  </span>
                  <h3 className="font-heading font-black text-xl text-slate-900 mt-1 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-600" /> Bandingkan Dua Resep Racikan Pilihanmu
                  </h3>
                </div>

                <button
                  onClick={handleResetValues}
                  className="comic-button bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs px-2.5 py-1.5 font-bold flex items-center gap-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Angka</span>
                </button>
              </div>

              {/* Two Recipe Columns */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* Resep 1 */}
                <div className="comic-card bg-amber-50/70 p-5 border-amber-400 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="bg-amber-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
                      RESEP RACIKAN 1
                    </span>
                    <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${getTasteBadge(ratio1).color}`}>
                      {getTasteBadge(ratio1).label}
                    </span>
                  </div>

                  {/* Sliders */}
                  <div className="space-y-3 bg-white p-3.5 rounded-xl border border-amber-300">
                    <div>
                      <div className="flex justify-between text-xs font-black text-slate-700 mb-1">
                        <span>Sirup:</span>
                        <span className="text-amber-700 font-black">{recipe1Syrup} ml</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="80"
                        step="1"
                        value={recipe1Syrup}
                        onChange={(e) => handleSyrup1Change(Number(e.target.value))}
                        onInput={(e) => handleSyrup1Change(Number((e.target as HTMLInputElement).value))}
                        onPointerDown={() => sounds.playPourWater(soundEnabled, true, true)}
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-black text-slate-700 mb-1">
                        <span>Jumlah Gelas Air:</span>
                        <span className="text-amber-700 font-black">{recipe1Glasses} gelas</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        step="1"
                        value={recipe1Glasses}
                        onChange={(e) => handleGlasses1Change(Number(e.target.value))}
                        onInput={(e) => handleGlasses1Change(Number((e.target as HTMLInputElement).value))}
                        onPointerDown={() => sounds.playPourWater(soundEnabled, false, true)}
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Visual Glass & Calculation */}
                  <div className="bg-white p-4 rounded-xl border-2 border-slate-900 flex items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="text-xs font-bold text-slate-500">Rasio Satuan Resep 1:</div>
                      <div className="text-sm font-black text-slate-700">
                        {recipe1Syrup} ml ÷ {recipe1Glasses} gelas
                      </div>
                      <div className="text-2xl font-black text-amber-700">
                        = {ratio1.toFixed(2)} <span className="text-xs">ml/gelas</span>
                      </div>
                    </div>

                    <div
                      className="shrink-0 cursor-pointer hover:scale-105 transition-transform text-center"
                      onClick={() => sounds.playPourWater(soundEnabled, true, true)}
                      title="Klik untuk mendengar suara tuang sirup!"
                    >
                      <SyrupGlassVisual syrupMl={ratio1} size="sm" showMlBadge={false} label="Resep 1" />
                      <span className="text-[10px] font-extrabold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded-full border border-amber-300 block mt-1">
                        🔊 Tuang!
                      </span>
                    </div>
                  </div>

                  {/* Interactive Button to Tuang Sirup */}
                  <button
                    type="button"
                    onClick={() => sounds.playPourWater(soundEnabled, true, true)}
                    className="comic-button w-full bg-amber-400 hover:bg-amber-300 text-slate-900 font-black text-xs sm:text-sm py-2 px-3 flex items-center justify-center gap-1.5 shadow-[2px_2px_0px_#1e293b]"
                  >
                    <span>🫗 Tuang Sirup Resep 1</span>
                    <Volume2 className="w-4 h-4 text-amber-900" />
                  </button>
                </div>

                {/* Resep 2 */}
                <div className="comic-card bg-rose-50/70 p-5 border-rose-400 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="bg-rose-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
                      RESEP RACIKAN 2
                    </span>
                    <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${getTasteBadge(ratio2).color}`}>
                      {getTasteBadge(ratio2).label}
                    </span>
                  </div>

                  {/* Sliders */}
                  <div className="space-y-3 bg-white p-3.5 rounded-xl border border-rose-300">
                    <div>
                      <div className="flex justify-between text-xs font-black text-slate-700 mb-1">
                        <span>Sirup:</span>
                        <span className="text-rose-700 font-black">{recipe2Syrup} ml</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="80"
                        step="1"
                        value={recipe2Syrup}
                        onChange={(e) => handleSyrup2Change(Number(e.target.value))}
                        onInput={(e) => handleSyrup2Change(Number((e.target as HTMLInputElement).value))}
                        onPointerDown={() => sounds.playPourWater(soundEnabled, true, true)}
                        className="w-full accent-rose-500 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-black text-slate-700 mb-1">
                        <span>Jumlah Gelas Air:</span>
                        <span className="text-rose-700 font-black">{recipe2Glasses} gelas</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        step="1"
                        value={recipe2Glasses}
                        onChange={(e) => handleGlasses2Change(Number(e.target.value))}
                        onInput={(e) => handleGlasses2Change(Number((e.target as HTMLInputElement).value))}
                        onPointerDown={() => sounds.playPourWater(soundEnabled, false, true)}
                        className="w-full accent-rose-500 cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Visual Glass & Calculation */}
                  <div className="bg-white p-4 rounded-xl border-2 border-slate-900 flex items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="text-xs font-bold text-slate-500">Rasio Satuan Resep 2:</div>
                      <div className="text-sm font-black text-slate-700">
                        {recipe2Syrup} ml ÷ {recipe2Glasses} gelas
                      </div>
                      <div className="text-2xl font-black text-rose-700">
                        = {ratio2.toFixed(2)} <span className="text-xs">ml/gelas</span>
                      </div>
                    </div>

                    <div
                      className="shrink-0 cursor-pointer hover:scale-105 transition-transform text-center"
                      onClick={() => sounds.playPourWater(soundEnabled, false, true)}
                      title="Klik untuk mendengar suara tuang sirup!"
                    >
                      <SyrupGlassVisual syrupMl={ratio2} size="sm" showMlBadge={false} label="Resep 2" />
                      <span className="text-[10px] font-extrabold text-rose-800 bg-rose-100 px-1.5 py-0.5 rounded-full border border-rose-300 block mt-1">
                        🔊 Tuang!
                      </span>
                    </div>
                  </div>

                  {/* Interactive Button to Tuang Sirup */}
                  <button
                    type="button"
                    onClick={() => sounds.playPourWater(soundEnabled, true, true)}
                    className="comic-button w-full bg-rose-400 hover:bg-rose-300 text-slate-900 font-black text-xs sm:text-sm py-2 px-3 flex items-center justify-center gap-1.5 shadow-[2px_2px_0px_#1e293b]"
                  >
                    <span>🫗 Tuang Sirup Resep 2</span>
                    <Volume2 className="w-4 h-4 text-rose-900" />
                  </button>
                </div>
              </div>

              {/* Lab Verdict Comparison Box */}
              <div className="bg-gradient-to-r from-purple-100 to-indigo-100 p-5 rounded-2xl border-2 border-slate-900 text-center space-y-2">
                <div className="text-xs font-black uppercase text-purple-900 tracking-wider">
                  Hasil Perbandingan Matematika
                </div>

                <div className="font-heading font-black text-2xl sm:text-3xl text-slate-900">
                  {ratio1 > ratio2 ? (
                    <span>
                      Resep 1 ({ratio1.toFixed(2)} ml){' '}
                      <span className="text-amber-700 font-black underline mx-1">&gt;</span>{' '}
                      Resep 2 ({ratio2.toFixed(2)} ml)
                    </span>
                  ) : ratio2 > ratio1 ? (
                    <span>
                      Resep 2 ({ratio2.toFixed(2)} ml){' '}
                      <span className="text-rose-700 font-black underline mx-1">&gt;</span>{' '}
                      Resep 1 ({ratio1.toFixed(2)} ml)
                    </span>
                  ) : (
                    <span>
                      Resep 1 ({ratio1.toFixed(2)} ml){' '}
                      <span className="text-purple-700 font-black underline mx-1">=</span>{' '}
                      Resep 2 ({ratio2.toFixed(2)} ml)
                    </span>
                  )}
                </div>

                <div className="text-sm sm:text-base font-extrabold text-slate-800 bg-white p-3 rounded-xl border-2 border-slate-900 max-w-xl mx-auto">
                  {ratio1 > ratio2 ? (
                    <span>
                      🏆 <strong>Resep 1 LEBIH MANIS</strong> karena tiap 1 gelasnya mengandung sirup lebih banyak!
                    </span>
                  ) : ratio2 > ratio1 ? (
                    <span>
                      🏆 <strong>Resep 2 LEBIH MANIS</strong> karena tiap 1 gelasnya mengandung sirup lebih banyak!
                    </span>
                  ) : (
                    <span>
                      ⚖️ <strong>Kedua resep SAMA MANISNYA</strong> karena rasio sirup per 1 gelasnya bernilai sama!
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'case1' && (
          <SectionCase1
            onNextSection={() => setActiveTab('case2')}
            soundEnabled={soundEnabled}
          />
        )}

        {activeTab === 'case2' && (
          <SectionCase2
            onNextSection={() => setActiveTab('case3')}
            soundEnabled={soundEnabled}
          />
        )}

        {activeTab === 'case3' && (
          <SectionCase3
            onNextSection={onNextToGames}
            soundEnabled={soundEnabled}
          />
        )}
      </div>

      {/* Footer Nav to Games */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNextToGames}
          className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-6 py-3.5 text-base font-black flex items-center gap-2 shadow-[4px_4px_0px_#1e293b]"
        >
          <span>Uji Kemampuan di Fitur 4: Games</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
