import React from 'react';

interface SyrupGlassVisualProps {
  syrupMl: number;
  glassNumber?: number;
  totalGlasses?: number;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  showMlBadge?: boolean;
  highlighted?: boolean;
  colorScheme?: 'red' | 'coral' | 'amber';
}

export const SyrupGlassVisual: React.FC<SyrupGlassVisualProps> = ({
  syrupMl,
  glassNumber,
  totalGlasses,
  label,
  size = 'md',
  showMlBadge = true,
  highlighted = false,
  colorScheme = 'red',
}) => {
  // Height & scale mapping
  const heightMap = {
    sm: { width: 50, height: 70 },
    md: { width: 70, height: 95 },
    lg: { width: 90, height: 125 },
  };

  const { width, height } = heightMap[size];

  // Sweetness visual opacity / color gradient depth based on syrupMl per glass
  // Baseline: 6-9 ml per glass
  const opacity = Math.min(1, Math.max(0.35, syrupMl / 10));

  // Liquid color based on scheme
  const liquidFill = colorScheme === 'red' ? '#e11d48' : colorScheme === 'coral' ? '#f43f5e' : '#f59e0b';
  const liquidTop = colorScheme === 'red' ? '#fda4af' : colorScheme === 'coral' ? '#fecdd3' : '#fef08a';

  return (
    <div className={`inline-flex flex-col items-center group transition-transform duration-300 ${highlighted ? 'scale-110' : 'hover:scale-105'}`}>
      <div className="relative">
        <svg
          width={width}
          height={height}
          viewBox="0 0 100 130"
          className="drop-shadow-sm filter"
        >
          <defs>
            {/* Glass Shadow */}
            <radialGradient id={`glassGlow-${syrupMl}-${glassNumber}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={liquidFill} stopOpacity={opacity * 0.4} />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
            </radialGradient>

            {/* Liquid Gradient */}
            <linearGradient id={`liquidGrad-${syrupMl}-${glassNumber}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={liquidTop} stopOpacity={opacity} />
              <stop offset="100%" stopColor={liquidFill} stopOpacity={Math.min(1, opacity + 0.2)} />
            </linearGradient>
          </defs>

          {/* Background Ambient Glow */}
          <ellipse cx="50" cy="115" rx="35" ry="10" fill={`url(#glassGlow-${syrupMl}-${glassNumber})`} />

          {/* Glass Outer Outline */}
          <path
            d="M 22 15 L 28 112 C 28 118, 72 118, 72 112 L 78 15 Z"
            fill="#ffffff"
            fillOpacity="0.4"
            stroke="#1e293b"
            strokeWidth="3.5"
            strokeLinejoin="round"
          />

          {/* Liquid Fill */}
          <path
            d="M 24.5 35 L 28.5 110 C 28.5 115, 71.5 115, 71.5 110 L 75.5 35 Z"
            fill={`url(#liquidGrad-${syrupMl}-${glassNumber})`}
          />

          {/* Liquid Surface Ellipse */}
          <ellipse cx="50" cy="35" rx="25.5" ry="5" fill={liquidTop} stroke="#be123c" strokeWidth="1" />

          {/* Ice Cubes inside */}
          <rect x="36" y="55" width="12" height="12" rx="2" fill="#ffffff" fillOpacity="0.7" stroke="#38bdf8" strokeWidth="1" transform="rotate(12 42 61)" />
          <rect x="52" y="70" width="11" height="11" rx="2" fill="#ffffff" fillOpacity="0.7" stroke="#38bdf8" strokeWidth="1" transform="rotate(-8 57 75)" />

          {/* Straw */}
          <path
            d="M 42 125 L 68 8 L 78 4"
            stroke="#f97316"
            strokeWidth="4"
            strokeLinecap="round"
            fill="none"
          />
          <path
            d="M 42 125 L 68 8 L 78 4"
            stroke="#ffffff"
            strokeWidth="1.5"
            strokeDasharray="4 4"
            strokeLinecap="round"
            fill="none"
          />

          {/* Glass Highlights */}
          <path d="M 26 20 L 30 108" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" opacity="0.8" />
          <path d="M 74 20 L 71 108" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />

          {/* Measuring lines on glass */}
          <line x1="26" y1="45" x2="33" y2="45" stroke="#475569" strokeWidth="1.5" opacity="0.6" />
          <line x1="26" y1="65" x2="33" y2="65" stroke="#475569" strokeWidth="1.5" opacity="0.6" />
          <line x1="26" y1="85" x2="33" y2="85" stroke="#475569" strokeWidth="1.5" opacity="0.6" />
        </svg>

        {glassNumber && (
          <span className="absolute top-1 left-1/2 -translate-x-1/2 bg-slate-800 text-white font-bold text-[10px] px-1.5 py-0.2 rounded-full border border-white">
            Gelas #{glassNumber}
          </span>
        )}
      </div>

      {showMlBadge && (
        <div className={`mt-1 text-center ${highlighted ? 'scale-105' : ''}`}>
          <span className="inline-block px-2 py-0.5 rounded-full text-xs font-extrabold bg-rose-500 text-white border border-rose-700 shadow-sm">
            {syrupMl > 0 ? `${syrupMl.toLocaleString('id-ID', { maximumFractionDigits: 2 })} ml` : '? ml'}
          </span>
          {label && <div className="text-[11px] font-semibold text-slate-600 mt-0.5">{label}</div>}
        </div>
      )}
    </div>
  );
};
