import React from 'react';
import { SectionId } from '../types';
import { Target, BookOpen, FlaskConical, Gamepad2 } from 'lucide-react';

interface NavigationBoxesProps {
  currentSection: SectionId;
  onSelectSection: (section: SectionId) => void;
}

export const NavigationBoxes: React.FC<NavigationBoxesProps> = ({
  currentSection,
  onSelectSection,
}) => {
  const menuBoxes = [
    {
      id: 'objectives' as SectionId,
      title: 'Tujuan Pembelajaran',
      subtitle: 'Target & Panduan Belajar',
      icon: <Target className="w-6 h-6 sm:w-7 sm:h-7 text-amber-700" />,
      activeBg: 'bg-amber-400 border-slate-900 shadow-[5px_5px_0px_#1e293b] ring-4 ring-amber-300 scale-[1.02]',
      idleBg: 'bg-white hover:bg-amber-50 border-slate-800 shadow-[3px_3px_0px_#1e293b]',
    },
    {
      id: 'materials' as SectionId,
      title: 'Bahan Ajar',
      subtitle: 'Konsep Rasio & Rasio Satuan',
      icon: <BookOpen className="w-6 h-6 sm:w-7 sm:h-7 text-sky-700" />,
      activeBg: 'bg-sky-300 border-slate-900 shadow-[5px_5px_0px_#1e293b] ring-4 ring-sky-300 scale-[1.02]',
      idleBg: 'bg-white hover:bg-sky-50 border-slate-800 shadow-[3px_3px_0px_#1e293b]',
    },
    {
      id: 'simulation' as SectionId,
      title: 'Simulasi',
      subtitle: 'Lab Racikan Es Sirup',
      icon: <FlaskConical className="w-6 h-6 sm:w-7 sm:h-7 text-purple-700" />,
      activeBg: 'bg-purple-300 border-slate-900 shadow-[5px_5px_0px_#1e293b] ring-4 ring-purple-300 scale-[1.02]',
      idleBg: 'bg-white hover:bg-purple-50 border-slate-800 shadow-[3px_3px_0px_#1e293b]',
    },
    {
      id: 'games' as SectionId,
      title: 'Games',
      subtitle: 'Tantangan Drag & Drop',
      icon: <Gamepad2 className="w-6 h-6 sm:w-7 sm:h-7 text-rose-700" />,
      activeBg: 'bg-rose-400 border-slate-900 shadow-[5px_5px_0px_#1e293b] ring-4 ring-rose-300 text-white scale-[1.02]',
      idleBg: 'bg-white hover:bg-rose-50 border-slate-800 shadow-[3px_3px_0px_#1e293b]',
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      {menuBoxes.map((box) => {
        const isActive = currentSection === box.id;

        return (
          <button
            key={box.id}
            onClick={() => onSelectSection(box.id)}
            className={`p-3.5 sm:p-4 rounded-2xl border-3 text-left transition-all duration-200 flex flex-col justify-between cursor-pointer ${
              isActive ? box.activeBg : box.idleBg
            } hover:-translate-y-0.5`}
          >
            {/* Icon Header */}
            <div className="mb-2">
              <div
                className={`w-11 h-11 sm:w-12 sm:h-12 rounded-xl border-2 border-slate-900 flex items-center justify-center shadow-sm ${
                  isActive ? 'bg-white text-slate-900' : 'bg-slate-100'
                }`}
              >
                {box.icon}
              </div>
            </div>

            {/* Title & Subtitle */}
            <div>
              <h3
                className={`font-heading font-black text-base sm:text-lg leading-tight mb-1 ${
                  isActive && box.id === 'games' ? 'text-white' : 'text-slate-900'
                }`}
              >
                {box.title}
              </h3>
              <p
                className={`text-xs font-bold leading-snug ${
                  isActive && box.id === 'games'
                    ? 'text-rose-100'
                    : isActive
                    ? 'text-slate-800'
                    : 'text-slate-500'
                }`}
              >
                {box.subtitle}
              </p>
            </div>
          </button>
        );
      })}
    </div>
  );
};
