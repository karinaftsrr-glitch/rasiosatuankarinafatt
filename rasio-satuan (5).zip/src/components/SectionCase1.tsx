import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { SyrupGlassVisual } from './SyrupGlassVisual';
import { DivisionVisualizer } from './DivisionVisualizer';
import { Search, Play, ArrowRight, CheckCircle2, AlertCircle, Calculator, Sparkles, HelpCircle } from 'lucide-react';
import { sounds } from '../utils/audio';

interface SectionCase1Props {
  onNextSection: () => void;
  soundEnabled: boolean;
}

export const SectionCase1: React.FC<SectionCase1Props> = ({ onNextSection, soundEnabled }) => {
  const [showProcess, setShowProcess] = useState<boolean>(false);
  const [animationStep, setAnimationStep] = useState<number>(0);

  // Warung A: 40 ml / 6 glasses = 6.67 ml/glass
  // Warung B: 55 ml / 8 glasses = 6.875 ml/glass
  const warungA = { name: 'Warung A', syrup: 40, glasses: 6, unit: 40 / 6, unitStr: '6,67 ml/gelas' };
  const warungB = { name: 'Warung B', syrup: 55, glasses: 8, unit: 55 / 8, unitStr: '6,875 ml/gelas' };

  const handleRevealProcess = () => {
    setShowProcess(true);
    sounds.playPourWater(soundEnabled, true, true);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  return (
    <div className="space-y-6">
      {/* Case Header Banner */}
      <div className="bg-gradient-to-r from-rose-500 via-rose-400 to-amber-400 border-4 border-slate-900 rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_#1e293b] text-white relative overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-slate-900 text-amber-300 font-extrabold text-xs px-3 py-1 rounded-full border border-amber-300 uppercase tracking-wider">
            STUDI KASUS 1
          </span>
          <span className="text-slate-900 font-extrabold text-xs flex items-center gap-1 bg-white/80 px-2 py-0.5 rounded-full">
            <Search className="w-3.5 h-3.5" /> Penyelidikan Rasa Sirup
          </span>
        </div>

        <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-slate-900 leading-tight">
          Warung A vs Warung B 🥤
        </h2>
        <p className="text-slate-900 text-sm sm:text-base font-bold mt-1 max-w-2xl">
          Dua warung menjual es sirup dengan resep racikan berbeda. Mari selidiki mana yang lebih manis!
        </p>
      </div>

      {/* Case Visual Presentation Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Warung A */}
        <div className="comic-card bg-amber-50 p-5 border-amber-400 relative">
          <div className="absolute top-3 right-3 bg-amber-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
            Resep #1
          </div>

          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-amber-400 rounded-2xl border-2 border-slate-900 flex items-center justify-center text-2xl">
              🏪
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                WARUNG A
              </h3>
              <p className="text-xs font-bold text-amber-800">
                40 ml sirup untuk 6 gelas air
              </p>
            </div>
          </div>

          {/* Visual Mixture Display */}
          <div className="bg-white p-4 rounded-xl border-2 border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-700">
              <span>Bahan: 40 ml Sirup</span>
              <span>Wadah: 6 Gelas Air</span>
            </div>

            {/* Glasses Preview */}
            <div
              className="grid grid-cols-6 gap-1 py-2 bg-amber-100/50 rounded-lg p-2 border border-dashed border-amber-300 cursor-pointer hover:bg-amber-100 transition-colors"
              onClick={() => sounds.playPourWater(soundEnabled, true, true)}
              title="Klik untuk mendengar suara tuang sirup Warung A"
            >
              {[1, 2, 3, 4, 5, 6].map((g) => (
                <SyrupGlassVisual key={g} syrupMl={40 / 6} glassNumber={g} size="sm" showMlBadge={false} />
              ))}
            </div>

            <div className="bg-amber-100 p-2.5 rounded-lg border border-amber-300 text-center font-bold text-xs text-amber-900">
              Rasio Mula-Mula: <span className="text-rose-600 font-black text-sm">40 ml : 6 gelas</span>
            </div>
          </div>
        </div>

        {/* Warung B */}
        <div className="comic-card bg-rose-50 p-5 border-rose-400 relative">
          <div className="absolute top-3 right-3 bg-rose-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
            Resep #2
          </div>

          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-rose-400 rounded-2xl border-2 border-slate-900 flex items-center justify-center text-2xl">
              🏪
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                WARUNG B
              </h3>
              <p className="text-xs font-bold text-rose-800">
                55 ml sirup untuk 8 gelas air
              </p>
            </div>
          </div>

          {/* Visual Mixture Display */}
          <div className="bg-white p-4 rounded-xl border-2 border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-700">
              <span>Bahan: 55 ml Sirup</span>
              <span>Wadah: 8 Gelas Air</span>
            </div>

            {/* Glasses Preview */}
            <div
              className="grid grid-cols-4 sm:grid-cols-8 gap-1 py-2 bg-rose-100/50 rounded-lg p-2 border border-dashed border-rose-300 cursor-pointer hover:bg-rose-100 transition-colors"
              onClick={() => sounds.playPourWater(soundEnabled, true, true)}
              title="Klik untuk mendengar suara tuang sirup Warung B"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map((g) => (
                <SyrupGlassVisual key={g} syrupMl={55 / 8} glassNumber={g} size="sm" showMlBadge={false} />
              ))}
            </div>

            <div className="bg-rose-100 p-2.5 rounded-lg border border-rose-300 text-center font-bold text-xs text-rose-900">
              Rasio Mula-Mula: <span className="text-rose-600 font-black text-sm">55 ml : 8 gelas</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Question Box for Teacher Discussion */}
      <div className="comic-card bg-amber-300 p-6 border-slate-900 text-center space-y-4">
        <div className="inline-flex items-center gap-2 bg-white px-4 py-1.5 rounded-full border-2 border-slate-900 text-xs font-extrabold text-slate-900 shadow-sm">
          <HelpCircle className="w-4 h-4 text-rose-600" /> Diskusi Lisan Guru dan Siswa
        </div>

        <h3 className="font-heading font-black text-2xl sm:text-3xl text-slate-900">
          "Menurut kalian, warung mana yang lebih manis?"
        </h3>

        <p className="text-slate-800 text-sm sm:text-base font-extrabold max-w-xl mx-auto">
          🗣️ Jawab secara lisan kepada Gurumu! Apakah Warung B lebih manis hanya karena menggunakan 55 ml sirup? Atau justru Warung A?
        </p>

        {!showProcess && (
          <div className="pt-2">
            <button
              onClick={handleRevealProcess}
              className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-8 py-3.5 text-lg font-black flex items-center gap-2 mx-auto shadow-[4px_4px_0px_#1e293b] animate-bounce"
            >
              <Calculator className="w-5 h-5" />
              Lihat Proses Perhitungan Rasio Satuan
            </button>
          </div>
        )}
      </div>

      {/* Calculation Process & Reveal */}
      {showProcess && (
        <div className="space-y-6 animate-fadeIn">
          {/* Interactive Division Visualizer */}
          <DivisionVisualizer
            shopAName="Warung A"
            shopASyrup={40}
            shopAGlasses={6}
            unitAStr="6,67 ml"
            unitAVal={40 / 6}
            colorA="amber"
            shopBName="Warung B"
            shopBSyrup={55}
            shopBGlasses={8}
            unitBStr="6,875 ml"
            unitBVal={55 / 8}
            colorB="rose"
            winningShopName="Warung B"
            conclusionText="memiliki sirup per 1 gelas yang LEBIH BANYAK (6,875 ml > 6,67 ml), sehingga rasanya LEBIH MANIS!"
            soundEnabled={soundEnabled}
          />

          <div className="comic-card bg-emerald-100 p-6 border-emerald-500 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-400 border-2 border-slate-900 rounded-2xl text-2xl text-slate-900">
                🏆
              </div>
              <div>
                <span className="bg-emerald-600 text-white font-extrabold text-xs px-3 py-0.5 rounded-full uppercase">
                  Hasil Perhitungan & Kesimpulan
                </span>
                <h3 className="font-heading font-black text-2xl text-slate-900 mt-1">
                  Warung B Lebih Manis Dibanding Warung A!
                </h3>
              </div>
            </div>

            {/* Concise Comparison Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white p-4 rounded-xl border-2 border-slate-800">
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-300 text-center">
                <div className="text-xs font-bold text-amber-800">Warung A</div>
                <div className="text-sm font-bold text-slate-600">40 ml ÷ 6 gelas</div>
                <div className="text-2xl font-black text-amber-600 mt-1">6,67 ml / gelas</div>
              </div>
              <div className="p-3 bg-rose-100 rounded-lg border-2 border-rose-500 text-center relative">
                <span className="absolute -top-2.5 right-2 bg-rose-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                  LEBIH MANIS!
                </span>
                <div className="text-xs font-bold text-rose-800">Warung B</div>
                <div className="text-sm font-bold text-slate-600">55 ml ÷ 8 gelas</div>
                <div className="text-2xl font-black text-rose-600 mt-1">6,875 ml / gelas</div>
              </div>
            </div>

            <p className="text-sm font-extrabold text-slate-800 bg-white p-3 rounded-lg border-2 border-slate-900 text-center">
              Kesimpulan: <span className="text-rose-600 font-black">6,875 ml/gelas &gt; 6,67 ml/gelas</span> (Warung B lebih manis karena memiliki lebih banyak sirup per 1 gelas).
            </p>
          </div>

          {/* Next Button */}
          <div className="flex justify-end pt-2">
            <button
              onClick={onNextSection}
              className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-6 py-3 text-base sm:text-lg font-bold flex items-center gap-2 shadow-[4px_4px_0px_#1e293b]"
            >
              Lanjut ke Studi Kasus 2 (Warung C vs A)
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
