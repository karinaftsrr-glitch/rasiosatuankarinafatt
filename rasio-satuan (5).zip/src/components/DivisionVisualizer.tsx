import React, { useState, useEffect } from 'react';
import { SyrupGlassVisual } from './SyrupGlassVisual';
import { Play, RotateCcw, ArrowRight, CheckCircle2, ChevronRight, Award, Volume2 } from 'lucide-react';
import { sounds } from '../utils/audio';

interface DivisionVisualizerProps {
  shopAName: string;
  shopASyrup: number;
  shopAGlasses: number;
  unitAStr: string;
  unitAVal: number;
  colorA: string; // e.g. 'amber'

  shopBName: string;
  shopBSyrup: number;
  shopBGlasses: number;
  unitBStr: string;
  unitBVal: number;
  colorB: string; // e.g. 'rose' | 'emerald' | 'purple'

  winningShopName: string;
  conclusionText: string;
  soundEnabled?: boolean;
}

export const DivisionVisualizer: React.FC<DivisionVisualizerProps> = ({
  shopAName,
  shopASyrup,
  shopAGlasses,
  unitAStr,
  unitAVal,
  colorA,
  shopBName,
  shopBSyrup,
  shopBGlasses,
  unitBStr,
  unitBVal,
  colorB,
  winningShopName,
  conclusionText,
  soundEnabled = true,
}) => {
  const [activeTab, setActiveTab] = useState<'A' | 'B' | 'compare'>('A');

  // Animation states for pouring syrup into glasses
  const [pouredGlassesA, setPouredGlassesA] = useState<number>(shopAGlasses);
  const [isPouringA, setIsPouringA] = useState<boolean>(false);

  const [pouredGlassesB, setPouredGlassesB] = useState<number>(shopBGlasses);
  const [isPouringB, setIsPouringB] = useState<boolean>(false);

  // Pouring animation effect A
  useEffect(() => {
    let timer: any;
    if (isPouringA) {
      timer = setInterval(() => {
        setPouredGlassesA((prev) => {
          const next = prev + 1;
          if (next >= shopAGlasses) {
            setIsPouringA(false);
            sounds.playPourWater(soundEnabled, true, true);
            sounds.playMixChime(soundEnabled);
            return shopAGlasses;
          }
          sounds.playPourWater(soundEnabled, true, true);
          return next;
        });
      }, 420);
    }
    return () => clearInterval(timer);
  }, [isPouringA, shopAGlasses, soundEnabled]);

  // Pouring animation effect B
  useEffect(() => {
    let timer: any;
    if (isPouringB) {
      timer = setInterval(() => {
        setPouredGlassesB((prev) => {
          const next = prev + 1;
          if (next >= shopBGlasses) {
            setIsPouringB(false);
            sounds.playPourWater(soundEnabled, true, true);
            sounds.playMixChime(soundEnabled);
            return shopBGlasses;
          }
          sounds.playPourWater(soundEnabled, true, true);
          return next;
        });
      }, 420);
    }
    return () => clearInterval(timer);
  }, [isPouringB, shopBGlasses, soundEnabled]);

  const startPouringA = () => {
    setPouredGlassesA(0);
    setIsPouringA(true);
    sounds.playPourWater(soundEnabled, true, true);
  };

  const startPouringB = () => {
    setPouredGlassesB(0);
    setIsPouringB(true);
    sounds.playPourWater(soundEnabled, true, true);
  };

  return (
    <div className="comic-card bg-slate-50 p-4 sm:p-6 border-slate-900 space-y-5">
      {/* Visualizer Mode Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 border-b-2 border-slate-300 pb-3">
        <button
          onClick={() => setActiveTab('A')}
          className={`comic-button px-3.5 py-2 text-xs sm:text-sm font-black flex items-center gap-1.5 ${
            activeTab === 'A'
              ? 'bg-amber-400 text-slate-900 ring-2 ring-slate-900'
              : 'bg-white text-slate-700 hover:bg-slate-100'
          }`}
        >
          <span>1. Pembagian {shopAName}</span>
        </button>

        <button
          onClick={() => setActiveTab('B')}
          className={`comic-button px-3.5 py-2 text-xs sm:text-sm font-black flex items-center gap-1.5 ${
            activeTab === 'B'
              ? 'bg-rose-400 text-slate-900 ring-2 ring-slate-900'
              : 'bg-white text-slate-700 hover:bg-slate-100'
          }`}
        >
          <span>2. Pembagian {shopBName}</span>
        </button>

        <button
          onClick={() => setActiveTab('compare')}
          className={`comic-button px-3.5 py-2 text-xs sm:text-sm font-black flex items-center gap-1.5 ${
            activeTab === 'compare'
              ? 'bg-emerald-400 text-slate-900 ring-2 ring-slate-900'
              : 'bg-white text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Award className="w-4 h-4 text-emerald-900" />
          <span>3. Bandingkan 1 Gelas</span>
        </button>
      </div>

      {/* TAB A: Shop A Division Visualizer */}
      {activeTab === 'A' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="bg-amber-100/80 p-4 rounded-xl border-2 border-amber-400 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <span className="bg-amber-500 text-white font-extrabold text-[11px] px-2.5 py-0.5 rounded-full border border-slate-900 uppercase">
                Visualisasi Pembagian {shopAName}
              </span>
              <h4 className="font-heading font-black text-xl text-slate-900 mt-1">
                {shopASyrup} ml Sirup ÷ {shopAGlasses} Gelas Air
              </h4>
            </div>

            <button
              onClick={startPouringA}
              disabled={isPouringA}
              className="comic-button bg-amber-400 hover:bg-amber-500 text-slate-900 px-4 py-2 text-xs sm:text-sm font-extrabold flex items-center gap-1.5 shrink-0"
            >
              <Play className="w-4 h-4 fill-slate-900" />
              <span>{isPouringA ? 'Mentuang Sirup...' : 'Simulasi Tuang Sirup'}</span>
              <Volume2 className="w-4 h-4 text-amber-900" />
            </button>
          </div>

          {/* Division Animation Area */}
          <div className="bg-white p-5 rounded-2xl border-2 border-slate-800 space-y-4">
            {/* Pitcher to Glasses Formula */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 bg-amber-50 p-4 rounded-xl border border-amber-300">
              <div
                className="text-center cursor-pointer hover:scale-105 transition-transform"
                onClick={() => sounds.playPourWater(soundEnabled, true, true)}
                title="Klik untuk mendengar suara tuang sirup!"
              >
                <div className="text-4xl py-1">🧃</div>
                <div className="text-xs font-black text-amber-900">Total Sirup</div>
                <div className="text-lg font-black text-rose-600">{shopASyrup} ml</div>
                <span className="text-[9px] font-black text-amber-800 bg-amber-200/80 px-1.5 py-0.2 rounded-full border border-amber-300">🔊 Tuang</span>
              </div>

              <div className="font-heading font-black text-2xl text-slate-800">
                ÷ {shopAGlasses} Gelas =
              </div>

              <div className="text-center bg-white px-4 py-2 rounded-xl border-2 border-slate-900 shadow-sm">
                <div className="text-xs font-extrabold text-slate-500">Hasil Rasio Satuan:</div>
                <div className="text-xl font-black text-amber-600">{unitAStr} / gelas</div>
              </div>
            </div>

            {/* Glasses Distribution */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-2">
              {Array.from({ length: shopAGlasses }).map((_, idx) => {
                const gNum = idx + 1;
                const isPoured = pouredGlassesA >= gNum;

                return (
                  <div
                    key={gNum}
                    className={`p-2 rounded-xl text-center border-2 transition-all duration-300 ${
                      isPoured
                        ? 'bg-amber-100/90 border-amber-400 scale-102 shadow-sm'
                        : 'bg-slate-100 border-slate-300 opacity-40'
                    }`}
                  >
                    <div className="text-[10px] font-bold text-slate-600">Gelas #{gNum}</div>
                    <div className="my-1 flex justify-center">
                      <SyrupGlassVisual
                        syrupMl={unitAVal}
                        glassNumber={gNum}
                        size="sm"
                        showMlBadge={false}
                        highlighted={isPoured}
                      />
                    </div>
                    <div className="text-xs font-black text-amber-800">
                      {isPoured ? unitAStr : '0 ml'}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-amber-200/60 rounded-xl border border-amber-400 text-center text-xs font-extrabold text-slate-800">
              Setiap 1 gelas air di {shopAName} mendapatkan bagian tepat <span className="text-rose-700 font-black">{unitAStr} sirup</span>.
            </div>
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => setActiveTab('B')}
              className="comic-button bg-rose-400 hover:bg-rose-500 text-slate-900 px-4 py-2 text-xs font-bold flex items-center gap-1"
            >
              <span>Lanjut ke Pembagian {shopBName}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* TAB B: Shop B Division Visualizer */}
      {activeTab === 'B' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="bg-rose-100/80 p-4 rounded-xl border-2 border-rose-400 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <span className="bg-rose-500 text-white font-extrabold text-[11px] px-2.5 py-0.5 rounded-full border border-slate-900 uppercase">
                Visualisasi Pembagian {shopBName}
              </span>
              <h4 className="font-heading font-black text-xl text-slate-900 mt-1">
                {shopBSyrup} ml Sirup ÷ {shopBGlasses} Gelas Air
              </h4>
            </div>

            <button
              onClick={startPouringB}
              disabled={isPouringB}
              className="comic-button bg-rose-400 hover:bg-rose-500 text-slate-900 px-4 py-2 text-xs sm:text-sm font-extrabold flex items-center gap-1.5 shrink-0"
            >
              <Play className="w-4 h-4 fill-slate-900" />
              <span>{isPouringB ? 'Mentuang Sirup...' : 'Simulasi Tuang Sirup'}</span>
              <Volume2 className="w-4 h-4 text-rose-900" />
            </button>
          </div>

          {/* Division Animation Area */}
          <div className="bg-white p-5 rounded-2xl border-2 border-slate-800 space-y-4">
            {/* Pitcher to Glasses Formula */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 bg-rose-50 p-4 rounded-xl border border-rose-300">
              <div
                className="text-center cursor-pointer hover:scale-105 transition-transform"
                onClick={() => sounds.playPourWater(soundEnabled, true, true)}
                title="Klik untuk mendengar suara tuang sirup!"
              >
                <div className="text-4xl py-1">🧃</div>
                <div className="text-xs font-black text-rose-900">Total Sirup</div>
                <div className="text-lg font-black text-rose-600">{shopBSyrup} ml</div>
                <span className="text-[9px] font-black text-rose-800 bg-rose-200/80 px-1.5 py-0.2 rounded-full border border-rose-300">🔊 Tuang</span>
              </div>

              <div className="font-heading font-black text-2xl text-slate-800">
                ÷ {shopBGlasses} Gelas =
              </div>

              <div className="text-center bg-white px-4 py-2 rounded-xl border-2 border-slate-900 shadow-sm">
                <div className="text-xs font-extrabold text-slate-500">Hasil Rasio Satuan:</div>
                <div className="text-xl font-black text-rose-600">{unitBStr} / gelas</div>
              </div>
            </div>

            {/* Glasses Distribution */}
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 pt-2">
              {Array.from({ length: shopBGlasses }).map((_, idx) => {
                const gNum = idx + 1;
                const isPoured = pouredGlassesB >= gNum;

                return (
                  <div
                    key={gNum}
                    className={`p-1.5 rounded-xl text-center border-2 transition-all duration-300 ${
                      isPoured
                        ? 'bg-rose-100/90 border-rose-400 scale-102 shadow-sm'
                        : 'bg-slate-100 border-slate-300 opacity-40'
                    }`}
                  >
                    <div className="text-[9px] font-bold text-slate-600">Gelas #{gNum}</div>
                    <div className="my-1 flex justify-center">
                      <SyrupGlassVisual
                        syrupMl={unitBVal}
                        glassNumber={gNum}
                        size="sm"
                        showMlBadge={false}
                        highlighted={isPoured}
                      />
                    </div>
                    <div className="text-[11px] font-black text-rose-800">
                      {isPoured ? unitBStr : '0 ml'}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-rose-200/60 rounded-xl border border-rose-400 text-center text-xs font-extrabold text-slate-800">
              Setiap 1 gelas air di {shopBName} mendapatkan bagian tepat <span className="text-rose-700 font-black">{unitBStr} sirup</span>.
            </div>
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => setActiveTab('compare')}
              className="comic-button bg-emerald-400 hover:bg-emerald-500 text-slate-900 px-4 py-2 text-xs font-bold flex items-center gap-1"
            >
              <span>Bandingkan Hasil 1 Gelas</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* TAB COMPARE: Side-by-side 1 Glass Comparison */}
      {activeTab === 'compare' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="bg-emerald-100 p-4 rounded-xl border-2 border-emerald-400 text-center space-y-1">
            <span className="bg-emerald-600 text-white font-extrabold text-[11px] px-3 py-0.5 rounded-full border border-slate-900 uppercase">
              Perbandingan Rasio Satuan (1 Gelas vs 1 Gelas)
            </span>
            <h4 className="font-heading font-black text-xl text-slate-900">
              Mana yang Memiliki Lebih Banyak Sirup per 1 Gelas?
            </h4>
          </div>

          {/* Glass vs Glass Comparison Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Glass A */}
            <div className={`comic-card p-5 text-center relative ${unitAVal > unitBVal ? 'bg-amber-100 border-amber-500 ring-2 ring-amber-500' : 'bg-white border-slate-300'}`}>
              {unitAVal > unitBVal && (
                <span className="absolute -top-3 right-3 bg-amber-500 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full border border-slate-900 shadow-sm">
                  LEBIH MANIS!
                </span>
              )}
              <div className="text-xs font-bold text-slate-600">1 Gelas di {shopAName}</div>
              <div className="my-3 flex justify-center">
                <SyrupGlassVisual syrupMl={unitAVal} size="md" showMlBadge={true} label={shopAName} />
              </div>
              <div className="text-2xl font-black text-amber-700">{unitAStr}</div>
              <div className="text-xs font-semibold text-slate-500 mt-1">({shopASyrup} ml ÷ {shopAGlasses} gelas)</div>
            </div>

            {/* Glass B */}
            <div className={`comic-card p-5 text-center relative ${unitBVal > unitAVal ? 'bg-rose-100 border-rose-500 ring-2 ring-rose-500' : 'bg-white border-slate-300'}`}>
              {unitBVal > unitAVal && (
                <span className="absolute -top-3 right-3 bg-rose-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full border border-slate-900 shadow-sm">
                  LEBIH MANIS!
                </span>
              )}
              <div className="text-xs font-bold text-slate-600">1 Gelas di {shopBName}</div>
              <div className="my-3 flex justify-center">
                <SyrupGlassVisual syrupMl={unitBVal} size="md" showMlBadge={true} label={shopBName} />
              </div>
              <div className="text-2xl font-black text-rose-700">{unitBStr}</div>
              <div className="text-xs font-semibold text-slate-500 mt-1">({shopBSyrup} ml ÷ {shopBGlasses} gelas)</div>
            </div>
          </div>

          {/* Mathematical Comparison Sign Box */}
          <div className="bg-amber-300 p-4 rounded-xl border-2 border-slate-900 text-center space-y-2">
            <div className="text-xs font-black text-slate-900 uppercase tracking-wider">
              Tanda Pembanding Matematika:
            </div>
            <div className="font-heading font-black text-2xl sm:text-3xl text-slate-900">
              {unitBVal > unitAVal ? (
                <span>{unitBStr} <span className="text-rose-700 underline mx-1">&gt;</span> {unitAStr}</span>
              ) : (
                <span>{unitAStr} <span className="text-amber-800 underline mx-1">&gt;</span> {unitBStr}</span>
              )}
            </div>
            <p className="text-xs sm:text-sm font-extrabold text-slate-900 bg-white p-2.5 rounded-lg border-2 border-slate-900">
              Kesimpulan: <strong className="text-rose-700">{winningShopName}</strong> {conclusionText}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
