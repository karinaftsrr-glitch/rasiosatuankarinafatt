import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { SyrupGlassVisual } from './SyrupGlassVisual';
import { DivisionVisualizer } from './DivisionVisualizer';
import { Search, Calculator, ArrowRight, CheckCircle2, HelpCircle, Award } from 'lucide-react';
import { sounds } from '../utils/audio';

interface SectionCase3Props {
  onNextSection: () => void;
  soundEnabled: boolean;
}

export const SectionCase3: React.FC<SectionCase3Props> = ({ onNextSection, soundEnabled }) => {
  const [showDiscussion, setShowDiscussion] = useState<boolean>(false);
  const [step, setStep] = useState<number>(0);

  // Warung D: 18 ml / 2 glasses = 9 ml/glass
  // Warung C: 24 ml / 3 glasses = 8 ml/glass
  const warungD = { name: 'Warung D', syrup: 18, glasses: 2, unit: 9, unitStr: '9 ml/gelas' };
  const warungC = { name: 'Warung C', syrup: 24, glasses: 3, unit: 8, unitStr: '8 ml/gelas' };

  const handleRevealDiscussion = () => {
    setShowDiscussion(true);
    sounds.playPourWater(soundEnabled, true, true);
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.7 },
    });
  };

  return (
    <div className="space-y-6">
      {/* Case Header Banner */}
      <div className="bg-gradient-to-r from-purple-500 via-indigo-400 to-sky-400 border-4 border-slate-900 rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_#1e293b] text-white relative overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-slate-900 text-purple-300 font-extrabold text-xs px-3 py-1 rounded-full border border-purple-300 uppercase tracking-wider">
            STUDI KASUS 3
          </span>
          <span className="text-slate-900 font-extrabold text-xs flex items-center gap-1 bg-white/80 px-2 py-0.5 rounded-full">
            <Search className="w-3.5 h-3.5" /> Warung D vs Warung C
          </span>
        </div>

        <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-slate-900 leading-tight">
          Warung D Membawa Racikan 18 ml Sirup! 🍧
        </h2>
        <p className="text-slate-900 text-sm sm:text-base font-bold mt-1 max-w-2xl">
          Warung D menyajikan 18 ml sirup untuk 2 gelas air. Apakah rasanya lebih manis atau lebih hambar?
        </p>
      </div>

      {/* Visual Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Warung D */}
        <div className="comic-card bg-purple-50 p-5 border-purple-400 relative">
          <div className="absolute top-3 right-3 bg-purple-600 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
            Resep Warung D
          </div>

          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-purple-400 rounded-2xl border-2 border-slate-900 flex items-center justify-center text-2xl">
              🥤
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                WARUNG D
              </h3>
              <p className="text-xs font-bold text-purple-800">
                18 ml sirup untuk 2 gelas air
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border-2 border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-700">
              <span>Bahan: 18 ml Sirup</span>
              <span>Wadah: 2 Gelas Air</span>
            </div>

            <div
              className="grid grid-cols-2 gap-2 py-2 bg-purple-100/50 rounded-lg p-2 border border-dashed border-purple-300 cursor-pointer hover:bg-purple-100 transition-colors"
              onClick={() => sounds.playPourWater(soundEnabled, true, true)}
              title="Klik untuk mendengar suara tuang sirup Warung D"
            >
              {[1, 2].map((g) => (
                <SyrupGlassVisual key={g} syrupMl={9} glassNumber={g} size="sm" showMlBadge={false} />
              ))}
            </div>

            <div className="bg-purple-100 p-2.5 rounded-lg border border-purple-300 text-center font-bold text-xs text-purple-900">
              Rasio Mula-Mula: <span className="text-purple-700 font-black text-sm">18 ml : 2 gelas</span>
            </div>
          </div>
        </div>

        {/* Warung C (Reference) */}
        <div className="comic-card bg-emerald-50 p-5 border-emerald-400 relative">
          <div className="absolute top-3 right-3 bg-emerald-500 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900">
            Pembanding Warung C
          </div>

          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-emerald-400 rounded-2xl border-2 border-slate-900 flex items-center justify-center text-2xl">
              🍹
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-2xl text-slate-900">
                WARUNG C
              </h3>
              <p className="text-xs font-bold text-emerald-800">
                24 ml sirup untuk 3 gelas air
              </p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border-2 border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold text-slate-700">
              <span>Bahan: 24 ml Sirup</span>
              <span>Wadah: 3 Gelas Air</span>
            </div>

            <div
              className="grid grid-cols-3 gap-2 py-2 bg-emerald-100/50 rounded-lg p-2 border border-dashed border-emerald-300 cursor-pointer hover:bg-emerald-100 transition-colors"
              onClick={() => sounds.playPourWater(soundEnabled, true, true)}
              title="Klik untuk mendengar suara tuang sirup Warung C"
            >
              {[1, 2, 3].map((g) => (
                <SyrupGlassVisual key={g} syrupMl={8} glassNumber={g} size="sm" showMlBadge={false} />
              ))}
            </div>

            <div className="bg-emerald-100 p-2.5 rounded-lg border border-emerald-300 text-center font-bold text-xs text-emerald-900">
              Rasio Mula-Mula: <span className="text-emerald-700 font-black text-sm">24 ml : 3 gelas</span>
            </div>
          </div>
        </div>
      </div>

      {/* Question Box for Class Oral Answer */}
      <div className="comic-card bg-purple-300 p-6 border-slate-900 text-center space-y-4">
        <div className="inline-flex items-center gap-2 bg-white px-4 py-1.5 rounded-full border-2 border-slate-900 text-xs font-extrabold text-slate-900 shadow-sm">
          <HelpCircle className="w-4 h-4 text-purple-700" /> Diskusi Lisan Guru dan Siswa
        </div>

        <h3 className="font-heading font-black text-2xl sm:text-3xl text-slate-900">
          "Lebih manis atau lebih hambar dibanding Warung C?"
        </h3>

        <p className="text-slate-800 text-sm sm:text-base font-extrabold max-w-xl mx-auto">
          🗣️ Berikan jawaban kalian secara lisan! Hitung berapa ml sirup per 1 gelas yang ada di Warung D!
        </p>

        {!showDiscussion && (
          <div className="pt-2">
            <button
              onClick={handleRevealDiscussion}
              className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-8 py-3.5 text-lg font-black flex items-center gap-2 mx-auto shadow-[4px_4px_0px_#1e293b] animate-bounce"
            >
              <Calculator className="w-5 h-5" />
              Lihat Pembahasan
            </button>
          </div>
        )}
      </div>

      {/* Discussion Reveal Steps */}
      {showDiscussion && (
        <div className="space-y-6 animate-fadeIn">
          {/* Interactive Division Visualizer */}
          <DivisionVisualizer
            shopAName="Warung D"
            shopASyrup={18}
            shopAGlasses={2}
            unitAStr="9 ml"
            unitAVal={9}
            colorA="purple"
            shopBName="Warung C"
            shopBSyrup={24}
            shopBGlasses={3}
            unitBStr="8 ml"
            unitBVal={8}
            colorB="emerald"
            winningShopName="Warung D"
            conclusionText="memiliki sirup per 1 gelas yang PALING BANYAK (9 ml > 8 ml), sehingga rasanya PALING MANIS!"
            soundEnabled={soundEnabled}
          />

          <div className="comic-card bg-amber-100 p-6 border-amber-500 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-amber-400 border-2 border-slate-900 rounded-2xl text-2xl text-slate-900">
                👑
              </div>
              <div>
                <span className="bg-purple-700 text-white font-extrabold text-xs px-3 py-0.5 rounded-full uppercase">
                  Hasil Perhitungan Studi Kasus 3
                </span>
                <h3 className="font-heading font-black text-2xl text-slate-900 mt-1">
                  Warung D Lebih Manis Dibanding Warung C!
                </h3>
              </div>
            </div>

            {/* Comparison Box */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white p-4 rounded-xl border-2 border-slate-800 text-center">
              <div className="p-3 bg-purple-100 rounded-lg border-2 border-purple-600 relative">
                <span className="absolute -top-2.5 right-2 bg-purple-700 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                  PALING MANIS! (9 ml)
                </span>
                <div className="text-xs font-bold text-purple-800">Warung D</div>
                <div className="text-sm font-bold text-slate-600">18 ml ÷ 2 gelas</div>
                <div className="text-2xl font-black text-purple-700 mt-1">9 ml / gelas</div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-300">
                <div className="text-xs font-bold text-emerald-800">Warung C</div>
                <div className="text-sm font-bold text-slate-600">24 ml ÷ 3 gelas</div>
                <div className="text-2xl font-black text-emerald-700 mt-1">8 ml / gelas</div>
              </div>
            </div>

            <p className="text-sm font-extrabold text-slate-800 bg-white p-3 rounded-lg border-2 border-slate-900 text-center">
              Kesimpulan: <span className="text-purple-700 font-black">9 ml/gelas &gt; 8 ml/gelas</span> (Warung D paling manis).
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
