import React, { useState, useEffect, useRef } from 'react';
import { Music, Play, Pause, Volume2, Upload, Trash2, Sparkles, X, Check, ArrowLeft } from 'lucide-react';
import { sounds } from '../utils/audio';

interface BgmModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BgmModal: React.FC<BgmModalProps> = ({ isOpen, onClose }) => {
  const [bgmState, setBgmState] = useState(() => sounds.getBgmState());
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const unsubscribe = sounds.subscribeBgm((state) => {
      setBgmState(state);
    });
    return unsubscribe;
  }, []);

  if (!isOpen) return null;

  const handleTogglePlay = () => {
    sounds.ensureUnlocked();
    sounds.toggleBgm();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    sounds.setBgmVolume(val);
  };

  const handleSelectTheme = (theme: 'playful' | 'chill') => {
    sounds.ensureUnlocked();
    sounds.setBgmTheme(theme);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      sounds.ensureUnlocked();
      sounds.setCustomAudioFile(file);
    }
  };

  const handleRemoveCustomAudio = () => {
    sounds.clearCustomAudio();
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border-4 border-slate-900 rounded-3xl p-5 sm:p-7 max-w-md w-full shadow-[8px_8px_0px_#1e293b] relative space-y-4 animate-scaleUp">
        {/* Top Navigation Row: Back Button & Close */}
        <div className="flex items-center justify-between">
          <button
            onClick={onClose}
            className="comic-button px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-amber-100 text-slate-800 text-xs font-heading font-black flex items-center gap-1.5 border-2 border-slate-900 shadow-[2px_2px_0px_#1e293b]"
          >
            <ArrowLeft className="w-4 h-4 text-slate-900" />
            <span>⬅️ Back (Kembali)</span>
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-700 border-2 border-slate-800 transition-colors"
            title="Tutup Pengaturan Musik"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-400 border-2 border-slate-900 flex items-center justify-center text-slate-900 shadow-[3px_3px_0px_#1e293b]">
            <Music className={`w-6 h-6 ${bgmState.isPlaying ? 'animate-bounce text-rose-600' : 'text-slate-900'}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                Audio Suasana
              </span>
              {bgmState.isPlaying && (
                <span className="flex items-center gap-1 text-[11px] font-black text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  Memutar 🎶
                </span>
              )}
            </div>
            <h3 className="font-heading font-black text-xl text-slate-900">
              Pengaturan Backsound
            </h3>
          </div>
        </div>

        {/* Main Play / Pause Button */}
        <div className="bg-gradient-to-r from-amber-100 to-amber-200 border-3 border-slate-900 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-[3px_3px_0px_#1e293b]">
          <div>
            <p className="text-sm font-extrabold text-slate-900">
              {bgmState.isPlaying ? 'Musik Sedang Berbunyi 🎶' : 'Musik Sedang Jeda / Mati'}
            </p>
            <p className="text-xs font-bold text-slate-600">
              Menemani aktivitas belajar agar lebih seru & santai!
            </p>
          </div>
          <button
            onClick={handleTogglePlay}
            className={`comic-button px-4 py-2.5 rounded-xl font-heading font-black text-sm flex items-center gap-2 whitespace-nowrap shadow-sm transition-all ${
              bgmState.isPlaying
                ? 'bg-rose-500 hover:bg-rose-600 text-white'
                : 'bg-emerald-400 hover:bg-emerald-500 text-slate-900'
            }`}
          >
            {bgmState.isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-white" /> Jeda
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-slate-900" /> Putar
              </>
            )}
          </button>
        </div>

        {/* Tombol BACK Cepat Setelah Memutar Musik */}
        <button
          onClick={onClose}
          className="w-full comic-button bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-slate-900 font-heading font-black text-sm py-2.5 px-4 rounded-2xl border-3 border-slate-900 flex items-center justify-center gap-2 shadow-[3px_3px_0px_#1e293b] transition-transform hover:-translate-y-0.5 active:translate-y-0"
        >
          <ArrowLeft className="w-5 h-5 text-slate-900" />
          <span>⬅️ Kembali ke Pembelajaran (Back)</span>
        </button>

        {/* Volume Slider */}
        <div className="space-y-2 bg-slate-50 border-2 border-slate-800 rounded-2xl p-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-slate-700" /> Volume Musik:
            </span>
            <span className="text-xs font-black bg-white px-2 py-0.5 rounded-lg border border-slate-700 text-slate-900">
              {Math.round(bgmState.volume * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={bgmState.volume}
            onChange={handleVolumeChange}
            className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-200 rounded-lg"
          />
        </div>

        {/* Music Options / Themes */}
        <div className="space-y-2">
          <label className="text-xs font-black text-slate-700 uppercase tracking-wider block">
            Pilihan Suasana Musik:
          </label>

          <div className="grid grid-cols-2 gap-2.5">
            {/* Theme 1: Playful */}
            <button
              onClick={() => handleSelectTheme('playful')}
              className={`p-3 rounded-2xl border-2 text-left transition-all ${
                bgmState.theme === 'playful'
                  ? 'bg-amber-100 border-amber-600 ring-2 ring-amber-500 shadow-[2px_2px_0px_#d97706]'
                  : 'bg-white border-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xl">🪗</span>
                {bgmState.theme === 'playful' && <Check className="w-4 h-4 text-amber-700" />}
              </div>
              <p className="font-heading font-black text-xs text-slate-900">
                Ceria Belajar
              </p>
              <p className="text-[10px] font-bold text-slate-600 mt-0.5">
                Marimba & nada riang
              </p>
            </button>

            {/* Theme 2: Chill */}
            <button
              onClick={() => handleSelectTheme('chill')}
              className={`p-3 rounded-2xl border-2 text-left transition-all ${
                bgmState.theme === 'chill'
                  ? 'bg-sky-100 border-sky-600 ring-2 ring-sky-500 shadow-[2px_2px_0px_#0284c7]'
                  : 'bg-white border-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xl">🍃</span>
                {bgmState.theme === 'chill' && <Check className="w-4 h-4 text-sky-700" />}
              </div>
              <p className="font-heading font-black text-xs text-slate-900">
                Santai & Tenang
              </p>
              <p className="text-[10px] font-bold text-slate-600 mt-0.5">
                Lo-Fi lembut & fokus
              </p>
            </button>
          </div>
        </div>

        {/* Custom Audio Upload */}
        <div className="bg-purple-50 border-2 border-purple-300 rounded-2xl p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-purple-900 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-purple-700" /> Pakai Musik Sendiri (.mp3):
            </span>
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
          </div>

          {bgmState.customName ? (
            <div className="flex items-center justify-between bg-white border border-purple-300 rounded-xl px-3 py-2">
              <span className="text-xs font-bold text-slate-800 truncate max-w-[200px]" title={bgmState.customName}>
                🎵 {bgmState.customName}
              </span>
              <button
                onClick={handleRemoveCustomAudio}
                className="text-rose-600 hover:text-rose-800 p-1"
                title="Hapus Musik Kustom"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*"
                onChange={handleFileUpload}
                className="hidden"
                id="bgm-file-upload"
              />
              <label
                htmlFor="bgm-file-upload"
                className="comic-button bg-white hover:bg-purple-100 text-purple-900 text-xs font-black py-2 px-3 rounded-xl border-2 border-purple-700 flex items-center justify-center gap-2 cursor-pointer w-full text-center"
              >
                <Upload className="w-3.5 h-3.5 text-purple-700" /> Pilih File MP3 / WAV
              </label>
              <p className="text-[10px] font-bold text-purple-800 mt-1.5 text-center">
                Bisa memutar lagu instrumental sekolah atau kesukaanmu secara berulang (looping).
              </p>
            </div>
          )}
        </div>

        {/* Footer info & Done / Back button */}
        <div className="pt-2 border-t-2 border-slate-200 flex items-center justify-between gap-2">
          <span className="text-[11px] font-bold text-slate-500">
            {bgmState.isPlaying ? '🎶 Musik terus aktif di latar' : 'Volume tersimpan otomatis'}
          </span>
          <button
            onClick={onClose}
            className="comic-button bg-slate-900 hover:bg-slate-800 text-white font-heading font-black text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-[2px_2px_0px_#1e293b]"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Kembali (Back)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
