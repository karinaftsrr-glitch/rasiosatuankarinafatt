import React, { useState, useEffect } from 'react';
import { Calculator, ArrowRight, Play, Pause, RotateCcw, ChevronRight, CheckCircle2, Sparkles, Volume2 } from 'lucide-react';
import { sounds } from '../utils/audio';

interface SectionUnitRatioConceptProps {
  onNextSection: () => void;
  soundEnabled?: boolean;
}

export const SectionUnitRatioConcept: React.FC<SectionUnitRatioConceptProps> = ({ onNextSection, soundEnabled = true }) => {
  // Example: Rp 12.000 for 4 pencils => Rp 3.000/pencil
  const totalPrice = 12000;
  const totalPencils = 4;
  const targetPerPencil = 3000;

  const [step, setStep] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      timer = setInterval(() => {
        setStep((prev) => {
          if (prev >= totalPencils) {
            setIsPlaying(false);
            return totalPencils;
          }
          const next = prev + 1;
          sounds.playPencilCoin(soundEnabled, next);
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, totalPencils, soundEnabled]);

  const handleNextStep = () => {
    if (step < totalPencils) {
      const next = step + 1;
      setStep(next);
      sounds.playPencilCoin(soundEnabled, next);
    }
  };

  const handleReset = () => {
    setStep(0);
    setIsPlaying(false);
    sounds.playCardSnap(soundEnabled);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-cyan-400 via-sky-300 to-sky-200 border-4 border-slate-900 rounded-2xl p-5 sm:p-6 shadow-[6px_6px_0px_#1e293b] relative overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-cyan-700 text-white font-extrabold text-xs px-3 py-1 rounded-full border border-slate-900 uppercase tracking-wider">
            BAGIAN 2
          </span>
          <span className="text-slate-800 font-extrabold text-xs flex items-center gap-1">
            <Calculator className="w-4 h-4 text-cyan-800" /> Konsep Inti
          </span>
        </div>
        <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-slate-900 leading-tight">
          Apa itu Rasio Satuan? ⚖️
        </h2>
      </div>

      {/* Definition Box */}
      <div className="comic-card bg-cyan-50 p-6 border-cyan-400 relative overflow-hidden space-y-4">
        <div className="flex items-start gap-3">
          <div className="p-3 bg-cyan-400 border-2 border-slate-900 rounded-2xl text-slate-900 text-2xl shrink-0">
            🎯
          </div>
          <div>
            <h3 className="font-heading font-bold text-xl text-slate-900 mb-1">
              Apa itu Rasio Satuan?
            </h3>
            <p className="text-base sm:text-lg font-bold text-slate-800 leading-relaxed bg-white p-4 rounded-xl border-2 border-slate-800 shadow-sm">
              <span className="text-cyan-700 font-extrabold">Rasio Satuan</span> adalah nilai perbandingan untuk <strong className="text-rose-600 bg-rose-100 px-2 py-0.5 rounded border border-rose-300">1 (satu) buah / satuan barang saja</strong>.
            </p>
          </div>
        </div>

        {/* Highlighted Comparison Signs Box for Unit Ratio */}
        <div className="bg-white p-4 rounded-xl border-2 border-slate-900 space-y-3">
          <div className="font-heading font-black text-base sm:text-lg text-cyan-800 flex items-center gap-2">
            <span className="bg-cyan-500 text-white text-xs px-2.5 py-0.5 rounded-md border border-slate-900 uppercase">
              Cara Menghitung & Membandingkan
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-cyan-50 rounded-lg border-2 border-cyan-300 text-center">
              <div className="text-2xl font-black text-cyan-700 mb-0.5">÷</div>
              <div className="text-xs font-bold text-slate-800">Tanda Bagi</div>
              <div className="text-[11px] font-semibold text-slate-600 mt-0.5">Rumus: <strong className="text-slate-900">Total ÷ Jumlah Benda</strong></div>
            </div>

            <div className="p-3 bg-amber-50 rounded-lg border-2 border-amber-300 text-center">
              <div className="text-sm font-extrabold text-amber-800 mb-1">" / 1 " (per 1)</div>
              <div className="text-xs font-bold text-slate-800">Tanda Satuan</div>
              <div className="text-[11px] font-semibold text-slate-600 mt-0.5">Contoh: <strong className="text-slate-900">Rp 3.000 / 1 pensil</strong></div>
            </div>

            <div className="p-3 bg-emerald-50 rounded-lg border-2 border-emerald-300 text-center">
              <div className="text-xl font-black text-emerald-700 mb-0.5">&gt; &nbsp; &lt; &nbsp; =</div>
              <div className="text-xs font-bold text-slate-800">Tanda Pembanding Hasil</div>
              <div className="text-[11px] font-semibold text-slate-600 mt-0.5">
                <strong className="text-emerald-800">&gt;</strong> Lebih besar | <strong className="text-rose-700">&lt;</strong> Lebih kecil | <strong className="text-sky-700 font-bold">=</strong> Sama
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Division Visualizer - Pensil Example */}
      <div className="comic-card bg-white p-5 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b-2 border-slate-200 pb-3">
          <div>
            <span className="bg-amber-100 text-amber-900 text-xs font-bold px-2.5 py-0.5 rounded-full border border-amber-300">
              Contoh Harga Satuan
            </span>
            <h3 className="font-heading font-bold text-xl text-slate-900 mt-1 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" /> Menghitung Harga 1 Buah Pensil
            </h3>
            <p className="text-xs font-semibold text-slate-600">
              Pak Budi membeli 1 kotak berisi 4 buah pensil seharga Rp 12.000,00. Mari hitung harga 1 buah pensil!
            </p>
          </div>

          {/* Animation Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              disabled={step >= totalPencils}
              className={`comic-button px-3 py-1.5 text-xs font-bold flex items-center gap-1.5 ${
                isPlaying ? 'bg-amber-400 text-slate-900' : 'bg-emerald-400 text-slate-900'
              } disabled:opacity-50`}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? 'Jeda' : 'Mulai Otomatis'}</span>
            </button>

            <button
              onClick={handleNextStep}
              disabled={step >= totalPencils || isPlaying}
              className="comic-button bg-cyan-300 hover:bg-cyan-400 text-slate-900 px-3 py-1.5 text-xs font-bold flex items-center gap-1 disabled:opacity-50"
            >
              <span>Langkah Selanjutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={handleReset}
              className="comic-button bg-slate-200 hover:bg-slate-300 text-slate-800 p-1.5 text-xs"
              title="Reset Visualisasi"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Visual Animation Stage */}
        <div className="bg-amber-50/70 p-6 rounded-2xl border-2 border-amber-300 space-y-6">
          {/* Formula Display */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 bg-white p-4 rounded-xl border-2 border-slate-800">
            <div className="flex items-center gap-3">
              <div className="text-4xl p-2 bg-amber-100 border-2 border-amber-400 rounded-2xl">
                ✏️
              </div>
              <div>
                <div className="text-xs font-bold text-slate-500">Harga Total Kotak Pensil:</div>
                <div className="font-heading font-extrabold text-xl text-slate-900">
                  Rp 12.000,00 (4 Pensil)
                </div>
              </div>
            </div>

            {/* Formula Arrow */}
            <div className="text-center font-heading font-extrabold text-xl sm:text-2xl text-slate-800 bg-amber-200 px-4 py-2 rounded-xl border-2 border-slate-800">
              Rp 12.000 ÷ 4 pensil = Rp 3.000 / pensil
            </div>
          </div>

          {/* Pencils Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((pNum) => {
              const isFilled = step >= pNum;

              return (
                <div
                  key={pNum}
                  onClick={() => {
                    if (isFilled) {
                      sounds.playPencilCoin(soundEnabled, pNum);
                    } else if (step === pNum - 1) {
                      handleNextStep();
                    }
                  }}
                  className={`comic-card-sm p-4 text-center transition-all duration-300 cursor-pointer select-none ${
                    isFilled
                      ? 'bg-white border-sky-400 scale-102 shadow-md hover:scale-105 hover:bg-sky-50/50'
                      : 'bg-slate-100/70 border-slate-300 opacity-60 hover:opacity-80'
                  }`}
                  title={isFilled ? `Klik untuk membunyikan Pensil #${pNum} (Rp 3.000,00)` : `Klik untuk hitung Pensil #${pNum}`}
                >
                  <div className="text-xs font-extrabold text-slate-700 mb-1 flex items-center justify-center gap-1">
                    <span>Pensil #{pNum}</span>
                    {isFilled && <Volume2 className="w-3 h-3 text-sky-500 inline" />}
                  </div>

                  <div className="text-5xl py-3 my-1">
                    ✏️
                  </div>

                  <div className="mt-1">
                    {isFilled ? (
                      <span className="inline-block px-3 py-1 bg-sky-500 text-white font-extrabold text-xs rounded-full border border-slate-900 shadow-sm animate-bounce">
                        Rp 3.000,00
                      </span>
                    ) : (
                      <span className="inline-block px-3 py-1 bg-slate-200 text-slate-600 font-bold text-xs rounded-full">
                        Belum Dihitung
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Progress / Result Indicator */}
          <div className="bg-white p-4 rounded-xl border-2 border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <div className="text-xs font-extrabold text-slate-500 uppercase tracking-wide">
                Status Perhitungan ({step} dari {totalPencils} Pensil):
              </div>
              <div className="font-heading font-bold text-lg text-slate-900">
                {step === 0 && 'Tekan "Langkah Selanjutnya" atau "Mulai Otomatis" untuk menghitung harga tiap pensil!'}
                {step === 1 && 'Pensil 1 = Rp 3.000,00'}
                {step === 2 && 'Pensil 1 & 2 = masing-masing Rp 3.000,00'}
                {step === 3 && 'Pensil 1, 2, & 3 = masing-masing Rp 3.000,00'}
                {step === 4 && 'Selesai! Seluruh 4 pensil masing-masing berharga Rp 3.000,00.'}
              </div>
            </div>

            {step === totalPencils && (
              <div className="bg-emerald-100 border-2 border-emerald-500 p-3 rounded-xl text-center shrink-0 animate-pulse-subtle">
                <div className="text-xs font-bold text-emerald-800 flex items-center gap-1 justify-center">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Rasio Satuan Diperoleh:
                </div>
                <div className="font-heading font-black text-xl text-emerald-900">
                  Rp 3.000,00 / 1 pensil
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Next Step Navigation Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNextSection}
          className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-6 py-3 text-base sm:text-lg font-bold flex items-center gap-2 shadow-[4px_4px_0px_#1e293b]"
        >
          Mulai Studi Kasus 1 (Warung A vs B)
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
