// Sound synthesis using Web Audio API
// Reliable, zero-latency, no external audio files required.

class SoundManager {
  private ctx: AudioContext | null = null;
  private lastPourTime = 0;

  public ensureUnlocked() {
    const ctx = this.getContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  }

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  // Play a triumphant, cheerful fanfare for correct answers in Games
  playCorrect(enabled = true) {
    if (!enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Cheerful major chord arpeggio: C5, E5, G5, C6
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.1);

      gain.gain.setValueAtTime(0, now + idx * 0.1);
      gain.gain.linearRampToValueAtTime(0.25, now + idx * 0.1 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.1);
      osc.stop(now + idx * 0.1 + 0.45);
    });

    // Add extra chime sparkle at the end
    setTimeout(() => {
      if (!ctx) return;
      const endNow = ctx.currentTime;
      [1318.51, 1567.98].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, endNow + i * 0.08);
        gain.gain.setValueAtTime(0.2, endNow + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, endNow + i * 0.08 + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(endNow + i * 0.08);
        osc.stop(endNow + i * 0.08 + 0.4);
      });
    }, 380);
  }

  // Play a friendly, gentle "oops" tone for incorrect answers (encouraging, not harsh)
  playWrong(enabled = true) {
    if (!enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Descending comic "wah-wah" / boing tone
    const notes = [
      { freq: 330, dur: 0.18, start: 0 },
      { freq: 277.18, dur: 0.28, start: 0.18 },
    ];

    notes.forEach(({ freq, dur, start }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + start);
      // slight downward slide
      osc.frequency.linearRampToValueAtTime(freq * 0.88, now + start + dur);

      gain.gain.setValueAtTime(0, now + start);
      gain.gain.linearRampToValueAtTime(0.22, now + start + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + start + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + start);
      osc.stop(now + start + dur);
    });
  }

  // Realistic liquid pouring sound (water stream rushing + bubbling splash droplets)
  playPourWater(enabled = true, isSyrup = false, force = false) {
    if (!enabled) return;
    const nowWall = Date.now();
    if (!force && nowWall - this.lastPourTime < 75) {
      return; // throttle rapid slider events to prevent stuttering
    }
    this.lastPourTime = nowWall;

    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    // 1. Bubbling Glugs (Ascending frequency sweeps representing bubbles bursting and fluid glugging)
    const bubbles = isSyrup
      ? [
          { f0: 380, f1: 920, t: 0.00, dur: 0.09, vol: 0.45 },
          { f0: 480, f1: 1100, t: 0.06, dur: 0.09, vol: 0.48 },
          { f0: 420, f1: 980, t: 0.12, dur: 0.09, vol: 0.45 },
          { f0: 550, f1: 1250, t: 0.18, dur: 0.10, vol: 0.50 },
          { f0: 620, f1: 1400, t: 0.24, dur: 0.09, vol: 0.46 },
          { f0: 740, f1: 1650, t: 0.30, dur: 0.10, vol: 0.48 },
        ]
      : [
          { f0: 480, f1: 1250, t: 0.00, dur: 0.08, vol: 0.45 },
          { f0: 600, f1: 1450, t: 0.05, dur: 0.08, vol: 0.48 },
          { f0: 540, f1: 1320, t: 0.11, dur: 0.09, vol: 0.45 },
          { f0: 720, f1: 1700, t: 0.16, dur: 0.09, vol: 0.50 },
          { f0: 650, f1: 1550, t: 0.22, dur: 0.08, vol: 0.46 },
          { f0: 820, f1: 1900, t: 0.27, dur: 0.09, vol: 0.48 },
        ];

    bubbles.forEach((b) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(b.f0, now + b.t);
      osc.frequency.exponentialRampToValueAtTime(b.f1, now + b.t + b.dur * 0.85);

      gain.gain.setValueAtTime(0.001, now + b.t);
      gain.gain.linearRampToValueAtTime(b.vol, now + b.t + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.001, now + b.t + b.dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + b.t);
      osc.stop(now + b.t + b.dur + 0.02);
    });

    // 2. Water/Syrup stream rushing sound (lowpass filtered noise burst)
    try {
      const bufferSize = Math.floor(ctx.sampleRate * 0.36);
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = noiseBuffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(isSyrup ? 1200 : 1900, now);
      filter.frequency.linearRampToValueAtTime(isSyrup ? 800 : 1300, now + 0.35);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.001, now);
      noiseGain.gain.linearRampToValueAtTime(0.35, now + 0.03);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);

      noiseSource.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(ctx.destination);

      noiseSource.start(now);
      noiseSource.stop(now + 0.37);
    } catch {
      // Fallback liquid swoosh
      const rushOsc = ctx.createOscillator();
      const rushGain = ctx.createGain();
      rushOsc.type = 'triangle';
      rushOsc.frequency.setValueAtTime(isSyrup ? 350 : 500, now);
      rushOsc.frequency.linearRampToValueAtTime(isSyrup ? 480 : 700, now + 0.3);
      rushGain.gain.setValueAtTime(0.25, now);
      rushGain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
      rushOsc.connect(rushGain);
      rushGain.connect(ctx.destination);
      rushOsc.start(now);
      rushOsc.stop(now + 0.33);
    }
  }

  // Bubbly liquid pour / droplet sound for syrup and water sliders in Simulation
  playPourLiquid(enabled = true, pitchMultiplier = 1) {
    this.playPourWater(enabled, pitchMultiplier > 1);
  }

  // Sound for pencil unit price calculation (crisp pencil tap + coin chime "ting! / ka-ching")
  playPencilCoin(enabled = true, step = 1) {
    if (!enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    // 1. Crisp wooden pencil tap
    const tapOsc = ctx.createOscillator();
    const tapGain = ctx.createGain();
    tapOsc.type = 'triangle';
    tapOsc.frequency.setValueAtTime(800, now);
    tapOsc.frequency.exponentialRampToValueAtTime(300, now + 0.035);

    tapGain.gain.setValueAtTime(0.25, now);
    tapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    tapOsc.connect(tapGain);
    tapGain.connect(ctx.destination);
    tapOsc.start(now);
    tapOsc.stop(now + 0.05);

    // 2. Bright, shiny coin chime ("ting!"): scale pitch with step (1 to 4)
    // Step 1: C6 (1046 Hz), Step 2: D6 (1174 Hz), Step 3: E6 (1318 Hz), Step 4: G6 (1567 Hz) + C7 sparkle
    const baseFreqs = [1046.5, 1174.66, 1318.51, 1567.98];
    const pitch = baseFreqs[Math.min(Math.max(step - 1, 0), baseFreqs.length - 1)] || 1046.5;

    const coinOsc = ctx.createOscillator();
    const coinGain = ctx.createGain();
    coinOsc.type = 'sine';
    coinOsc.frequency.setValueAtTime(pitch, now + 0.02);

    coinGain.gain.setValueAtTime(0, now + 0.02);
    coinGain.gain.linearRampToValueAtTime(0.28, now + 0.03);
    coinGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    coinOsc.connect(coinGain);
    coinGain.connect(ctx.destination);
    coinOsc.start(now + 0.02);
    coinOsc.stop(now + 0.48);

    // Overtone shimmer for coin ring
    const shimmerOsc = ctx.createOscillator();
    const shimmerGain = ctx.createGain();
    shimmerOsc.type = 'sine';
    shimmerOsc.frequency.setValueAtTime(pitch * 2, now + 0.02);

    shimmerGain.gain.setValueAtTime(0, now + 0.02);
    shimmerGain.gain.linearRampToValueAtTime(0.12, now + 0.03);
    shimmerGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    shimmerOsc.connect(shimmerGain);
    shimmerGain.connect(ctx.destination);
    shimmerOsc.start(now + 0.02);
    shimmerOsc.stop(now + 0.38);

    // If step 4 (all 4 pencils finished!), add a celebratory triumphant chord finish
    if (step >= 4) {
      setTimeout(() => {
        if (!ctx) return;
        const endNow = ctx.currentTime;
        [1567.98, 2093.0].forEach((f, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, endNow + i * 0.08);
          gain.gain.setValueAtTime(0.22, endNow + i * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, endNow + i * 0.08 + 0.45);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(endNow + i * 0.08);
          osc.stop(endNow + i * 0.08 + 0.5);
        });
      }, 150);
    }
  }

  // Pleasant mixing / stirring chime for simulation
  playMixChime(enabled = true) {
    if (!enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    [659.25, 880, 1174.66].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + i * 0.06);

      gain.gain.setValueAtTime(0.15, now + i * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + i * 0.06);
      osc.stop(now + i * 0.06 + 0.3);
    });
  }

  // Card placement / snap sound
  playCardSnap(enabled = true) {
    if (!enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(400, now);
    osc.frequency.exponentialRampToValueAtTime(800, now + 0.06);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.08);
  }

  // Warning alert (e.g. belum terisi semua)
  playWarning(enabled = true) {
    if (!enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(440, now);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.13);
  }

  // ==========================================
  // BACKGROUND MUSIC (BGM) ENGINE
  // ==========================================
  private bgmPlaying = false;
  private bgmVolume = 0.35; // 0.0 to 1.0
  private bgmTheme: 'playful' | 'chill' | 'custom' = 'playful';
  private bgmTimer: any = null;
  private bgmMasterGain: GainNode | null = null;
  private bgmNextStepTime = 0;
  private bgmStep = 0;
  private customAudio: HTMLAudioElement | null = null;
  private customAudioName: string | null = null;
  private bgmListeners: Array<(state: {
    isPlaying: boolean;
    volume: number;
    theme: 'playful' | 'chill' | 'custom';
    customName: string | null;
  }) => void> = [];

  public subscribeBgm(
    listener: (state: {
      isPlaying: boolean;
      volume: number;
      theme: 'playful' | 'chill' | 'custom';
      customName: string | null;
    }) => void
  ) {
    this.bgmListeners.push(listener);
    listener(this.getBgmState());
    return () => {
      this.bgmListeners = this.bgmListeners.filter((l) => l !== listener);
    };
  }

  public getBgmState() {
    return {
      isPlaying: this.bgmPlaying,
      volume: this.bgmVolume,
      theme: this.bgmTheme,
      customName: this.customAudioName,
    };
  }

  private notifyBgm() {
    const st = this.getBgmState();
    this.bgmListeners.forEach((l) => l(st));
  }

  private initBgmMasterGain(ctx: AudioContext) {
    if (!this.bgmMasterGain) {
      this.bgmMasterGain = ctx.createGain();
      this.bgmMasterGain.gain.setValueAtTime(this.bgmVolume * 0.22, ctx.currentTime);
      this.bgmMasterGain.connect(ctx.destination);
    }
  }

  public setBgmVolume(vol: number) {
    const clamped = Math.max(0, Math.min(1, vol));
    this.bgmVolume = clamped;
    const ctx = this.getContext();
    if (ctx && this.bgmMasterGain) {
      this.bgmMasterGain.gain.setValueAtTime(this.bgmVolume * 0.22, ctx.currentTime);
    }
    if (this.customAudio) {
      this.customAudio.volume = this.bgmVolume;
    }
    this.notifyBgm();
  }

  public setBgmTheme(theme: 'playful' | 'chill' | 'custom') {
    if (this.bgmTheme === theme) return;
    const wasPlaying = this.bgmPlaying;
    if (wasPlaying) {
      this.stopBgm(false);
    }
    this.bgmTheme = theme;
    if (wasPlaying) {
      this.startBgm();
    } else {
      this.notifyBgm();
    }
  }

  public setCustomAudioFile(file: File) {
    if (this.customAudio) {
      this.customAudio.pause();
      this.customAudio.src = '';
    }
    const url = URL.createObjectURL(file);
    this.customAudio = new Audio(url);
    this.customAudio.loop = true;
    this.customAudio.volume = this.bgmVolume;
    this.customAudioName = file.name;
    this.bgmTheme = 'custom';

    if (this.bgmPlaying) {
      this.customAudio.play().catch(() => {});
    }
    this.notifyBgm();
  }

  public clearCustomAudio() {
    if (this.customAudio) {
      this.customAudio.pause();
      this.customAudio = null;
    }
    this.customAudioName = null;
    if (this.bgmTheme === 'custom') {
      this.bgmTheme = 'playful';
      if (this.bgmPlaying) {
        this.startBgm();
      }
    }
    this.notifyBgm();
  }

  public toggleBgm() {
    if (this.bgmPlaying) {
      this.stopBgm();
    } else {
      this.startBgm();
    }
  }

  public startBgm() {
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    this.bgmPlaying = true;
    this.notifyBgm();

    if (this.bgmTheme === 'custom' && this.customAudio) {
      this.customAudio.volume = this.bgmVolume;
      this.customAudio.play().catch(() => {});
      return;
    }

    this.initBgmMasterGain(ctx);
    if (this.bgmMasterGain) {
      this.bgmMasterGain.gain.setValueAtTime(this.bgmVolume * 0.22, ctx.currentTime);
    }

    this.bgmStep = 0;
    this.bgmNextStepTime = ctx.currentTime + 0.05;

    if (this.bgmTimer) {
      clearInterval(this.bgmTimer);
    }
    this.bgmTimer = setInterval(() => this.scheduleBgmNotes(), 100);
  }

  public stopBgm(notify = true) {
    this.bgmPlaying = false;
    if (this.bgmTimer) {
      clearInterval(this.bgmTimer);
      this.bgmTimer = null;
    }
    if (this.customAudio) {
      this.customAudio.pause();
    }
    const ctx = this.getContext();
    if (ctx && this.bgmMasterGain) {
      // Gentle fade out
      this.bgmMasterGain.gain.linearRampToValueAtTime(0.001, ctx.currentTime + 0.15);
    }
    if (notify) {
      this.notifyBgm();
    }
  }

  private scheduleBgmNotes() {
    if (!this.bgmPlaying) return;
    const ctx = this.getContext();
    if (!ctx || !this.bgmMasterGain) return;

    // Lookahead: schedule up to 0.4s into future
    const lookahead = 0.4;
    const stepDuration = this.bgmTheme === 'chill' ? 0.38 : 0.28; // seconds per 8th note step

    while (this.bgmNextStepTime < ctx.currentTime + lookahead) {
      if (this.bgmTheme === 'chill') {
        this.playChillStep(ctx, this.bgmStep % 32, this.bgmNextStepTime);
      } else {
        this.playPlayfulStep(ctx, this.bgmStep % 32, this.bgmNextStepTime);
      }
      this.bgmNextStepTime += stepDuration;
      this.bgmStep++;
    }
  }

  // Procedural playful marimba/music box
  // 32 steps (4 bars of 8 eighth-notes) in C major
  private playPlayfulStep(ctx: AudioContext, step: number, time: number) {
    if (!this.bgmMasterGain) return;

    // Chord progressions per bar (8 steps each):
    // Bar 1 (0-7): C major (C4, E4, G4, C5)
    // Bar 2 (8-15): G major (G3, B3, D4, G4)
    // Bar 3 (16-23): A minor (A3, C4, E4, A4)
    // Bar 4 (24-31): F major (F3, A3, C4, F4)

    // Bass note on step 0 and 4 of each bar
    const bar = Math.floor(step / 8);
    const barStep = step % 8;

    const bassFreqs = [130.81, 98.0, 110.0, 87.31]; // C3, G2, A2, F2
    if (barStep === 0 || barStep === 4) {
      this.renderSynthNote(ctx, bassFreqs[bar], time, 0.45, 0.18, 'sine');
    }

    // Gentle middle harmony on steps 2 and 6
    const midFreqs = [
      [261.63, 329.63], // C4, E4
      [246.94, 293.66], // B3, D4
      [220.0, 261.63],  // A3, C4
      [261.63, 349.23], // C4, F4
    ];
    if (barStep === 2 || barStep === 6) {
      const pair = midFreqs[bar];
      this.renderSynthNote(ctx, pair[0], time, 0.25, 0.1, 'triangle');
      this.renderSynthNote(ctx, pair[1], time, 0.25, 0.08, 'sine');
    }

    // Playful melody pattern
    // Pentatonic happy melody
    const melodyMap: Record<number, number> = {
      0: 523.25,  // C5
      2: 659.25,  // E5
      3: 587.33,  // D5
      4: 783.99,  // G5
      6: 659.25,  // E5
      8: 587.33,  // D5
      10: 493.88, // B4
      12: 587.33, // D5
      14: 659.25, // E5
      16: 659.25, // E5
      18: 523.25, // C5
      20: 880.0,  // A5
      22: 783.99, // G5
      24: 698.46, // F5
      26: 659.25, // E5
      28: 587.33, // D5
      30: 523.25, // C5
    };

    if (melodyMap[step]) {
      this.renderSynthNote(ctx, melodyMap[step], time, 0.32, 0.14, 'triangle');
      // subtle overtone chime
      this.renderSynthNote(ctx, melodyMap[step] * 2, time, 0.12, 0.04, 'sine');
    }
  }

  // Procedural chill lofi study
  // 32 steps (4 bars of 8 eighth-notes): Cmaj7 -> Am7 -> Dm7 -> G7
  private playChillStep(ctx: AudioContext, step: number, time: number) {
    if (!this.bgmMasterGain) return;
    const bar = Math.floor(step / 8);
    const barStep = step % 8;

    const bassFreqs = [130.81, 110.0, 146.83, 98.0]; // C3, A2, D3, G2
    if (barStep === 0) {
      this.renderSynthNote(ctx, bassFreqs[bar], time, 0.7, 0.2, 'sine');
    }

    // Soft Rhodes-like chords
    const chordNotes = [
      [261.63, 329.63, 392.0, 493.88], // Cmaj7: C4, E4, G4, B4
      [220.0, 261.63, 329.63, 392.0],  // Am7: A3, C4, E4, G4
      [293.66, 349.23, 440.0, 523.25], // Dm7: D4, F4, A4, C5
      [246.94, 293.66, 349.23, 392.0], // G7: B3, D4, F4, G4
    ];

    if (barStep === 1 || barStep === 5) {
      const chord = chordNotes[bar];
      chord.forEach((freq, idx) => {
        this.renderSynthNote(ctx, freq, time + idx * 0.02, 0.38, 0.07, 'sine');
      });
    }

    // Gentle kalimba drops
    const chillMelody: Record<number, number> = {
      2: 659.25, // E5
      4: 587.33, // D5
      7: 523.25, // C5
      10: 440.0, // A4
      12: 523.25,// C5
      15: 493.88,// B4
      18: 698.46,// F5
      20: 659.25,// E5
      23: 587.33,// D5
      26: 783.99,// G5
      28: 659.25,// E5
      31: 523.25,// C5
    };

    if (chillMelody[step]) {
      this.renderSynthNote(ctx, chillMelody[step], time, 0.45, 0.12, 'triangle');
    }
  }

  private renderSynthNote(
    ctx: AudioContext,
    freq: number,
    startTime: number,
    duration: number,
    volume: number,
    type: OscillatorType
  ) {
    if (!this.bgmMasterGain) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Soft low-pass filter to make it mellow, warm, and gentle
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1400, startTime);

      osc.type = type;
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(volume, startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.bgmMasterGain);

      osc.start(startTime);
      osc.stop(startTime + duration + 0.05);
    } catch {
      // Ignore timing errors if tab suspended
    }
  }
}

export const sounds = new SoundManager();

if (typeof window !== 'undefined') {
  const unlock = () => {
    sounds.ensureUnlocked();
  };
  window.addEventListener('pointerdown', unlock, { passive: true });
  window.addEventListener('click', unlock, { passive: true });
  window.addEventListener('touchstart', unlock, { passive: true });
}
