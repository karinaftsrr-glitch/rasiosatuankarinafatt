/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SectionId } from './types';
import { Navbar } from './components/Navbar';
import { NavigationBoxes } from './components/NavigationBoxes';
import { SectionWelcome } from './components/SectionWelcome';
import { SectionObjectives } from './components/SectionObjectives';
import { SectionBahanAjar } from './components/SectionBahanAjar';
import { SectionSimulation } from './components/SectionSimulation';
import { SectionGames } from './components/SectionGames';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import { sounds } from './utils/audio';

export default function App() {
  const [currentSection, setCurrentSection] = useState<SectionId>('welcome');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [resetKey, setResetKey] = useState<number>(0);

  const sectionOrder: SectionId[] = [
    'welcome',
    'objectives',
    'materials',
    'simulation',
    'games',
  ];

  const currentIdx = sectionOrder.indexOf(currentSection);

  const handleNext = () => {
    if (currentIdx < sectionOrder.length - 1) {
      setCurrentSection(sectionOrder[currentIdx + 1]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrev = () => {
    if (currentIdx > 0) {
      setCurrentSection(sectionOrder[currentIdx - 1]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleResetCurrentSection = () => {
    setResetKey((prev) => prev + 1);
  };

  const sectionLabels: Record<SectionId, string> = {
    welcome: 'Halaman Pembuka',
    objectives: 'Tujuan Pembelajaran',
    materials: 'Bahan Ajar',
    simulation: 'Simulasi',
    games: 'Games',
  };

  return (
    <div className="min-h-screen bg-amber-50 text-slate-900 flex flex-col font-sans pb-16">
      {/* Top Navbar */}
      <Navbar
        currentSection={currentSection}
        onSelectSection={(sec) => {
          setCurrentSection(sec);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onResetSection={handleResetCurrentSection}
        soundEnabled={soundEnabled}
        onToggleSound={() => {
          const next = !soundEnabled;
          setSoundEnabled(next);
          if (next) sounds.playMixChime(true);
        }}
      />

      {/* Main Container */}
      <main className="max-w-5xl w-full mx-auto px-4 py-6 flex-1 space-y-6">
        {/* 4 Clickable Card Boxes Menu (Shown when outside Welcome page) */}
        {currentSection !== 'welcome' && (
          <NavigationBoxes
            currentSection={currentSection}
            onSelectSection={(sec) => {
              setCurrentSection(sec);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {/* Section View Router */}
        <div key={`${currentSection}-${resetKey}`} className="animate-fadeIn">
          {currentSection === 'welcome' && (
            <SectionWelcome
              onStartLearning={() => {
                setCurrentSection('objectives');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onSelectDirectSection={(sec) => {
                setCurrentSection(sec);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          )}

          {currentSection === 'objectives' && (
            <SectionObjectives onStartLearning={handleNext} />
          )}

          {currentSection === 'materials' && (
            <SectionBahanAjar
              onNextToSimulation={handleNext}
              soundEnabled={soundEnabled}
            />
          )}

          {currentSection === 'simulation' && (
            <SectionSimulation
              onNextToGames={handleNext}
              soundEnabled={soundEnabled}
            />
          )}

          {currentSection === 'games' && (
            <SectionGames soundEnabled={soundEnabled} />
          )}
        </div>

        {/* Footer Navigation Controls (Shown when outside Welcome page) */}
        {currentSection !== 'welcome' && (
          <div className="comic-card bg-amber-200/90 p-4 border-slate-900 flex items-center justify-between gap-2 mt-8">
            <button
              onClick={handlePrev}
              disabled={currentIdx <= 0}
              className="comic-button bg-white hover:bg-slate-100 text-slate-800 px-4 py-2 text-xs sm:text-sm font-bold flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>{currentIdx === 1 ? 'Ke Halaman Pembuka' : 'Sebelumnya'}</span>
            </button>

            <div className="text-center font-bold text-xs sm:text-sm text-slate-800">
              Halaman: <span className="font-heading font-black text-rose-700">{sectionLabels[currentSection]}</span>
            </div>

            <button
              onClick={handleNext}
              disabled={currentIdx === sectionOrder.length - 1}
              className="comic-button bg-rose-500 hover:bg-rose-600 text-white px-4 py-2 text-xs sm:text-sm font-bold flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed shadow-[2px_2px_0px_#1e293b]"
            >
              <span className="hidden sm:inline">Selanjutnya</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </main>

      {/* Footer Branding */}
      <footer className="text-center text-xs font-bold text-slate-500 pt-6">
        Karina Fatmasari • Media Pembelajaran Matematika RasioKu
      </footer>
    </div>
  );
}
